<?php
namespace Backend\GridModule\Controller\Adminhtml\GridContoller;
use Magento\Framework\App\Filesystem\DirectoryList;

class Save extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {
        $post = $this->getRequest()->getPost();
       
        if ($post)
        {
            $data = $this->getRequest()->getParams();
            //echo "<pre>";print_r($data); die('here');
            $model = $this->_objectManager->create('Backend\GridModule\Model\BackendModule');
            //print_r($_FILES['image']['name']);
            //die('here');

            if(isset($_FILES['image']['name']) && $_FILES['image']['name'] != '') {
            try {
                $uploader = $this->_objectManager->create('Magento\MediaStorage\Model\File\Uploader',['fileId' => 'image']);
                    $uploader->setAllowedExtensions(array('jpg', 'jpeg', 'gif', 'png'));
                    $uploader->setAllowRenameFiles(true);
                    $uploader->setFilesDispersion(true);
                    $mediaDirectory = $this->_objectManager->get('Magento\Framework\Filesystem')->getDirectoryRead(DirectoryList::MEDIA);
                    $result = $uploader->save($mediaDirectory->getAbsolutePath('upload/images'));
                    unset($result['tmp_name']);
                    unset($result['path']);
                    $path = 'upload/images';
                    $data['image'] = $path.$result['file'];
                } catch (Exception $e) {
                $data['image'] = $_FILES['image']['name'];
                }
            }
            else{
                if(empty($data['image']['value']))
                {
                    $data['image'] = "No image available";
                }
                else
                {
                    $data['image'] = $data['image']['value'];
                }
            } 

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
            $model->setData($data);

            //$model->setId($this->getRequest()->getParam('id')); 
            //echo $this->getRequest()->getParam('name');  
            //$model->setName($this->getRequest()->getParam('name'));
            try {
                $model->save();      
                //die('saved');      
                $this->messageManager->addSuccess(__('Record Saved.'));       
                 
                $this->_redirect('*/*/');   
             return;
            } catch (\Magento\Framework\Model\Exception $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the banner.'));
            }

            $this->_getSession()->setFormData($data);
            $this->_redirect('*/*/edit', array('banner_id' => $this->getRequest()->getParam('banner_id')));
            return;
        }
        $this->_redirect('*/*/');
    }
	   
}
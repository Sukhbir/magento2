<?php
namespace Backend\GridModule\Block\Adminhtml;
class BackendModule extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_backendModule';/*block grid.php directory*/
        $this->_blockGroup = 'Backend_GridModule';
        $this->_headerText = __('BackendModule');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		
    }
}

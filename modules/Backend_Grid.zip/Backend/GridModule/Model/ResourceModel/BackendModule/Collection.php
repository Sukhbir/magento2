<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Backend\GridModule\Model\ResourceModel\BackendModule;

/**
 * BackendModules Collection
 *
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Initialize resource collection
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('Backend\GridModule\Model\BackendModule', 'Backend\GridModule\Model\ResourceModel\BackendModule');
    }
}

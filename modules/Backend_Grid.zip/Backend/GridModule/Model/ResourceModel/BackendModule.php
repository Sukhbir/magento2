<?php
/**
 * Copyright © 2015 Backend. All rights reserved.
 */
namespace Backend\GridModule\Model\ResourceModel;

/**
 * BackendModule resource
 */
class BackendModule extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('gridmodule_backendmodule', 'id');
    }

  
}

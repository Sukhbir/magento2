<?php
/**
 * @category Jute
 * @package Jute_Ecommerce
 */
namespace Backend\GridModule\Setup;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
class UpgradeSchema implements UpgradeSchemaInterface{
public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context){
 if (version_compare($context->getVersion(), '2.0.1')<0) {
 $setup->startSetup();
 $setup->getConnection()->addColumn(
 $setup->getTable('gridmodule_backendmodule'),
	'gender',
	['type' =>\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	'length' => '11',
	'nullable' => false,
	'default' => '0',
	'comment' => 'gender']);
 $setup->getConnection()->addColumn(
	$setup->getTable('gridmodule_backendmodule'),
		'image',
		['type' =>\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
		'length' => '11',
		'nullable' => false,
		'default' => '0',
		'comment' => 'image']);
 $setup->endSetup();
 } } }
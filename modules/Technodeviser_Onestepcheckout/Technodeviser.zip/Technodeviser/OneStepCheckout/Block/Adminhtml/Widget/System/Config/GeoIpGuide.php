<?php

/**
 * *
 *  Copyright © 2016 Technodeviser. All rights reserved.
 *  See COPYING.txt for license details.
 *
 */

namespace Technodeviser\OneStepCheckout\Block\Adminhtml\Widget\System\Config;
class GeoIpGuide extends \Technodeviser\OneStepCheckout\Block\Adminhtml\Widget\System\Config\Notification
{
    /**
     * @var string
     */
    protected $_template = 'Technodeviser_OneStepCheckout::system/config/guide.phtml';
}
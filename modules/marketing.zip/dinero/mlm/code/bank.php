<?php
	require('../config.php');
	@session_start();
	$userid=$_SESSION['userlogin'];

	if(isset($_POST['add_bank_details']))
	{
		$account_name = mysqli_real_escape_string($con,$_POST['account_name']);
		$account_no = mysqli_real_escape_string($con,$_POST['account_no']);
		$bank_name = mysqli_real_escape_string($con,$_POST['bank_name']);
		$ifsc = mysqli_real_escape_string($con,$_POST['ifsc']);
		$aadhar_no = mysqli_real_escape_string($con,$_POST['aadhar_no']);
		$pan_no = mysqli_real_escape_string($con,$_POST['pan_no']);
		$address = mysqli_real_escape_string($con,$_POST['address']);

		$query = mysqli_query($con,"insert into bank values('0','$userid','$account_name','$account_no','$bank_name','$ifsc','$aadhar_no','$pan_no','$address')");

		if($query)
		{
			$_SESSION['user_profile']='Bank Detail Added';
			header('location:../bank-details.php');
			exit();
		}
	}
?>

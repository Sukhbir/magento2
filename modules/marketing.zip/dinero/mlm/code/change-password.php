<?php
	@session_start();
	include('../config.php');

	$userlogin=$_SESSION['userlogin'];

	if(isset($_POST['btn_password']) && isset($_POST['old_password']) && isset($_POST['new_password']))
	{

		$old_password=mysqli_escape_string($con,$_POST['old_password']);
		$new_password=mysqli_escape_string($con,$_POST['new_password']);

		$checkoldpassword=mysqli_query($con,"select * from member where uname='$userlogin' and password='$old_password'") or die ("Error : ".mysqli_error($con));
		if(mysqli_num_rows($checkoldpassword)==1)
		{
			$updatepassword=mysqli_query($con,"update member set password='$new_password' where uname='$userlogin'") or die ("Error : ".mysqli_error($con));

			if($updatepassword)
			{
				$_SESSION['success']='Successfully Password Changed.';
				header('location:../change-password.php');
				exit();
			}
		}
		else
		{
			$_SESSION['errors']='Old Password is Wrong.';
			header('location:../change-password.php');
			exit();
		}
	}
?>
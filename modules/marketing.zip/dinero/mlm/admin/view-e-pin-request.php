<?php include('header.php'); ?>

<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>View E-Pin Request</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <?php
        if(isset($_SESSION['new_e_pin_request']))
        {
        ?>
        <div class="breadcrumbs bg-success">
            <div>
                <div class="page-header text-center text-white bg-success">
                    <div class="page-title">
                        <h1><?php echo $_SESSION['new_e_pin_request']; ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <?php
        unset($_SESSION['new_e_pin_request']);
        }
        ?>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                        <div class="card-body table-responsive">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>User</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Generate E-Pin</th>
                                    <th>Cancel</th>
                                </tr>
                            </thead>
                    
                            <tbody>
                                  <?php
                                  $sql = "SELECT * FROM e_pin_request WHERE status='0' order by date ASC";
                                  $re = mysqli_query($con, $sql) or die (mysqli_error($con));
                                  $i=1;
                                  while ($row=mysqli_fetch_assoc($re))
                                    {
                                  ?>
                                    <tr>
                                        <td><?php echo $i ?></td>
                                        <td><?php echo $row['user_id'] ?></td>
                                        <td><?php echo $row['amount'] ?></td>
                                        <td><?php echo $row['date'] ?></td>
                                        <td><?php if($row['status']==0){ echo "Open"; } ?></td>
                                        <td><a class="btn btn-success text-white" href="code/e-pin.php?action=generate_e_pin&e_pin_request_id=<?php echo $row['id'] ?>"><i class="fa fa-file"></i> Generate E-pin</a></td>
                                        <td><a class="btn btn-danger text-white"><i class="fa fa-times"></i> Cancel</a></td>
                                    </tr>
                                  <?php
                                        $i++;
                                    }
                                  ?>
                            </tbody>
                        </table>
                     </div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

</div><!-- /#right-panel -->


                  
<?php include('footer.php') ?>
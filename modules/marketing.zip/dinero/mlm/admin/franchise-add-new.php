<?php include('header.php'); ?>
                  <div class="col-lg-6">
                    <div class="card">
                      <div class="card-header">Add New Franchise</div>
                      <div class="card-body card-block">
                        <form action="code/franchise.php" method="post" class="">
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="fname" name="fname" placeholder="First name" class="form-control">
                            </div>
                          </div>
						              
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="sname" name="lname" placeholder="Lastname" class="form-control">
                            </div>
                          </div>
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="uname" name="uname" placeholder="Username" class="form-control">
                            </div>
                          </div>
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                              <input type="email" id="email" name="email" placeholder="Email" class="form-control">
                            </div>
                          </div>
						  
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-phone-square"></i></div>
                              <input type="text" id="mnumber" name="mobile_number" placeholder="Mobile Number" class="form-control">
                            </div>
                          </div>
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-rupee"></i></div>
                              <select id="enrollment_fee" name="enrollment_fee" class="form-control">
                            
                                <option selected="" disabled=""> Select Franchises Amount</option>

                                <?php
                                $i=30000;
                                while($i <= 300000)
                                {
                                ?>

                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>

                                <?php
                                  $i=$i+30000;
                                }
                                ?>
                              </select>
                            </div>
                          </div>
					
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
                              <input type="password" id="password" name="password" placeholder="Password" class="form-control">
                            </div>
                          </div>

						              <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
                              <input type="password" id="cpassword" name="cpassword" placeholder="Confirm Password" class="form-control">
                            </div>
                          </div>
                        
                          <div class="form-actions form-group"><button name="addnew_franchases" type="submit" class="btn btn-success"><i class="fa fa-plus"></i> Add Member</button></div>
                        </form>
                      </div>
                    </div>
                  </div>
<?php include('footer.php') ?>
<?php include('header.php'); ?>
<?php
    
    date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
    $date=date('Y-m-d');
    
    $chkdaily_flush=mysqli_query($con,"SELECT * FROM dally_flush where todate='$date'") or die("Error : ".mysqli_error($con));
        
        if(mysqli_num_rows($chkdaily_flush)==0)
        {
            $getdaybalance=mysqli_query($con,"SELECT * FROM income") or die("Error : ".mysqli_error($con));
            while($getdaybalancerow=mysqli_fetch_array($getdaybalance))
            {
                $user_idbalance=$getdaybalancerow['user_id'];
                $day_bal=$getdaybalancerow['day_bal'];
                $yesterday=date('Y-m-d',strtotime("-1 days"));

                $pendingbalance=mysqli_query($con,"insert into pending_commision (id,date,user_id,balance) values ('0','$yesterday','$user_idbalance','$day_bal')") or die("Error : ".mysqli_error($con));
            }

            if($pendingbalance)
            {
                $updateday_bal=mysqli_query($con,"update income set day_bal='0'") or die("Error : ".mysqli_error($con));

                $updatedaily_fluse=mysqli_query($con,"update dally_flush set todate='$date'") or die("Error : ".mysqli_error($con));
            
                $con->set_charset("utf8");


                // Get All Table Names From the Database
                $tables = array();
                $sql = "SHOW TABLES";
                $result = mysqli_query($con, $sql);

                while ($row = mysqli_fetch_row($result)) {
                    $tables[] = $row[0];
                }
                ?>
                <?php
                $sqlScript = "";
                foreach ($tables as $table) {
                    
                    // Prepare SQLscript for creating table structure
                    $query = "SHOW CREATE TABLE $table";
                    $result = mysqli_query($con, $query);
                    $row = mysqli_fetch_row($result);
                    
                    $sqlScript .= "\n\n" . $row[1] . ";\n\n";
                    
                    
                    $query = "SELECT * FROM $table";
                    $result = mysqli_query($con, $query);
                    
                    $columnCount = mysqli_num_fields($result);
                    
                    // Prepare SQLscript for dumping data for each table
                    for ($i = 0; $i < $columnCount; $i ++) {
                        while ($row = mysqli_fetch_row($result)) {
                            $sqlScript .= "INSERT INTO $table VALUES(";
                            for ($j = 0; $j < $columnCount; $j ++) {
                                $row[$j] = $row[$j];
                                
                                if (isset($row[$j])) {
                                    $sqlScript .= '"' . $row[$j] . '"';
                                } else {
                                    $sqlScript .= '""';
                                }
                                if ($j < ($columnCount - 1)) {
                                    $sqlScript .= ',';
                                }
                            }
                            $sqlScript .= ");\n";
                        }
                    }
                    
                    $sqlScript .= "\n"; 
                }

                if(!empty($sqlScript))
                {
                    // Save the SQL script to a backup file
                    $backup_file_name = 'backup/'.'mlm'. '_backup_' . date('d-m-Y h-i') . '.sql';
                    $fileHandler = fopen($backup_file_name, 'w+');
                    $number_of_lines = fwrite($fileHandler, $sqlScript);
                    fclose($fileHandler); 
                }
            }
        }
?>
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <?php
            $query = mysqli_query($con,"select * from member");
            $result = mysqli_num_rows($query);
        ?>
        <div class="content mt-3">
            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-user text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Total DSA</div>
                                <div class="stat-digit"><?php echo $result; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <?php
            $query = mysqli_query($con,"select * from e_pin_request where status='0'");
            $result = mysqli_num_rows($query);
            ?>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-pin text-success border-success"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">E-Pin Request</div>
                                <div class="stat-digit"><?php echo $result; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            $query = mysqli_query($con,"select * from e_pin where status='0'");
            $result = mysqli_num_rows($query);
            ?>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-pin text-warning border-warning"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">E-pin</div>
                                <div class="stat-digit"><?php echo $result; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            $payout=0;
            $query = mysqli_query($con,"select * from income_received");
            while($result = mysqli_fetch_array($query))
            {
                $payout=$payout+$result['amount'];
            }
            ?>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-wallet text-warning border-warning"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Total Payout</div>
                                <div class="stat-digit"><?php echo $payout; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
                            <div class="card">
                                <div class="card-header">
                                    <strong> Quick Link </strong>
                                </div>
                                <div class="card-body">
                                    <button onclick="location.href='new-member.php'" type="button" class="btn btn-primary mb-2"><i class="fa fa-plus"></i>&nbsp; Add New DSA</button>
                                    
                                    <button onclick="location.href='members.php'" type="button" class="btn btn-secondary mb-2"><i class="fa fa-users"></i>&nbsp; View DSA</button>
                                    
                                    <button onclick="location.href='genealogytree.php'" type="button" class="btn btn-success mb-2"><i class="fa fa-sitemap"></i>&nbsp; View DSA Tree</button>
                                    
                                    <button onclick="location.href='view-e-pin.php'" type="button" class="btn btn-warning mb-2"><i class="fa fa-map-pin"></i>&nbsp; View E-Pin</button>
                                    
                                    <button onclick="location.href='view-e-pin-request.php'" type="button" class="btn btn-danger mb-2"><i class="fa fa-map-pin"></i>&nbsp; View E-pin Request</button>
                                    
                                    <button onclick="location.href='income.php'" type="button" class="btn btn-primary mb-2"><i class="fa fa-rupee"></i>&nbsp; Income </button>
                                    
                                    <button onclick="location.href='income-history.php'" type="button" class="btn btn-secondary mb-2"><i class="fa fa-history"></i>&nbsp; Income History </button>

                                    <button onclick="location.href='report.php'" type="button" class="btn btn-success mb-2"><i class="fa fa-file"></i>&nbsp; Report</button>
                                </div>
                            </div><!-- /# card -->

        </div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->
<?php include('footer.php') ?>
<?php include('header.php'); ?>
                  <div class="col-lg-6">
                    <div class="card">
                      <div class="card-header">Add New E-Pin Setting
					  <a href="your link here" style="float:right;"><i class="fa fa-refresh"></i></a>
					  
					  </div>
                      <div class="card-body card-block">
                        <form action="code/e-pin.php" method="post" class="">
                          
						  <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-dollar"></i></div>
                              <input type="number" id="epinvalue" name="epinvalue" placeholder="E-Pin Values" class="form-control">
                            </div>
                          </div>
						  
						  	
						 <div class="form-actions form-group"><button type="submit" name="addnew_e_pin_values" class="btn btn-success"><i class="fa fa-plus"></i> Add E-pin Value</button></div>
                        </form>
                      </div>
                    </div>
                  </div>
<?php include('footer.php') ?>
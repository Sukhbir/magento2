<?php
	require('../config.php');
	@session_start();

if(isset($_GET['action']) && $_GET['action']=='sent_payment')
{
	$userid = mysqli_real_escape_string($con,$_GET['userid']);
	$amount = mysqli_real_escape_string($con,$_GET['amount']);
	
	$date = date("Y-m-d");
	
	$query = mysqli_query($con,"insert into income_received(`user_id`, `amount`, `date`) value('$userid', '$amount', '$date')");
	
	$query1 = mysqli_query($con,"update income set current_bal=0 where user_id='$userid'");
	if($query1)
	{
	$_SESSION['send_payment']="Successfully Sent Payment";
	header('location:../income-history.php');
	}
}
?>
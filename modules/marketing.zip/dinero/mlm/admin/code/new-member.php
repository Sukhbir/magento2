<?php

require('../config.php');
@session_start();

if(isset($_POST['addnew_member']))
{
	@session_start();
	$userid = mysqli_real_escape_string($con,$_POST['sponsor']);
	$capping = 4000;


	$getusernumber=mysqli_query($con,"select * from member order by id desc");
	$getusernumberrow=mysqli_fetch_array($getusernumber);

	$lastuname=$getusernumberrow['uname'];
	$cutssc=substr($lastuname,3);
	$getnumber=str_pad($cutssc + 1, 6, 0, STR_PAD_LEFT);
	$uname = "SSC".$getnumber;

	strtoupper($uname);
	
	$side='';
/*	$pin = mysqli_real_escape_string($con,$_POST['e_pin']);*/
	$fname = mysqli_real_escape_string($con,$_POST['fname']);
	$lname = mysqli_real_escape_string($con,$_POST['lname']);
	$email = mysqli_real_escape_string($con,$_POST['email']);
	$mobile = mysqli_real_escape_string($con,$_POST['mobile_number']);
	$enrollment_fee = mysqli_real_escape_string($con,$_POST['enrollment_fee']);
	$under_userid = mysqli_real_escape_string($con,$_POST['sponsor']);
	$side = mysqli_real_escape_string($con,$_POST['position']);
	$password = mysqli_real_escape_string($con,$_POST['password']);;
	
	$flag = 0;
	
	if($fname!='' && $lname!='' && $uname!='' && $email!='' && $mobile!='' && $enrollment_fee!='' && $password!='' && $under_userid!='' && $side!=''){
		//User filled all the fields.
			//Pin is ok
			if(email_check($email)){
				//Email is ok
				if(!email_check($under_userid)){
					//Under userid is ok
					if(side_check($under_userid,$side)){
						//Side check
						$flag=1;
					}
					else{
						$_SESSION['errors']="The side you selected is not available.";
						header('location:../new-member.php');
					}
				}
				else{
					//check under userid
					$_SESSION['errors']="Invalid Under userid.";
					header('location:../new-member.php');
				}
			}
			else{
				//check email
				$_SESSION['errors']="This user id already availble.";
				header('location:../new-member.php');
			}
	}
	else{
		//check all fields are fill
		$_SESSION['errors']="Please fill all the fields.";
		header('location:../new-member.php');
	}
	
	//Now we are heree
	//It means all the information is correct
	//Now we will save all the information
	if($flag==1){

		$date=date('Y-m-d h:i:s');
	
		//Insert into User profile
		$query = mysqli_query($con,"insert into member values('0','$fname','$lname','$uname','$email','$mobile','$enrollment_fee','$under_userid','$side','$password','1','user','$date')");
		
		if($query)
		{

		//Insert into Tree
		//So that later on we can view tree.
		$query = mysqli_query($con,"insert into tree(`user_id`) values('$uname')");

		//Insert to side
		$query = mysqli_query($con,"update tree set `$side`='$uname' where user_id='$under_userid'");

		$chkuserbinary=mysqli_query($con,"select * from tree where `user_id`='$under_userid' and `left`!='' AND `right`!=''") or die ("Error : ".mysqli_error($con));
		
		$commission=0;
		if(mysqli_num_rows($chkuserbinary)==1)
		{
				$getlastautotreeparent=mysqli_query($con,"select * from tree_2 order by id desc");
				$getlastautotreeparentrow=mysqli_fetch_array($getlastautotreeparent);
				$getlastparent=$getlastautotreeparentrow['parent_id'];
				
				$getcount=mysqli_query($con,"select * from tree_2 where parent_id='$getlastparent' order by id desc");

			if(mysqli_num_rows($getcount)<=9)
			{		
					$getparentbalance=mysqli_query($con,"select * from tree_2 where user_id='$getlastparent' order by id desc") or die ("Error ".mysqli_error($con));

					$parentcomminssionrow=mysqli_fetch_array($getparentbalance);
					$parentcomminssion=$parentcomminssionrow['amount'];
					$grantparent=$parentcomminssionrow['parent_id'];

					$parent=$getlastparent;
					$commission=$parentcomminssion+50;

					$insert=mysqli_query($con,"insert into tree_2 values(0,'$under_userid','$parent','0')");
					
					$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$parent'") or die ("Error ".mysqli_error($con));

					$updatebalance=1;
					while($updatebalance==1)
					{
							$grandparentsql=mysqli_query($con,"select * from tree_2 where user_id='$grantparent' order by id desc") or die ("Error ".mysqli_error($con));
							if(mysqli_num_rows($grandparentsql)==1)
							{
								$grandparentrow=mysqli_fetch_array($grandparentsql);

								$commission=$grandparentrow['amount'];

								$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$grantparent'") or die ("Error ".mysqli_error($con));

								$grantparent=$grandparentrow['parent_id'];
								
								if($grantparent=='')
								{
						
									$updatebalance=0;
								}
							}
					}

					echo "meifhu";
					echo $parent;
					echo "com".$updatecom;
			}
			else
			{
					$cutparent=substr($getlastparent,3);
					$getnumber=str_pad($cutparent + 1, 6, 0, STR_PAD_LEFT);
					$parent = "SSC".$getnumber;
					$commission=50;

					$insert=mysqli_query($con,"insert into tree_2 values(0,'$under_userid','$parent','0')");
					$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$parent'") or die ("Error ".mysqli_error($con));

					echo "else";
					echo $parent;
					echo "elsecom".$updatecom;
			}

		}

		//insert E-wallet
		$query = mysqli_query($con,"insert into e_wallet(`user_id`) values('$uname')");
		
		//Update pin status to close
//		$query = mysqli_query($con,"update e_pin set status='1' where e_pin='$pin'");
		
		//Inset into Icome
		$query = mysqli_query($con,"insert into income (`user_id`) values('$uname')");
		echo mysqli_error($con);
		//This is the main part to join a user\
		//If you will do any mistake here. Then the site will not work.
		
		//Update count and Income.
		$temp_under_userid = $under_userid;
		$temp_side_count = $side.'count'; //leftcount or rightcount
		
		$temp_side = $side;
		$total_count=1;
		$i=1;
		while($total_count>0){
			$i;
			$q = mysqli_query($con,"select * from tree where user_id='$temp_under_userid'");
			$r = mysqli_fetch_array($q);
			$current_temp_side_count = $r[$temp_side_count]+1;
			$temp_under_userid;
			$temp_side_count;
			mysqli_query($con,"update tree set `$temp_side_count`=$current_temp_side_count where user_id='$temp_under_userid'");
			
			//income
			if($temp_under_userid!=""){
				$income_data = income($temp_under_userid);
				//check capping
				//$income_data['day_bal'];
				if($income_data['day_bal']<$capping){
					$tree_data = tree($temp_under_userid);
					
					//check leftplusright
					//$tree_data['leftcount'];
					//$tree_data['rightcount'];
					//$leftplusright;
					
					$temp_left_count = $tree_data['leftcount'];
					$temp_right_count = $tree_data['rightcount'];
					//Both left and right side should at least 1 user
					if($temp_left_count>0 && $temp_right_count>0){
						if($temp_side=='left'){
							$temp_left_count;
							$temp_right_count;
							if($temp_left_count<=$temp_right_count){
								
								$new_day_bal = $income_data['day_bal']+800;
								$new_current_bal = $income_data['current_bal']+800;
								$new_total_bal = $income_data['total_bal']+800;
								
								//update income
								mysqli_query($con,"update income set day_bal='$new_day_bal', current_bal='$new_current_bal', total_bal='$new_total_bal' where user_id='$temp_under_userid' limit 1");	
							
							}
						}
						else{
							if($temp_right_count<=$temp_left_count){
						
								$new_day_bal = $income_data['day_bal']+800;
								$new_current_bal = $income_data['current_bal']+800;
								$new_total_bal = $income_data['total_bal']+800;
								$temp_under_userid;
								//update income
								if(mysqli_query($con,"update income set day_bal='$new_day_bal', current_bal='$new_current_bal', total_bal='$new_total_bal' where user_id='$temp_under_userid'")){
									
								}
							}
						}
					}//Both left and right side should at least 1 user
					
				}
				//change under_userid
				$next_under_userid = getUnderId($temp_under_userid);
				$temp_side = getUnderIdPlace($temp_under_userid);
				$temp_side_count = $temp_side.'count';
				$temp_under_userid = $next_under_userid;	
				
				$i++;
			}
			
			//Chaeck for the last user
			if($temp_under_userid==""){
				$total_count=0;
			}
			
		}//Loop
				
		echo mysqli_error($con);
		
		$_SESSION['user_action']="Successfully Added New Member";
		
/*		$to=$mobile;
		$msg="Thank you for registering. Login URL: http://sakarsales.com/mlm %0A %0A Username: ".$uname." %0A Password: ".$password;

        $url ="http://sms.technoguideinfo.com/API/WebSMS/Http/v1.0a/index.php?username=switchkey&password=switchkey@123&sender=JETHVA&to=".$to."&message=".$msg."&route_id=17";

        $ch = curl_init();
        curl_setopt ($ch,CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_HEADER, false);
        $ress = curl_exec($ch);
        curl_close($ch);*/
        
        $to = $email;
        $subject = "Thank you for registering";

        $message = "
            <html>
            <head>
            <title>Thank you for registering.</title>
            <style>
            #customers {
                font-family: 'Trebuchet MS', Arial, Helvetica, sans-serif;
                border-collapse: collapse;
                width: 100%;
            }
            
            #customers td, #customers th {
                border: 1px solid #ddd;
                padding: 8px;
            }
            
            #customers tr:nth-child(even){background-color: #f2f2f2;}
            
            #customers tr:hover {background-color: #ddd;}
            
            #customers th {
                padding-top: 12px;
                padding-bottom: 12px;
                text-align: left;
                background-color: #1E1E1E;
                color: white;
            }
            </style>
            </head>
            <body>
            
            <table id='customers'>
              <tr>
                <th colspan='2' align='center'><img src='http://www.sakarsales.com/wp-content/uploads/2018/09/oie_10134230RvLFfRw5.png'></th>
              </tr>
              <tr>
                <th colspan='2'align='center'>Thank you for registering.</th>
              </tr>
              <tr>
                <td>Login Url</td>
                <td>http://sakarsales.com/mlm</td>
              </tr>
              <tr>
                <td>Username</td>
                <td>".$uname."</td>
              </tr>
              
              <tr>
                <td>Password</td>
                <td>".$password."</td>
              </tr>
            
            </table>
            </body>
            </html>
            ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <info@sakarsales.com>' . "\r\n";

        mail($to,$subject,$message,$headers);
        
		//header('location:../members.php');
		exit();
		}
		else
		{
			$_SESSION['errors']='Something went wrong.';
			header('location:../new-member.php');
		}
	}
}
?><!--/join user-->
<?php 
//functions
function pin_check($pin){
	global $con,$userid;
	
	$query =mysqli_query($con,"select * from e_pin where e_pin='$pin' and user_id='$userid' and status='0'");
	if(mysqli_num_rows($query)>0){
		return true;
	}
	else{
		return false;
	}
}
function email_check($uname){
	global $con;
	
	$query =mysqli_query($con,"select * from member where uname='$uname'");
	if(mysqli_num_rows($query)>0){
		return false;
	}
	else{
		return true;
	}
}
function side_check($uname,$side){
	global $con;
	
	$query =mysqli_query($con,"select * from tree where user_id='$uname'");
	$result = mysqli_fetch_array($query);
	$side_value = $result[$side];
	if($side_value==''){
		return true;
	}
	else{
		return false;
	}
}
function income($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from income where user_id='$userid'");
	$result = mysqli_fetch_array($query);
	$data['day_bal'] = $result['day_bal'];
	$data['current_bal'] = $result['current_bal'];
	$data['total_bal'] = $result['total_bal'];
	
	return $data;
}
function tree($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from tree where user_id='$userid'");
	$result = mysqli_fetch_array($query);
	$data['left'] = $result['left'];
	$data['right'] = $result['right'];
	$data['leftcount'] = $result['leftcount'];
	$data['rightcount'] = $result['rightcount'];
	
	return $data;
}
function getUnderId($userid){
	global $con;
	$query = mysqli_query($con,"select * from member where uname='$userid'");
	$result = mysqli_fetch_array($query);
	return $result['sponsor'];
}
function getUnderIdPlace($userid){
	global $con;
	$query = mysqli_query($con,"select * from member where uname='$userid'");
	$result = mysqli_fetch_array($query);
	return $result['position'];
}
?>
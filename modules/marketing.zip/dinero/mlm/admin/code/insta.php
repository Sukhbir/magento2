<?php
        $url ="http://www.sakarsales.com/mlm/admin/login.php";

        $ch = curl_init();
        curl_setopt ($ch,CURLOPT_URL, $url);
        $response=curl_exec($ch);
        curl_close($ch);
        echo $response;

        echo "1";
?>
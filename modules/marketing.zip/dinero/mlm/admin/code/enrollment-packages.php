<?php
	require('../config.php');
	@session_start();

	if(isset($_POST['addnew']))
	{
		$title= $_POST['enrollment_title'];
		$price= $_POST['enrollment_price'];

		$sql = "insert into enrollment_pack values('0','$title','$price')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['enrollment_action']="Successfully Added New Enrollment Packages";
			header('location:../manage-enrollment-packages.php');
		}
	}

	if(isset($_POST['edit']))
	{

		$id= $_POST['id'];
		$title= $_POST['enrollment_title'];
		$price= $_POST['enrollment_price'];

		$sql = "UPDATE enrollment_pack SET enrollment_title='$title',enrollment_price='$price' WHERE id='$id'";
		$res = $con->query($sql) or die("error : ".mysqli_error($con));
		if ($res==1)
		{
			$_SESSION['enrollment_action']="Successfully Edited Enrollment Packages";
			header('location:../manage-enrollment-packages.php');
		}
	}

	if($_GET['action']=='delete')
	{
		$id=$_GET['id'];

		$sql = "delete from enrollment_pack where id='$id'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['enrollment_action']="Successfully Deleted Enrollment Packages";
			header('location:../manage-enrollment-packages.php');
		}
	}
?>
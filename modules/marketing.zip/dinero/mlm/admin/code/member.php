<?php
	require('../config.php');
	@session_start();

	if(isset($_POST['login']))
	{
		$uname=$_POST['username'];
		$pwd=$_POST['password'];

		$sql = "SELECT * FROM admin WHERE username='$uname' AND password='$pwd'";
			
			$re = mysqli_query($con, $sql);
			if (mysqli_num_rows($re)) 
			{
				$_SESSION['adminlogin'] = $uname;
				header('location:../index.php');	
			}
			else
			{
				$_SESSION['invalidlogin'] = "Invalid Login Details";
				header('location:../login.php');
			}
	}

	if(isset($_POST['addnew_member']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$uname=$_POST['uname'];
		$email=$_POST['email'];
		$mobile_number=$_POST['mobile_number'];
		$enrollment_fee=$_POST['enrollment_fee'];
		$sponsor=$_POST['sponsor'];
		$position=$_POST['position'];
		$password=$_POST['password'];

		$date=date('Y-m-d h:i:s');

		$sql = "insert into member values('0','$fname','$lname','$uname','$email','$mobile_number','$enrollment_fee','$sponsor','$position','$password','1','user','$date')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['user_action']="Successfully Added New Member";
			header('location:../referred-members.php');
		}
	}

	if(isset($_GET['action']) && $_GET['action']=='cancel')
	{
		$userid=$_GET['user_id'];
		$sql="update member set status='2' where id='$userid'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['cancel_user']="Member Cancelled";
			header('location:../members.php');
		}
	}

	if(isset($_GET['action']) && $_GET['action']=='reactive')
	{
		$userid=$_GET['user_id'];
		$sql="update member set status='1' where id='$userid'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['cancel_user']="Successfully Re-Active Member";
			header('location:../members.php');
		}
	}

	if(isset($_GET['action']) && $_GET['action']=='block')
	{
		$userid=$_GET['user_id'];
		$sql="update member set status='3' where id='$userid'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['cancel_user']="Member Blocked";
			header('location:../members.php');
		}
	}

	if(isset($_GET['action']) && $_GET['action']=='unblock')
	{
		$userid=$_GET['user_id'];
		$sql="update member set status='1' where id='$userid'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['cancel_user']="Successfully Member Unblocked";
			header('location:../members.php');
		}
	}
?>
<?php
	include('config.php');
	$user_id='SSC000002';

	$i=1;
	$cutssc=000002;

	$commission=0;

	while($i<= 59)
	{
	
		$getnumber=str_pad($cutssc + 1, 6, 0, STR_PAD_LEFT);
		$user_id = "SSC".$getnumber;

		$parentnodesql=mysqli_query($con,"select * from tree_2 order by id desc") or die ("Error : ".mysqli_error($con));
		$parentnoderow=mysqli_fetch_array($parentnodesql);
		$parentcomminssion=$parentnoderow['2'];

		$chkparent=mysqli_query($con,"select * from tree_2 where parent_id='$parentcomminssion' order by id desc") or die ("Error : ".mysqli_error($con));

		if(mysqli_num_rows($chkparent)<10)
		{				

				$parent=$parentcomminssion;
				$commission=$commission+100;

				$insert=mysqli_query($con,"insert into tree_2 values(0,'$user_id','$parent','0')");
				$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$parent'");
		}
		else
		{
				$cutparent=substr($parentcomminssion,3);
				$getnumber=str_pad($cutparent + 1, 6, 0, STR_PAD_LEFT);
				$parent = "SSC".$getnumber;
				$commission=0;

				$insert=mysqli_query($con,"insert into tree_2 values(0,'$user_id','$parent','0')");
				$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$parent'");
		}


		$cutssc++;


/*	echo $i."<br>";
	
	
	$cutssc++;

	$parentnodesql=mysqli_query($con,"select * from tree_2 order by id desc") or die ("Error : ".mysqli_error($con));
	$parentnoderow=mysqli_fetch_array($parentnodesql);
	$parentcomminssion=$parentnoderow['2'];

	echo $parentcomminssion;

	$secondtree=mysqli_query($con,"select * from tree_2 where parent_id='$parentcomminssion'") or die ("Error : ".mysqli_error($con));


	if(mysqli_num_rows($secondtree)<10)
	{
			$inserttree=mysqli_query($con,"insert into tree_2 values(0,'$user_id','$parentcomminssion','0')")or die ("Error : ".mysqli_error($con));

			$chkamount=mysqli_query($con,"select * from tree_2 where user_id='$parentcomminssion'") or die ("Error : ".mysqli_error($con));

			$getamount=mysqli_fetch_array($chkamount);
			$newamount=$getamount['3']+100;

			$updateparentbal=mysqli_query($con,"update tree_2 set amount='$newamount' where user_id='$parentcomminssion'") or die ("Error : ".mysqli_error($con));
	}
	else
	{
				$cutssc=substr($parentcomminssion,3);
				$getnumber=str_pad($cutssc + 1, 6, 0, STR_PAD_LEFT);
				$uname = "SSC".$getnumber;

				strtoupper($uname);
				$inserttree=mysqli_query($con,"insert into tree_2 values(0,'$user_id','$uname','0')") or die ("Error : ".mysqli_error($con));

				$chkamount=mysqli_query($con,"select * from tree_2 where user_id='$uname'") or die ("Error : ".mysqli_error($con));

				$getamount=mysqli_fetch_array($chkamount);
				$newamount=$getamount['3']+100;

				$updateparentbal=mysqli_query($con,"update tree_2 set amount='$newamount' where user_id='$uname'") or die ("Error : ".mysqli_error($con));			
	}
*/
		$i++;
	}
?>
<?php include('header.php');

	if(isset($_GET['search']))
	{
		$search=$_GET['search'];
	}
	else
	{
		$search='SSC000001';
	}

	$parentnodesql=mysqli_query($con,"select * from tree_2 where user_id='$search' order by id desc") or die ("Error : ".mysqli_error($con));

	$parentnoderow=mysqli_fetch_array($parentnodesql);
	$parentcomminssion=$parentnoderow['3'];

	$secondtree=mysqli_query($con,"select * from tree_2 where parent_id='$search'") or die ("Error : ".mysqli_error($con));

	$i=0;
	while($secondtreerows=mysqli_fetch_array($secondtree))
	{
			$secondtreearray[$i]=$secondtreerows['1'];
			$secondtreecommision[$i]=$secondtreerows['3'];

			$i++;
	}

?>


<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Income Tree </h1>
                    </div>
                </div>
            </div>
            <!-- <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div> -->
        </div>

		<div class="col-sm-12">
            <div class="alert  alert-warning alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-warning">Abbreviations</span>  <br />   
                		C = Commission <br />
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
        
        <div class="col-lg-3">
        	<form action="">
            <div class="row form-group">
            	<div class="col col-md-12">
                	<div class="input-group">
                        <input type="text" id="search" name="search" placeholder="Search User" class="form-control">
                        <div class="input-group-btn"><button class="btn btn-primary"><i class="fa fa-search"></i></button></div>
                       	</div>
                </div>
            </div>
            </form>
        </div>

		<div class="card-body">

<style type="text/css">

	.treetext
	{
		background-color: #FFF;
		border: 1px solid gray; 
		width: auto;
		max-width: 170px;
		border-radius: 1em;
		padding: 10px;
		margin: 0 10px 0 10px;
		text-align: center;
	}
	.treetextlast
	{
		background-color: #FFF;
		border: 1px solid gray; 
		width: auto;
		max-width: 50px;
		border-radius: 1em;
		padding: 10px;
		margin: 0 10px 0 10px;
		text-align: center;
		word-wrap: break-word;
	}
	.treeborder
	{
	 	border-right: 1px solid gray;
	 	height: 1em;
	}
	.treeborderleft
	{
		border-left:  1px solid gray;
		height: 1em;
	}
	.treeleftborder
	{
		border-top: 1px solid gray;
	 	border-left: 1px solid gray;
	 	height: 1em;
	}
	.treerightborder
	{
		border-top: 1px solid gray;
	 	border-right: 1px solid gray;
	 	height: 1em;	
	}
	.treetopborder
	{
		border-top: 1px solid gray;
	 	border-left: 1px solid gray;
	 	height: 1em;
	}
	.treetoprightborder
	{
		border-top: 1px solid gray;
		border-right: 1px solid gray;
		height: 1em;
	}
	p
	{
		margin: 0 auto !important;
		padding: 0 !important;
	}
	table
	{
		border-color: #fff;
		border: solid 0px;
	}

</style>

<div class="table-responsive">
<table border="1">
	<tr>
		<td colspan="20" align="center"> 
			<div class="treetext"><i class="fa fa-user fa-2x" style="color:#1E84AD"></i>
			<p><?php echo $search; ?></p>
			<p>C : <?php echo $parentcomminssion; ?></p>
			</div>
		</td>
	</tr>

	<tr>
		<td colspan="10" class="treeborder"></td>
		<td colspan="10"></td>
	</tr>

	<tr>
		<td></td>
		<td colspan="2"><div class="treetopborder"></div></td>		
		<td colspan="2"><div class="treetopborder"></div></td>
		<td colspan="2"><div class="treetopborder"></div></td>
		<td colspan="2"><div class="treetopborder"></div></td>

		<td><div class="treetopborder"></div></td> 
		<td><div class="treetoprightborder"></div></td>
 		
 		<td colspan="2"><div class="treetoprightborder"></div></td>
		<td colspan="2"><div class="treetoprightborder"></div></td>
 		<td colspan="2"><div class="treetoprightborder"></div></td>
 		<td colspan="2"><div class="treetoprightborder"></div></td>
 		<td></td>
	</tr>

	<tr>
		
		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[0])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[0]; ?>">

							<p><?php echo $secondtreearray[0]; ?></p>
							<p>C : <?php echo $secondtreecommision[0]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[1])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[1]; ?>">
								<p><?php echo $secondtreearray[1]; ?></p>
								<p>C : <?php echo $secondtreecommision[1]; ?></p>
							</a>

				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>		

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[2])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[2]; ?>">
								<p><?php echo $secondtreearray[2]; ?></p>
								<p>C : <?php echo $secondtreecommision[2]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[3])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[3]; ?>">
								<p><?php echo $secondtreearray[3]; ?></p>
								<p>C : <?php echo $secondtreecommision[3]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[4])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[4]; ?>">
								<p><?php echo $secondtreearray[4]; ?></p>
								<p>C : <?php echo $secondtreecommision[4]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[5])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[5]; ?>">
								<p><?php echo $secondtreearray[5]; ?></p>
								<p>C : <?php echo $secondtreecommision[5]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[6])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[6]; ?>">
								<p><?php echo $secondtreearray[6]; ?></p>
								<p>C : <?php echo $secondtreecommision[6]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[7])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[7]; ?>">
								<p><?php echo $secondtreearray[7]; ?></p>
								<p>C : <?php echo $secondtreecommision[7]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[8])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[8]; ?>">
								<p><?php echo $secondtreearray[8]; ?></p>
								<p>C : <?php echo $secondtreecommision[8]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

		<td colspan="2">
			<div class="treetext">
				
				<?php 

					if(isset($secondtreearray[9])) 
					{				
				?>
							<i class="fa fa-user fa-2x" style="color:#272C33"></i>
							<a href="?search=<?php echo $secondtreearray[9]; ?>">
								<p><?php echo $secondtreearray[9]; ?></p>
								<p>Com : <?php echo $secondtreecommision[9]; ?></p>
							</a>
				<?php
					}
					else
					{
				?>
							<i class="fa fa-plus fa-2x" style="color:#272C33"></i>
							<p></p>
				<?php
					}
				?>
			</div>
		</td>

	</tr>
</table>
</div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

</div><!-- /#right-panel -->

<?php include('footer.php') ?>

    <!-- <script src="assets/js/lib/data-table/datatables.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/jszip.min.js"></script>
    <script src="assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="assets/js/lib/data-table/datatables-init.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
        } );
    </script> -->
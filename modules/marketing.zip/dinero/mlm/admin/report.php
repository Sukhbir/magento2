<?php include('header.php');

$yesterday=date('Y-m-d',strtotime("-1 days"));

if(isset($_GET['btn-daterenge']))
{
    $sdate=$_GET['sdate'];
    $edate=$_GET['edate'];

    $query = mysqli_query($con,"SELECT * FROM income_received WHERE `date` BETWEEN '$sdate' AND '$edate' order by id asc");
} 
else
{
    $query = mysqli_query($con,"SELECT * FROM income_received WHERE `date`='$yesterday' order by id asc");
}
?>
<!--     <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
    $('#bootstrap-data-table').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
        });
    });
    </script> -->

<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Report</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                </div>
            </div>
        </div>

        <?php
        if(isset($_SESSION['send_payment']))
        {
        ?>
        <div class="breadcrumbs bg-success">
            <div>
                <div class="page-header text-center text-white bg-success">
                    <div class="page-title">
                        <h1><?php echo $_SESSION['send_payment']; ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <?php
        unset($_SESSION['send_payment']);
        }
        ?>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <form method='get' action='' class='form-inline mb-2'><label class="form-lable">Start Date : </label><input type='date' name='sdate' class='form-control' value='<?php echo $yesterday; ?>'><label class="form-lable">End Date : </label><input class='form-control' type='date' name='edate' value='<?php echo $yesterday; ?>'><button type='submit' name='btn-daterenge' class='form-control btn btn-primary'><i class="fa fa-search"> </i> Search</button></form>
                        <div class="card">
                        <div class="card-body table-responsive">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Name</th></th>
                                        <th>Userid</th>
                                        <th>Mobile Nos.</th>
                                        <th>Pan Card</th>
                                        <th>A/C Holder Name</th>
                                        <th>A/C Holder No</th>
                                        <th>Bank Name</th>
                                        <th>IFSC Code</th>
                                        <th>Address</th>
                                        <th>Amount</th>
                                        <th>TDS</th>
                                        <th>Admin Charge</th>
                                        <th>Final Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    if(mysqli_num_rows($query)>0){
                                        $i=1;
                                        while($row=mysqli_fetch_array($query)){
                                        
                                        $userid=$row['user_id'];
                                        $bankdetail=mysqli_query($con,"select * from bank where user_id='$userid'");
                                        
                                        $bankrow=mysqli_fetch_array($bankdetail);
                                        
                                        $userdetail=mysqli_query($con,"select * from member where uname='$userid'");
                                        
                                        $userrow=mysqli_fetch_array($userdetail);
                                        
                                        ?>
                                            <tr>
                                                <td><?php echo $i; ?></td>
                                                <td> <div style="width: 90px !important;"><?php $date=$row['date']; echo date("d-m-Y", strtotime($date)); ?></div></td>
                                                <td><?php echo $row['fname'].' '.$row['lname']; ?></td>
                                                <td><?php echo $row['user_id']; ?></td>
                                                <td><?php echo $row['mobile_number']; ?></td>
                                                <td><?php echo $bankrow['pan_no']; ?></td>
                                                <td><?php echo $bankrow['name']; ?></td>
                                                <td><?php echo $bankrow['account_no']; ?></td>
                                                <td><?php echo $bankrow['bank_name']; ?></td>
                                                <td><?php echo $bankrow['ifsc']; ?></td>
                                                <td><?php echo $bankrow['address']; ?></td>
                                                <td><i class="fa fa-rupee"></i> <?php echo $row['balance']; ?></td>
                                                <td><i class="fa fa-rupee"></i> <?php $admincharge=$row['balance']*5; $admincharge=$admincharge/100; echo $admincharge;  ?></td>
                                                <td><i class="fa fa-rupee"></i> <?php $tds=$row['balance']*5; $tds=$tds/100; echo $tds; ?></td>
                                                <td><i class="fa fa-rupee"></i> <?php $finalamount=$row['balance']-$admincharge-$tds; echo $finalamount; ?></td>
                                            </tr>
                                        <?php
                                            $i++;
                                        }
                                    }
                                    else{
                                    ?>
                                        <tr>
                                            <td colspan="9">No Payment History</td>
                                        </tr>
                                    <?php
                                    }
                                ?>
                                </tbody>

                        </table>
                     </div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

</div><!-- /#right-panel -->


                  
<?php include('footer.php') ?>
<?php
$con=mysqli_connect('localhost','sakarsal_mlm','SKS@ss2018','sakarsal_mlm');
if(!$con)
{
	echo "database connection fail";
}
?>
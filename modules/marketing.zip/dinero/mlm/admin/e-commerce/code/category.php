<?php
	require('../config.php');
	@session_start();

	if(isset($_POST['addnew_category']))
	{
		$categoryname= $_POST['categoryname'];

		$sql = "insert into ec_category values('0','$categoryname')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['category_action']="Successfully Added New Category";
			header('location:../category-view.php');
		}
	}

	if(isset($_POST['edit_category']))
	{
		$categoryname= $_POST['categoryname'];
		$id=$_POST['id'];

		$sql = "update ec_category set category='$categoryname' where id='$id'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['category_action']="Successfully Edit Category";
			header('location:../category-view.php');
		}
	}

	if(isset($_GET['action']) && $_GET['action']=='deletecategory')
	{
		$id=$_GET['id'];

		$sql = "delete from ec_category where id='$id'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['category_action']="Successfully Deleted Category";
			header('location:../category-view.php');
		}
	}

?>
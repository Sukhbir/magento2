<?php
$con=mysqli_connect('localhost','hbfhsjaj_mlm','ConicP@2018','hbfhsjaj_mlm');
if(!$con)
{
	echo "database connection fail";
}
?>
<?php include('header.php'); ?>
                  <div class="col-lg-6">
                    <div class="card">
                      <div class="card-header">Add Bank Account</div>
                      <div class="card-body card-block">
                        <form action="code/bank.php" method="post" class="">

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-home"></i></div>
                              <textarea id="address" name="address" placeholder="Enter Your Address" class="form-control"></textarea>
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="aadhar_no" name="aadhar_no" placeholder="Enter Aadhar Card Nos." class="form-control">
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="pan_no" name="pan_no" placeholder="Enter Pan Nos." class="form-control">
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="account_name" name="account_name" placeholder="Enter Account Holder Name" class="form-control">
                            </div>
                          </div>
						              
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-bank"></i></div>
                              <input type="text" id="account_no" name="account_no" placeholder="Enter Account Number" class="form-control">
                            </div>
                          </div>
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-bank"></i></div>
                              <input type="text" id="bank_name" name="bank_name" placeholder="Bank Name" class="form-control">
                            </div>
                          </div>

						              <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-hashtag"></i></div>
                              <input type="text" id="ifsc" name="ifsc" placeholder="Enter Bank IFSC Code" class="form-control">
                            </div>
                          </div>

                          <div class="form-actions form-group"><button name="add_bank_details" type="submit" class="btn btn-success"><i class="fa fa-plus"></i> Add Bank Details</button></div>
                        </form>
                      </div>
                    </div>
                  </div>
<?php include('footer.php') ?>
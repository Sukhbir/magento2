<?php
namespace Category\Attribute\Setup;

use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Setup\EavSetupFactory;

class InstallData implements InstallDataInterface
{

	private $eavSetupFactory;

	public function __construct(EavSetupFactory $eavSetupFactory)
	{
		$this->eavSetupFactory = $eavSetupFactory;
	}

	public function install(
		ModuleDataSetupInterface $setup,
		ModuleContextInterface $context
	)
	{
		$eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

		$eavSetup->addAttribute(
			\Magento\Catalog\Model\Category::ENTITY,
			'cat_link_attribute',
			[
                        'type' => 'varchar',
		      	'label' => 'Category Link Text',
		      	'input' => 'text',
		      	'source' => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
		      	'required' => false,
		      	'sort_order' => 100,
		      	'global' => 1,
		      	'group' => '',
		      	'user_defined' => false,
				'default'      => null,
				'group'        => '',
				'backend'      => ''
			]
		);
	}
}
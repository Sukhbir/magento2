<?php
	require('../config.php');
	@session_start();

	if(isset($_POST['addnew_e_pin_values']))
	{
		$epinvalue= $_POST['epinvalue'];

		$sql = "insert into e_pin_setting values('0','$epinvalue')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['e_pin_action']="Successfully Added New E-pin values";
			header('location:../e-pin-setting.php');
		}
	}

	if(isset($_GET['action']) && $_GET['action']=='delete')
	{
		$id=$_GET['id'];

		$sql = "delete from e_pin_setting where id='$id'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['e_pin_action']="Successfully Deleted E-Pin Values";
			header('location:../e-pin-setting.php');
		}
	}

	if(isset($_POST['addnew_e_pin']))
	{

		$user_id=$_SESSION['userlogin'];
		$epinvalue= $_POST['epinvalue'];		
		date_default_timezone_set('Asia/Kolkata');
		$date=date('Y-m-d');

		$e_wallet_sql="select * from e_wallet where user_id='$user_id'";
		$e_wallet_res = mysqli_query($con, $e_wallet_sql) or die("error : ".mysqli_error($con));

		$e_wallet_fund=mysqli_fetch_array($e_wallet_res);

		$bal=$e_wallet_fund['current_bal'];
		if($bal>=$epinvalue)
		{

		$sql = "insert into e_pin_request values('0','$user_id','$epinvalue','$date','0')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$newbal=$bal-$epinvalue;

			$newupdateewallet=mysqli_query($con,"update e_wallet set current_bal='$newbal' where user_id='$user_id'");
			
			$addepintrans=mysqli_query($con,"insert into e_wallet_transactions values('0','$user_id','$date','$epinvalue','debit','You Requested New E-Pin')");

			$_SESSION['new_e_pin_request']="Successfully Requsted New E-pin";
			header('location:../e-pin-request.php');
		}
		}
		else
		{
			$_SESSION['new_e_pin_request']="You have Insufficient E-Wallet Balance";
			header('location:../add-new-e-pin.php');	
		}
	}
?>
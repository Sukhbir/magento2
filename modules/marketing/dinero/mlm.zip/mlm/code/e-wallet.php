<?php
include('../config.php');
@session_start();
$userid=$_SESSION['userlogin'];
if (isset($_POST['deposit_fund'])) 
{
		$fund= $_POST['fund'];
		$date=date('Y-m-d');
		$remark="You Added Fund in E-Wallet";

		$e_wallet_sql="select * from e_wallet where user_id='$userid'";
		$e_wallet_res = mysqli_query($con, $e_wallet_sql) or die("error : ".mysqli_error($con));
		$e_wallet_fund=mysqli_fetch_array($e_wallet_res);

		$ufund=$fund+$e_wallet_fund['current_bal'];
		
		$e_wallet_update="update e_wallet set current_bal='$ufund' where user_id='$userid'";
		$e_wallet_update_res = mysqli_query($con, $e_wallet_update) or die("error : ".mysqli_error($con));
		if($e_wallet_update_res)
		{

		$sql = "insert into e_wallet_transactions values('0','$userid','$date','$fund','credit','
		$remark')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['deposit_fund']="Successfully Added New E-pin values";
			header('location:../e-wallet-transactions.php');
		}

		}	
}
if (isset($_POST['e_wallet_transfer'])) 
{
	$username=$_POST['username'];
	$amount=$_POST['amount'];
	$date=date('Y-m-d');

	$chk_user_sql="select * from member where uname='$username'";
	$chk_user_res = mysqli_query($con, $chk_user_sql) or die("error : ".mysqli_error($con));
	if(mysqli_num_rows($chk_user_res)==1)
	{
		$e_wallet_sql="select * from e_wallet where user_id='$userid'";
		$e_wallet_res = mysqli_query($con, $e_wallet_sql) or die("error : ".mysqli_error($con));
		$e_wallet_fund=mysqli_fetch_array($e_wallet_res);
		$e_wallet=$e_wallet_fund['current_bal'];

		if($e_wallet>=$amount)
		{
			$e_wallet=$e_wallet-$amount;
			
			$e_wallet_update="update e_wallet set current_bal='$e_wallet' where user_id='$userid'";
			$e_wallet_update_res = mysqli_query($con, $e_wallet_update) or die("error : ".mysqli_error($con));
			if($e_wallet_update_res)
			{	

				$remark='You Transfer Fund to '.$username;

				$sql = "insert into e_wallet_transactions values('0','$userid','$date','$amount','debit','$remark')";
				$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
			

				$e_wallet1_sql="select * from e_wallet where user_id='$username'";
				$e_wallet1_res = mysqli_query($con, $e_wallet1_sql) or die("error : ".mysqli_error($con));
				$e_wallet_row=mysqli_fetch_array($e_wallet1_res);
		
				$e_wallet1=$e_wallet_row['current_bal'];	
				$e_wallet1=$e_wallet1+$amount;

				$e_wallet_update1="update e_wallet set current_bal='$e_wallet1' where user_id='$username'";
				$e_wallet_update_res1 = mysqli_query($con, $e_wallet_update1) or die("error : ".mysqli_error($con));
				if($e_wallet_update_res1)
				{	

					$remark='You Got Fund from '.$userid;
					$sql1 = "insert into e_wallet_transactions values('0','$username','$date','$amount','credit','$remark')";
					$res1 = mysqli_query($con, $sql1) or die("error : ".mysqli_error($con));
					{
						$_SESSION['deposit_fund']="Successfully Transfer Fund to ".$username;
						header('location:../e-wallet-transactions.php');	
					}
				}
			}
		}
		else
		{
			$_SESSION['e_wallet_transfer']='You have Insufficient E-Wallet Balance';
			header('location:../e-wallet-transfer-fund.php');
		}
	}
	else
	{
		$_SESSION['e_wallet_transfer']='Invalid User Name';
		header('location:../e-wallet-transfer-fund.php');
	}
}
?>
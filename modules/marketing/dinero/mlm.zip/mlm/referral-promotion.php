<?php include('header.php') ?>
        
		<div class="col-lg-12">
          <div class="card">
		  <div class="card-body card-block">
          
                                <div class="card-body">
                                    
                                        <h3>Referral Links</h3>
                                        <p>Please Use the Below Links To add members To Your Network </p>
                                        
                                </div>
								
                            </div>
							</div>
							</div>		
		
		<div class="col-lg-12">
          <div class="card">
		  <div class="card-body card-block">
          
                                <div class="card-body">
                                    
                                        <h3>Left Joining Links</h3>
                                        <p>localhost:8080/mml/new-member?ref=<?php echo $_SESSION['userlogin']; ?>?position=left</p>

										<button type="button" style="float:right" class="btn btn-primary mb-6">Copy Link</button>      
                                </div>
								
                            </div>
							</div>
							</div>		
					

		<div class="col-lg-12">
          <div class="card">
		  <div class="card-body card-block">
          
                                <div class="card-body">
                                    
                                        <h3>Right Joining Links</h3>
                                        <p>localhost:8080/mml/new-member?ref=<?php echo $_SESSION['userlogin']; ?>?position=right<p>
                                        <button type="button" style="float:right" class="btn btn-primary mb-6">Copy Link</button>      
                                </div>
								
                            </div>
							</div>
							</div>		
		
   
<?php include('footer.php') ?>

    <!-- <script src="assets/js/lib/data-table/datatables.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/jszip.min.js"></script>
    <script src="assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="assets/js/lib/data-table/datatables-init.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
        } );
    </script> -->
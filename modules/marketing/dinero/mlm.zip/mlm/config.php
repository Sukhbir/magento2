<?php
$con=mysqli_connect('localhost','root','','mlm');
if(!$con)
{
	echo "database connection fail";
}
?>
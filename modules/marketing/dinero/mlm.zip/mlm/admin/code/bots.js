$(document).ready(function(){
   
//   alert('hiii');
	
    $("#user_action").change(function(){
        
        $status=$('#user_action :selected').val();
        $username=$(this).parent('td').siblings('td').find('#user_id').val();


        $.ajax({
  			url: "8x-kill-shot/bots.php",
  			type:"POST",
  			data:{
  					action:'update_status',
  					username:$username,
  					status:$status
  				},
  			cache: false,
  			success: function(html)
  			{
    			if(html!='1')
    			{
    				alert('User status not updated');
    			}
  			}
		});

    });
});
<?php
	require('../config.php');
	@session_start();

	if(isset($_POST['addnew_franchases']))
	{
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$uname=$_POST['uname'];
		$email=$_POST['email'];
		$mobile_number=$_POST['mobile_number'];
		$enrollment_fee=$_POST['enrollment_fee'];
		$password=$_POST['password'];

		$date=date('Y-m-d h:i:s');

		$sql = "insert into member values('0','$fname','$lname','$uname','$email','$mobile_number','$enrollment_fee','','','$password','1','franchase','$date')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$query = mysqli_query($con,"insert into tree(`user_id`) values('$uname')");
			$query = mysqli_query($con,"insert into e_wallet(`user_id`) values('$uname')");
			$query = mysqli_query($con,"insert into income (`user_id`) values('$uname')");
			echo mysqli_error($con);

			$product_amount = 3000;

			$no_of_pin = $enrollment_fee/$product_amount;
			$i=1;

			while($no_of_pin>=$i)
			{	
				$e_pin = rand(1000000,9999999);

					$epinsql = "insert into e_pin values('0','$uname','$e_pin','0')";
					$epinres = mysqli_query($con, $epinsql) or die("error : ".mysqli_error($con));
				$i++;
			}

			$_SESSION['user_action']="Successfully Added New Franchase";
			header('location:../franchase-view.php');
		}
	}
?>
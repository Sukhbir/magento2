<?php

require('../config.php');
@session_start();

		$chkuserbinary=mysqli_query($con,"select * from tree where `left`!='' AND `right`!=''") or die ("Error : ".mysqli_error($con));
//insert-secord-tree
	$i=0;
		$commission=0;
		while($row=mysqli_fetch_array($chkuserbinary))
		{
			$under_userid=$row['user_id'];

				$getlastautotreeparent=mysqli_query($con,"select * from tree_2 order by id desc");
				$getlastautotreeparentrow=mysqli_fetch_array($getlastautotreeparent);
				$getlastparent=$getlastautotreeparentrow['parent_id'];
				
				if($getlastparent=='')
				{
					$getlastparent='SSC000001';
				}

				$getcount=mysqli_query($con,"select * from tree_2 where parent_id='$getlastparent' order by id desc");

			if(mysqli_num_rows($getcount)<=9)
			{		
					$getparentbalance=mysqli_query($con,"select * from tree_2 where user_id='$getlastparent' order by id desc") or die ("Error ".mysqli_error($con));

					$parentcomminssionrow=mysqli_fetch_array($getparentbalance);
					$parentcomminssion=$parentcomminssionrow['amount'];
					$grantparent=$parentcomminssionrow['parent_id'];

					$parent=$getlastparent;
					$commission=$parentcomminssion+50;

					if($i==0)
					{
						$parent='';
					}

					$insert=mysqli_query($con,"insert into tree_2 values(0,'$under_userid','$parent','0')");
					
					$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$parent'") or die ("Error ".mysqli_error($con));

					$updatebalance=1;
/*					while($updatebalance==1)
					{
							$grandparentsql=mysqli_query($con,"select * from tree_2 where user_id='$grantparent' order by id desc") or die ("Error ".mysqli_error($con));
							if(mysqli_num_rows($grandparentsql)==1)
							{
								$grandparentrow=mysqli_fetch_array($grandparentsql);

								$commission=$grandparentrow['amount'];

								$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$grantparent'") or die ("Error ".mysqli_error($con));

								$grantparent=$grandparentrow['parent_id'];
								
								if($grantparent=='')
								{
						
									$updatebalance=0;
								}
							}
					}*/

					echo "meifhu";
					echo $parent;
					echo "com".$updatecom;
			}
			else
			{
					$cutparent=substr($getlastparent,3);
					$getnumber=str_pad($cutparent + 1, 6, 0, STR_PAD_LEFT);
					$parent = "SSC".$getnumber;
					$commission=50;

					if($i==0)
					{
						$parent='';
					}

					$insert=mysqli_query($con,"insert into tree_2 values(0,'$under_userid','$parent','0')");
					$updatecom=mysqli_query($con,"update tree_2 set amount='$commission' where user_id='$parent'") or die ("Error ".mysqli_error($con));

					echo "else";
					echo $parent;
					echo "elsecom".$updatecom;
			}
			$i++;

		}
?>
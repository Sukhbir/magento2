<?php
	require('../config.php');
	@session_start();

	if(isset($_POST['addnew_e_pin_values']))
	{
		$epinvalue= $_POST['epinvalue'];

		$sql = "insert into e_pin_setting values('0','$epinvalue')";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['e_pin_action']="Successfully Added New E-pin values";
			header('location:../e-pin-setting.php');
		}
	}

	if($_GET['action']=='delete')
	{
		$id=$_GET['id'];

		$sql = "delete from e_pin_setting where id='$id'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{
			$_SESSION['e_pin_action']="Successfully Deleted E-Pin Values";
			header('location:../e-pin-setting.php');
		}
	}

	if($_GET['action']=='generate_e_pin')
	{
		$product_amount = 100;
		$id=$_GET['e_pin_request_id'];
		$sql = "select * from e_pin_request where id='$id'";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		$row=mysqli_fetch_array($res);

			$user_id=$row['user_id'];
			$amount=$row['amount'];

			$no_of_pin = $amount/$product_amount;
			$i=1;

			while($no_of_pin>=$i)
			{	
				$e_pin = rand(1000000,9999999);
				$chkepinsql = "select * from e_pin_request where id='$id' AND status='0'";
				$chkepinres = mysqli_query($con, $chkepinsql) or die("error : ".mysqli_error($con));
				if(mysqli_num_rows($chkepinres)>0)
				{
					mysqli_num_rows($chkepinres);
				
					$epinsql = "insert into e_pin values('0','$user_id','$e_pin','0')";
					$epinres = mysqli_query($con, $epinsql) or die("error : ".mysqli_error($con));
					if($res)
					{
					   $updateepinrequeststatussql="update e_pin_request set status='1' WHERE id='$id'";
        			    $updateepinrequeststatusres=mysqli_query($con,$updateepinrequeststatussql) or die("Error : ".mysqli_error($con));
					    
						$_SESSION['e_pin']="Successfully New E-pin Generated";
						header('location:../view-e-pin.php');
					}
					else
					{
					    echo "Error";
					}
				$i++;
				}
				else{
				    "Error";
				}
			} 
	}
?>
<?php include('header.php'); ?>

<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>View Product</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <?php
        if(isset($_SESSION['product_action']))
        {
        ?>
        <div class="breadcrumbs bg-success">
            <div>
                <div class="page-header text-center text-white bg-success">
                    <div class="page-title">
                        <h1><?php echo $_SESSION['product_action']; ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <?php
        unset($_SESSION['product_action']);
        }
        ?>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                        <div class="card-body table-responsive">
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><div style="width: 100px;">Name</div></th>
                                    <th><div style="width: 300px;">Description</div></th>
                                    <th><div style="width: 100px;">Category</div></th>
                                    <th><div style="width: 100px;">Images 1</div></th>
                                    <th><div style="width: 100px;">Images 2</div></th>
                                    <th><div style="width: 100px;">Images 3</div></th>
                                    <th><div style="width: 50px;">MRP</div></th>
                                    <th><div style="width: 50px;">Price</div></th>
                                </tr>
                            </thead>
                    
                            <tbody>
                                  <?php
                                  $sql = "SELECT * FROM ec_product order by id DESC";
                                  $re = mysqli_query($con, $sql) or die (mysqli_error($con));
                                  $i=1;
                                  $product_images='../../../products_images/';
                                  while ($row=mysqli_fetch_array($re))
                                    {
                                  ?>
                                    <tr>
                                        <td><?php echo $i ?></td>
                                        <td><div style="width: 100px; height: 100px;"><?php echo $row['1'] ?></div></td>
                                        <td><div style="width: 300px; height: 100px;"><?php echo substr($row['2'],0,150); ?></div></td>
                                        <td><div style="width: 100px; height: 100px;"><?php echo $row['3'] ?></div></td>
                                        <td><div style="width: 100px; height: 100px;"><img src="<?php echo $product_images.''.$row['4'] ?>"></div></td>
                                        <td><div style="width: 100px; height: 100px;"><img src="<?php echo $product_images.''.$row['5'] ?>"></td>
                                        <td><div style="width: 100px; height: 100px;"><img src="<?php echo $product_images.''.$row['6'] ?>"></div></td>
                                        <td><div style="width: 50px; height: 100px;"><?php echo $row['7'] ?></div></td>
                                        <td><div style="width: 50px; height: 100px;"><?php echo $row['8'] ?></div></td>                                        
                                    </tr>
                                  <?php
                                        $i++;
                                    }
                                  ?>
                            </tbody>
                        </table>
                     </div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

</div><!-- /#right-panel -->


                  
<?php include('footer.php') ?>
<?php
	require('../config.php');
	@session_start();

	if(isset($_POST['addnew_product']))
	{
		$productname=mysqli_real_escape_string($con,$_POST['productname']);
		$productdescription=mysqli_real_escape_string($con,$_POST['productdescription']);
		$categoryname=$_POST['categoryname'];
		$mrp=$_POST['mrp'];
		$price=$_POST['price'];

		$image1= basename($_FILES['image1']["name"]);
		$image2= basename($_FILES['image2']["name"]);
		$image3= basename($_FILES['image3']["name"]);


		print_r($_FILES['image1']);
		echo "<hr />";
		echo $image1. "<br />";
		echo $image2. "<br />";
		echo $image3. "<br />";

		$tmp_name1 = $_FILES["image1"]["tmp_name"];
		$tmp_name2 = $_FILES["image2"]["tmp_name"];
		$tmp_name3 = $_FILES["image3"]["tmp_name"];

		$sql = "insert into ec_product values('0','$productname','$productdescription','$categoryname','$image1','$image2','$image3','$mrp',$price)";
		$res = mysqli_query($con, $sql) or die("error : ".mysqli_error($con));
		if($res)
		{

			move_uploaded_file($tmp_name1, "../../../../products_images/$image1");
			move_uploaded_file($tmp_name2, "../../../../products_images/$image2");
			move_uploaded_file($tmp_name3, "../../../../products_images/$image3");

			$_SESSION['product_action']="Successfully Added New Product";
//			header('location:../product-view.php');
		}
	}
?>
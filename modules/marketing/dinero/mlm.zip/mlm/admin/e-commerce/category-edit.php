<?php include('header.php'); ?>
                  <div class="col-lg-6">
                    <div class="card">
                      <div class="card-header">Add New Category</div>
                      <div class="card-body card-block">
                        <form action="code/category.php" method="post" class="">
                          
                           <?php
                              $id=$_GET['id'];
                              $sql = "SELECT * FROM ec_category where id='$id'";
                              $re = mysqli_query($con, $sql) or die (mysqli_error($con));
                              $row=mysqli_fetch_array($re);
                            ?>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="hidden" id="id" name="id" placeholder="Category Name" value="<?php echo $row[0]; ?>" class="form-control">
                              <input type="text" id="categoryname" name="categoryname" placeholder="Category Name" value="<?php echo $row[1]; ?>" class="form-control">
                            </div>
                          </div>

                          <div class="form-actions form-group"><button name="edit_category" type="submit" class="btn btn-success"><i class="fa fa-pencil"></i> Edit Category</button></div>
                        </form>
                      </div>
                    </div>
                  </div>
<?php include('footer.php') ?>
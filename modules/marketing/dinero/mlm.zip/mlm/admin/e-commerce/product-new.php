<?php include('header.php'); ?>
                  <div class="col-lg-6">
                    <div class="card">
                      <div class="card-header">Add New Product</div>
                      <div class="card-body card-block">
                        <form action="code/product.php" method="post" enctype="multipart/form-data">
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-product-hunt"></i></div>
                              <input type="text" id="productname" name="productname" placeholder="Product Name" class="form-control">
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-file-text"></i></div>
                              <textarea id="productdescription" name="productdescription" placeholder="Product Description" class="form-control"></textarea>
                            </div>
                          </div>
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-tags"></i></div>
                              <select id="categoryname" name="categoryname" class="form-control">
                                  <option disabled="" selected="">Select Category</option>
                                  <?php
                                  $sql = "SELECT * FROM ec_category order by id ASC";
                                  $re = mysqli_query($con, $sql) or die (mysqli_error($con));
                                  $i=1;
                                  while ($row=mysqli_fetch_array($re))
                                    {
                                  ?>
                                  <option value="<?php echo $row[0]; ?>"><?php echo $row[1]; ?></option>
                                  <?php
                                    }
                                  ?>
                                </select>
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-photo"></i></div>
                              <input type="file" id="image1" name="image1" placeholder="Product Images" class="form-control">
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-photo"></i></div>
                              <input type="file" id="image2" name="image2" placeholder="Product Images" class="form-control">
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-photo"></i></div>
                              <input type="file" id="image3" name="image3" placeholder="Product Images" class="form-control">
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-rupee"></i></div>
                              <input type="number" id="mrp" name="mrp" placeholder="Product MRP" class="form-control">
                            </div>
                          </div>

                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-rupee"></i></div>
                              <input type="number" id="price" name="price" placeholder="Product Price" class="form-control">
                            </div>
                          </div>

                          <div class="form-actions form-group"><button name="addnew_product" type="submit" class="btn btn-success"><i class="fa fa-plus"></i> Add Product</button></div>
                        </form>
                      </div>
                    </div>
                  </div>
<?php include('footer.php') ?>
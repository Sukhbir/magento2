<?php include('header.php'); ?>
                  <div class="col-lg-6">
                    <div class="card">
                      <div class="card-header">Add New Category</div>
                      <div class="card-body card-block">
                        <form action="code/category.php" method="post" class="">
                          
                          <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-tags"></i></div>
                              <input type="text" id="categoryname" name="categoryname" placeholder="Category Name" class="form-control">
                            </div>
                          </div>

                          <div class="form-actions form-group"><button name="addnew_category" type="submit" class="btn btn-success"><i class="fa fa-plus"></i> Add Category</button></div>
                        </form>
                      </div>
                    </div>
                  </div>
<?php include('footer.php') ?>
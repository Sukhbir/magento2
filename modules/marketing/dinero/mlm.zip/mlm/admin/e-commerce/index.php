<?php include('header.php'); ?>
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <?php
            $query = mysqli_query($con,"select * from member");
            $result = mysqli_num_rows($query);
        ?>
        <div class="content mt-3">
            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-user text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Total Members</div>
                                <div class="stat-digit"><?php echo $result; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <?php
            $query = mysqli_query($con,"select * from e_pin_request where status='0'");
            $result = mysqli_num_rows($query);
            ?>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-pin text-success border-success"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">E-Pin Request</div>
                                <div class="stat-digit"><?php echo $result; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            $query = mysqli_query($con,"select * from e_pin where status='0'");
            $result = mysqli_num_rows($query);
            ?>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-pin text-warning border-warning"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">E-pin</div>
                                <div class="stat-digit"><?php echo $result; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
            $payout=0;
            $query = mysqli_query($con,"select * from income_received");
            while($result = mysqli_fetch_array($query))
            {
                $payout=$payout+$result['amount'];
            }
            ?>

            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-money text-warning border-warning"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Total Payout</div>
                                <div class="stat-digit"><?php echo $payout; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- .content -->
    </div><!-- /#right-panel -->

    <!-- Right Panel -->
<?php include('footer.php') ?>
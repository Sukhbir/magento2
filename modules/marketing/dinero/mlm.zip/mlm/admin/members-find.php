<?php
include('header.php');
?>
	<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Find Members</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                        <div class="card-body">
   						<form method="get">
   						<div class="row form-group">
             	 			<div class="col col-md-12">
                    			<div class="input-group">
                    		
                    			<input type="text" id="search" name="search" placeholder="Search member by Username or Name" class="form-control">
                    			<div class="input-group-btn"><button type="submit" class="btn btn-primary"><strong><i class="fa fa-search"> </i> Find </strong></button></div>
                				</div>
        		    		</div>
        			    </div>
        			    </form>
						<?php
						if(isset($_GET['search']))
						{
						?>
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Member</th>
                                    <th>Sponsor</th>
                                    <th>Position</th>
									<th>Enrollment Amount</th>
									<th>Joined Date</th>
									<th>Status</th>
                                    <th colspan="3" class="text-center">Action</th>
                                </tr>
                            </thead>
                    
                            <tbody>
                            <?php
                            $search=$_GET['search'];
                            $sql = "SELECT * FROM member where uname like ('%$search%') or fname like ('%$search%') or lname like ('%$search%')  order by id desc";
                            $re = mysqli_query($con, $sql) or die (mysqli_error($con));
                            $i=1;
                            while ($row=mysqli_fetch_assoc($re))
                                {
                            ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
									<td><?php echo $row['fname']." ".$row['lname']; ?></td>
                                    <td><?php echo $row['sponsor']; ?></td>
                                    <td><?php echo $row['position']; ?></td>
                            <?php

                            $id=$row['enrollement_fee'];

                            $sql1 = "SELECT * FROM enrollment_pack where id='$id'";
                            $re1 = mysqli_query($con, $sql1) or die (mysqli_error($con));

                            $row1=mysqli_fetch_assoc($re1);     
                            ?>
                                    <td><?php echo $row1['enrollment_title']; ?> ($ <?php echo $row1['enrollment_price']; ?>)</td>
									<td><?php echo $row['datetime']; ?></td>
									<td><?php if($row['status']=='1') { echo "Active"; } elseif($row['status']=='2') { echo "Cancelled"; } elseif($row['status']=='3') { echo "Blocked"; } ?> </td>
                                    <td><?php if($row['status']=='1' or $row['status']=='3') { ?> <a class="btn btn-warning" href="code/member.php?action=cancel&user_id=<?php echo $row['id']; ?>">Cancel</a><?php } ?>
                                    <?php if($row['status']=='2') { ?> <a class="btn btn-success" href="code/member.php?action=reactive&user_id=<?php echo $row['id']; ?>">Re Active</a><?php } ?></td>

                                    <td><?php if($row['status']=='1') { ?> <a class="btn btn-danger" href="code/member.php?action=block&user_id=<?php echo $row['id']; ?>">Block</a><?php } ?>
                                    <?php if($row['status']=='3') { ?> <a class="btn btn-primary" href="code/member.php?action=unblock&user_id=<?php echo $row['id']; ?>">Un-Block</a><?php } ?></td>

                                </tr>
                            <?php
                                $i++;
                                }
                            ?>    
                            </tbody>
                        </table>
						<?php
						}
						?>
                        </div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

</div><!-- /#right-panel -->


                  
<?php include('footer.php') ?>
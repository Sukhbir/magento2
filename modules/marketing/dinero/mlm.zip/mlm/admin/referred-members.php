<?php include('header.php') ?>
        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Referred Members </h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Table</a></li>
                            <li class="active">Data table</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <?php
        if(isset($_SESSION['user_action']))
        {
        ?>
        <div class="breadcrumbs bg-success">
            <div>
                <div class="page-header text-center text-white bg-success">
                    <div class="page-title">
                        <h1><?php echo $_SESSION['user_action']; ?></h1>
                    </div>
                </div>
            </div>
        </div>
        <?php
        unset($_SESSION['user_action']);
        }
        ?>

	      <div class="col-lg-12">
          <div class="card">
		  <div class="card-body card-block">
                      
			<form class="form-inline">
    		<div class="input-group mb-2 mr-sm-2">
    		<div class="input-group-prepend">
      		<div class="input-group-text"><i class="fa fa-user"></i></div>
    		</div>
   				 <input type="text" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Member Id">
 		 	</div>
					
			<div class="col-auto">
                <button type="submit" class="btn btn-primary mb-2">Search</button>
	  			<button type="submit" class="btn btn-primary mb-2">Clear</button>
    		</div>

			</form>		
           </div>
		   </div>
           </div>

                  
	       <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Referred Members</strong>
                                
                            </div>
						<div class="card-body table-responsive">
                                        
                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Member</th>
                                    <th>Enrollment Amount</th>
									<th>Joined Date</th>
									<th>Title/Rank/Status</th>
                                </tr>
                            </thead>
                    
                            <tbody>

                            <?php
                            $uname=$_SESSION['userlogin'];
                            $sql = "SELECT * FROM member where sponsor='$uname'";
                            $re = mysqli_query($con, $sql) or die (mysqli_error($con));
                            $i=1;
                            while ($row=mysqli_fetch_assoc($re))
                                {
                            ?>


                                <tr>
                                    <td><?php echo $i; ?></td>
									<td><?php echo $row['fname']; ?></td>
                                    <?php
                                        
                                        $id=$row['enrollement_fee'];
                                        $sql1 = "SELECT * FROM enrollment_pack where id='$id'";
                                        $re1 = mysqli_query($con, $sql1) or die (mysqli_error($con));
                                        $row1=mysqli_fetch_assoc($re1);     
                                     
                                    ?>
                                    <td><?php echo $row1['enrollment_title']; ?> ($<?php echo $row1['enrollment_price']; ?>)</td>
									<td><?php echo $row['datetime']; ?></td>
									<td><?php if($row['status']=='1') { echo "<a class='btn btn-success text-white'> Active </a>"; } ?> </td>
                                </tr>
                                <?php
                                    $i++;
                                    }
                                ?>
                            </tbody>
                        </table>
                     </div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
    </div><!-- .content -->

</div><!-- /#right-panel -->

<?php include('footer.php') ?>

    <!-- <script src="assets/js/lib/data-table/datatables.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="assets/js/lib/data-table/jszip.min.js"></script>
    <script src="assets/js/lib/data-table/pdfmake.min.js"></script>
    <script src="assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="assets/js/lib/data-table/datatables-init.js"></script>


    <script type="text/javascript">
        $(document).ready(function() {
          $('#bootstrap-data-table-export').DataTable();
        } );
    </script> -->
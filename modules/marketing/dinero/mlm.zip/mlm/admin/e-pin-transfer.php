<?php include('header.php'); ?>


                  <div class="col-lg-6">
                    <div class="card">
                      <div class="card-header">E-Pin Transfer
					  <a href="your link here" style="float:right;"><i class="fa fa-refresh"></i></a>
					  
					  </div>
                      <div class="card-body card-block">
                        <form action="" method="post" class="">
                          
						  <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="fromusername" name="fromusername" placeholder="From Username" class="form-control">
                            </div>
                          </div>
						  <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-user"></i></div>
                              <input type="text" id="tousername" name="tousername" placeholder="To Username" class="form-control">
                            </div>
                          </div>
						  
						  <div class="form-group">
                            <div class="input-group">
                              <div class="input-group-addon"><i class="fa fa-dollar"></i></div>
                           
                              <select name="select" id="select" class="form-control">
                                <option value="0">Select Pin</option>
                                <option value="1">$1</option>
                                <option value="2">$5</option>
                                <option value="3">$10</option>
								<option value="4">$20</option>
								<option value="3">$50</option>
                              </select>
                            </div>
							</div>
							
						 <div class="form-actions form-group"><button type="submit" class="btn btn-success btn-sm">Transfer</button></div>
                        </form>
                      </div>
                    </div>
                  </div>

<?php include('footer.php') ?>
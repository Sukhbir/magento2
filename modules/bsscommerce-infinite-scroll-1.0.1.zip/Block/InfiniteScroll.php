<?php
/**
* BSS Commerce Co.
*
* NOTICE OF LICENSE
*
* This source file is subject to the EULA
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://bsscommerce.com/Bss-Commerce-License.txt
*
* =================================================================
*                 MAGENTO EDITION USAGE NOTICE
* =================================================================
* This package designed for Magento COMMUNITY edition
* BSS Commerce does not guarantee correct work of this extension
* on any other Magento edition except Magento COMMUNITY edition.
* BSS Commerce does not provide extension support in case of
* incorrect edition usage.
* =================================================================
*
* @category   BSS
* @package    Bss_InfiniteScroll
* @author     Extension Team
* @copyright  Copyright (c) 2015-2016 BSS Commerce Co. ( http://bsscommerce.com )
* @license    http://bsscommerce.com/Bss-Commerce-License.txt
*/
namespace Bss\InfiniteScroll\Block;

use Magento\Framework\View\Element\Template;

class InfiniteScroll extends Template
{
    protected $_config;
    protected $_gototop;
    protected $_btnload;

    public function __construct(
        \Magento\Catalog\Block\Product\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_scopeConfig   = $context->getScopeConfig();
        $this->pageConfig->getTitle()->set(__('InfiniteScroll'));
    }

    public function getMediaUrl() 
    {
        return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }

    public function getConfig($config_path = '') 
    {
        return $this->_scopeConfig->getValue('infinitescroll/settings/' . $config_path);
    }

    public function loadingIcon() {
        $loading = $this->getConfig('loading_icon');
        if($loading){
            return $this->getMediaUrl() .'infinitescroll/'. $loading;
        }
        return false;
    }

    public function getConfigGototop($config_path = '') {
        if($this->_scopeConfig->getValue('infinitescroll/gototop/enabled_gototop'))
            return $this->_scopeConfig->getValue('infinitescroll/gototop/' . $config_path);
        return false;
    }

    public function getConfigButton($config_path = '') {
        return $this->_scopeConfig->getValue('infinitescroll/btn_loadmore/' . $config_path);
    }
}
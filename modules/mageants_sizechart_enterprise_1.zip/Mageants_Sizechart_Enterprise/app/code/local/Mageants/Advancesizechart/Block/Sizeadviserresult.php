<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block;
 
use \Magento\Framework\View\Element\Template\Context;
use \Mageants\Advancesizechart\Helper\Data;
use \Magento\Framework\ObjectManagerInterface;
use \Mageants\Advancesizechart\Model\SizeadviserFactory;
use \Mageants\Advancesizechart\Model\SizedimensionFactory;
use \Mageants\Advancesizechart\Model\ResourceModel\Image;
use \Magento\Store\Model\StoreManagerInterface;
use \Mageants\Advancesizechart\Model\Source\SizechartDisplayType;
use \Mageants\Advancesizechart\Model\Source\SizeUnit;

/**
 * Class BlockRepository
 *
 * @package Mageants\Advancesizechart\Block
 */
 
class Sizeadviserresult extends \Magento\Framework\View\Element\Template
{
	/**
	 * Retrieve setAdvsizechart for current request 
	 *
     * @return sizechart
     */
    public function setSizeAdviser($sizeadviser)
    {
		$this->_sizeadviser = $sizeadviser;
	}
	
	/**
     * Retrieve getSizeadviser for current request 
     *
     * @return sizechart
     */
	public function getSizeadviser()
    {
		return $this->_sizeadviser;
    }
}
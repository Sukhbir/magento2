<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizechart\Edit\Tab;

use \Magento\Cms\Model\Wysiwyg\Config;
use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;
use \Magento\Cms\Ui\Component\Listing\Column\Cms\Options;
use \Magento\Config\Model\Config\Source\Yesno;
use \Mageants\Advancesizechart\Model\Source\Status;
use \Mageants\Advancesizechart\Model\Source\SizechartDisplayType;
use \Mageants\Advancesizechart\Model\Source\SizechartUseType;
use \Mageants\Advancesizechart\Model\SizeadviserFactory;
use \Mageants\Advancesizechart\Helper\Data;

class Sizechart extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
	
	/**
     * Default Helper options
     * 
     */
    protected $_helper;
	  /**
     * Wysiwyg config
     * 
     * @var \Magento\Cms\Model\Wysiwyg\Config
     */
    protected $_wysiwygConfig;
    /**
     * Store View options
     * 
     */
    protected $_cmsOpt;
	
    /**
     * Yes No options
     * 
     */
    protected $_yesNo;

    /**
     * Enable / Disable options
     * 
     */
    protected $_status;
	
    /**
     * Use Image / Content
     * 
     */
    protected $_sizechartUseType;

    /**
     * Use Image / Content
     * 
     */
    protected $_sizeadviser;

    /**
     * constructor
     * 
     * @param Context $context
	 * @param Options $cmsOpt
	 * @param Yesno $yesNo
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param array $data
     */
    public function __construct(
		Config $wysiwygConfig,		
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
		Options $cmsOpt,
		Yesno $yesNo,
		Status $status,
		SizechartUseType $sizechartUseType,
		SizeadviserFactory $sizeadviserFactory,
		SizechartDisplayType $sizechartDisplayType,
		Data $helper,
        array $data = []
    )
    {	
        $this->_cmsOpt 				 = $cmsOpt;
		
        $this->_yesNo 					 = $yesNo;
        
		$this->_status 					 = $status;
		
		$this->_wysiwygConfig        = $wysiwygConfig;
		
		$this->_sizechartUseType        = $sizechartUseType;
		
		$this->_sizechartDisplayType        = $sizechartDisplayType;
		
		$this->_sizeadviser       = $sizeadviserFactory->create();
		
		$this->_helper 					 = $helper;
		
	    parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Mageants\Advancesizechart\Model\Sizechart $sizechart */
        $sizechart = $this->_coreRegistry->registry('mageants_advancesizechart');
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('sizechart_');
        $form->setFieldNameSuffix('sizechart');
        
		 $fieldset = $form->addFieldset(
            'base_fieldset',
            [
                'legend' => __('Sizechart Information'),
                'class'  => 'fieldset-wide'
            ]
        );
		 
	$fieldset->addType('image', 'Mageants\Advancesizechart\Block\Adminhtml\Sizechart\Helper\Image');
			
      if ($sizechart->getId()) 
	  {
            $fieldset->addField(
                'id',
                'hidden',
                ['name' => 'id']
            );
        }
		
      $fieldset->addField(
            'status',
            'select',
            [
                'name'  => 'status',
                'label' => __('Enable'),
                'title' => __('Enable'),
                'required' => true,
				'values' => $this->_status->toOptionArray()
            ]
        );
		
        $fieldset->addField(
            'sizechart_name',
            'text',
            [
                'name'  => 'sizechart_name',
                'label' => __('Sizechart Name'),
                'title' => __('Sizechart Name'),
                'required' => true,
            ]
        );
		
        $fieldset->addField(
            'store_id',
            'select',
            [
                'name'  => 'store_id',
                'label' => __('Store View'),
                'title' => __('Store View'),
                'required' => true,
				'values' => $this->_cmsOpt->toOptionArray()
            ]
        );
			
        $enablesizeadv = $fieldset->addField(
            'link_label',
            'text',
            [
                'name'  => 'setting[link_label]',
                'label' => __('Frontend Link Label'),
                'title' => __('Frontend Link Label'),
                'required' => true				
            ]
        );
	 	
		$enablesizeadv = $fieldset->addField(
            'display_type',
            'select',
            [
                'name'  => 'setting[display_type]',
                'label' => __('Display Type'),
                'title' => __('Display Type'),
                'required' => true,
				'values' => $this->_sizechartDisplayType->toOptionArray()
            ]
        );
	 	
        $enablesizeadv = $fieldset->addField(
            'enable_size_adviser',
            'select',
            [
                'name'  => 'setting[enable_size_adviser]',
                'label' => __('Enable Size Adviser To Configurable Product ?'),
                'title' => __('Enable Size Adviser To Configurable Product ?'),
                'required' => true,
				'values' => $this->_yesNo->toOptionArray()
            ]
        );
	 
       $sizeadv = $fieldset->addField(
            'size_adviser',
            'select',
            [
                'name'  => 'setting[size_adviser]',
                'label' => __('Size Adviser '),
                'title' => __('Size Adviser '),
                'required' => true,
				'values' => $this->_sizeadviser->getCollection()->toOptionArray()
            ]
        );
        $chart_type = $fieldset->addField(
            'use_image_content',
            'select',
            [
                'name'  => 'setting[use_image_content]',
                'label' => __('Use Image / Content '),
                'title' => __('Use Image / Content '),
                'required' => true,
				'values' => $this->_sizechartUseType->toOptionArray()
            ]
        );
	 
		$chart_image = $fieldset->addField(
			'image',
			'image',
			[
				'name'  => 'image',
				'label' => __('Chart Image'),
				'title' => __('Chart Image'),
				'value' => $sizechart->getImage()
			]
		);
		
		$chart_content = $fieldset->addField(
			'content',
			'editor',
			[
				'name'  => 'content',
				'label' => __('Content'),
				'title' => __('Content'),
				'config'    => $this->_wysiwygConfig->getConfig()
			]
		);  
		
		$sizechartSettings = $this->_helper->getDefaultSizechartSetting();
		
		$sizechart->addData($sizechartSettings);		
		
       $sizechartData = $this->_session->getData('mageants_advancesizechart_sizechart_data', true);
	   
        if ($sizechartData) 
		{
		    $sizechart->addData($sizechartData);
        } 
		else 
		{
            if (!$sizechart->getId()) 
			{
			    $sizechart->addData($sizechart->getDefaultValues());
            }
			else
			{
				
				$settingData = $this->_helper->unserializeSetting($sizechart->getSetting());
				
				$sizechart->addData($settingData);
			}
        }
		
        $form->addValues($sizechart->getData()); 
		
		$this->setChild('form_after', 
			 $this->getLayout()->createBlock('Magento\Backend\Block\Widget\Form\Element\Dependence')
            ->addFieldMap($sizeadv->getHtmlId(), $sizeadv->getName())
            ->addFieldMap($enablesizeadv->getHtmlId(), $enablesizeadv->getName())
			->addFieldMap($chart_image->getHtmlId(), $chart_image->getName())
            ->addFieldMap($chart_content->getHtmlId(), $chart_content->getName())
            ->addFieldMap($chart_type->getHtmlId(), $chart_type->getName())
            /* ->addFieldDependence(
                $chart_image->getName(),
                $chart_type->getName(),
                0
            )
			 ->addFieldDependence(
                $chart_content->getName(),
                $chart_type->getName(),
                1
            ) */
            ->addFieldDependence(
                $sizeadv->getName(),
                $enablesizeadv->getName(),
                1
            )
        );
		
        $this->setForm($form);
		
        return parent::_prepareForm();
    }

	
    /**
     * Prepare Sizechart for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('General');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }

}

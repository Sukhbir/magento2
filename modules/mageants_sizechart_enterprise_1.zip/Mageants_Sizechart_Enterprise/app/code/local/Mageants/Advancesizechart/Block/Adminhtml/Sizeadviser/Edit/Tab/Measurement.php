<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizeadviser\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;
use \Magento\Cms\Ui\Component\Listing\Column\Cms\Options;

class Measurement extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Mageants\Advancesizechart\Model\Sizeadviser $sizeadviser */
        $sizeadviser = $this->_coreRegistry->registry('mageants_sizeadviser');
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('measurement_');
        $form->setFieldNameSuffix('measurement');
        
		 $fieldset = $form->addFieldset(
            'base_fieldset',
            [
                'legend' => __('Measurement Information'),
                'class'  => 'fieldset-wide'
            ]
        );
	
		$measurementBlock = $this->getLayout()->createBlock(
            SizeMeasurement::class,
            null,
			[
				'data' => ['measurement'=>$sizeadviser->getSizeMeasurements(),
								 'dimension'=>$sizeadviser->getDimensions(),
								 'standerd'=>$sizeadviser->getStanderds(),
								 'size_unit'=>$sizeadviser->getSizeUnit()
								] 
			]             
        );
		
		$fieldset->addField(
            'standerds_value_container',
            'note',
            [
                    'text' => $measurementBlock->toHtml(),				
            ]
        );
       $sizeadviserData = $this->_session->getData('mageants_advancesizechart_sizeadviser_data', true);
	   
        if ($sizeadviserData) 
		{
		    $sizeadviser->addData($sizeadviserData);
        } 
		else 
		{
            if (!$sizeadviser->getId()) 
			{
			    $sizeadviser->addData($sizeadviser->getDefaultValues());
            }
        }
		
        $form->addValues($sizeadviser->getData()); 
		
        $this->setForm($form);
		
        return parent::_prepareForm();
    }

	
    /**
     * Prepare Sizeadviser for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Size Measurement');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }

}

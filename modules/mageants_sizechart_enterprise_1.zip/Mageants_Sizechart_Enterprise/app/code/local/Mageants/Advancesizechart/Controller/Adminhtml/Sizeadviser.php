<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml;

use \Mageants\Advancesizechart\Model\SizeadviserFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
		
abstract class Sizeadviser extends \Magento\Backend\App\Action
{
    /**
     * Size Chart Factory
     * 
     * @var \Mageants\Advancesizechart\Model\SizeadviserFactory
     */
    protected $_sizeadviserFactory;

    /**
     * Core registry
     * 
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * Result redirect factory
     * 
     * @var \Magento\Backend\Model\View\Result\RedirectFactory
     */
    protected $_resultRedirectFactory;

    /**
     * constructor
     * 
     * @param SizeadviserFactory $sizeadviserFactory
     * @param Registry $coreRegistry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        SizeadviserFactory $sizeadviserFactory,
        Registry $coreRegistry,
        Context $context
    )
    {
        $this->_sizeadviserFactory           = $sizeadviserFactory;
		
        $this->_coreRegistry          = $coreRegistry;
		
        $this->_resultRedirectFactory = $context->getResultRedirectFactory();
		
        parent::__construct($context);
    }

    /**
     * Init Size Chart
     *
     * @return \Mageants\Advancesizechart\Model\Sizeadviser
     */
    protected function _initSizeadviser()
    {
       $sizeadviserid  = (int) $this->getRequest()->getParam('id');
	   
	   if(!$sizeadviserid )
	   {
		   $sizeadviser  =  $this->getRequest()->getParam('sizeadviser');
		  
			if(isset($sizeadviser['id']))
				$sizeadviserid = (int)$sizeadviser['id'];
	   }
        /** @var \Mageants\Advancesizechart\Model\Sizeadviser $sizeadviser */
        $sizeadviser    = $this->_sizeadviserFactory->create();
		
        if ($sizeadviserid) 
		{
            $sizeadviser->load($sizeadviserid);
        }
		
        $this->_coreRegistry->register('mageants_sizeadviser', $sizeadviser);
		
        return $sizeadviser;
    }
}

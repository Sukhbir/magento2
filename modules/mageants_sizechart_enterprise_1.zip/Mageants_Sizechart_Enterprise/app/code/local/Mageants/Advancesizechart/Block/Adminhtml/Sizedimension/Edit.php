<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizedimension;

use \Magento\Framework\Registry;
use \Magento\Backend\Block\Widget\Context;
		
class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry
     * 
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * constructor
     * 
     * @param Registry $coreRegistry
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Registry $coreRegistry,
        Context $context,
        array $data = []
    )
    {
        $this->_coreRegistry = $coreRegistry;
		
        parent::__construct($context, $data);
    }

    
    /**
     * Initialize Post edit block
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId = 'id';
        
		$this->_blockGroup = 'Mageants_Advancesizechart';
        
		$this->_controller = 'adminhtml_sizedimension';
		
        parent::_construct();
        
		$this->buttonList->update('save', 'label', __('Save Size Dimension'));
        
		$this->buttonList->add(
            'save-and-continue',
            [
                'label' => __('Save and Continue Edit'),
                'class' => 'save',
                'data_attribute' => [
                    'mage-init' => [
                        'button' => [
                            'event' => 'saveAndContinueEdit',
                            'target' => '#edit_form'
                        ]
                    ]
                ]
            ],
            -100
        );
		
        $this->buttonList->update('delete', 'sizechart', __('Delete Size Dimension'));
    }
	
    /**
     * Retrieve text for header element depending on loaded Size Dimension
     *
     * @return string
     */
    public function getHeaderText()
    {
        $sizedimension = $this->_coreRegistry->registry('mageants_sizedimension');
        
		if ($sizedimension->getId()) 
		{
            return __("Edit Size Dimension '%1'", $this->escapeHtml($sizedimension->getLabel()));
        }
		
        return __('New Size Dimension');
    }
}

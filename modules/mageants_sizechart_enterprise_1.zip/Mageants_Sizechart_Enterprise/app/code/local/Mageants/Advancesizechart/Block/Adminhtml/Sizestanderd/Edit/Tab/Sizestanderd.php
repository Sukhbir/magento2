<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizestanderd\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;
use \Magento\Cms\Ui\Component\Listing\Column\Cms\Options;

class Sizestanderd extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Mageants\Advancesizechart\Model\Sizestanderd $sizestanderd */
        $sizestanderd = $this->_coreRegistry->registry('mageants_sizestandard');
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('sizestanderd_');
        $form->setFieldNameSuffix('sizestanderd');
        
		 $fieldset = $form->addFieldset(
            'base_fieldset',
            [
                'legend' => __('Sizestanderd Information'),
                'class'  => 'fieldset-wide'
            ]
        );
		 
	  $fieldset->addType('image', 'Mageants\Advancesizechart\Block\Adminhtml\Sizestanderd\Helper\Image');
			
		
      if ($sizestanderd->getId()) 
	  {
            $fieldset->addField(
                'id',
                'hidden',
                ['name' => 'id']
            );
        }
		
        $fieldset->addField(
            'standerd_name',
            'text',
            [
                'name'  => 'standerd_name',
                'label' => __('Size Standerd Name'),
                'title' => __('Size Standerd Name'),
                'required' => true,
            ]
        );
		
		$sizeStanderdValueEditBlock = $this->getLayout()->createBlock(
            SizeStanderdValues::class,
            null,
			['data' => ['standerd_serialize'=>$sizestanderd->getValue()] ]             
        );
		
		$fieldset->addField(
            'standerds_value_container',
            'note',
            [
                'label' => __('Standerd Values'),
                'title' => __('Standerd Values'),
                'text' => $sizeStanderdValueEditBlock->toHtml(),
				
            ]
        );
		
	 
       $sizestanderdData = $this->_session->getData('mageants_advancesizechart_sizestanderd_data', true);
	   
        if ($sizestanderdData) 
		{
		    $sizestanderd->addData($sizestanderdData);
        } 
		else 
		{
            if (!$sizestanderd->getId()) 
			{
			    $sizestanderd->addData($sizestanderd->getDefaultValues());
            }
        }
		
        $form->addValues($sizestanderd->getData()); 
		
        $this->setForm($form);
		
        return parent::_prepareForm();
    }

	
    /**
     * Prepare Sizestanderd for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('General');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }

}

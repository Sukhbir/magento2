<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml;

use \Mageants\Advancesizechart\Model\SizechartFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
		
abstract class Sizechart extends \Magento\Backend\App\Action
{
    /**
     * Size Chart Factory
     * 
     * @var \Mageants\Advancesizechart\Model\SizechartFactory
     */
    protected $_sizechartFactory;

    /**
     * Core registry
     * 
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * Result redirect factory
     * 
     * @var \Magento\Backend\Model\View\Result\RedirectFactory
     */
    protected $_resultRedirectFactory;

    /**
     * constructor
     * 
     * @param SizechartFactory $sizechartFactory
     * @param Registry $coreRegistry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        SizechartFactory $sizechartFactory,
        Registry $coreRegistry,
        Context $context
    )
    {
        $this->_sizechartFactory           = $sizechartFactory;
		
        $this->_coreRegistry          = $coreRegistry;
		
        $this->_resultRedirectFactory = $context->getResultRedirectFactory();
		
        parent::__construct($context);
    }

    /**
     * Init Size Chart
     *
     * @return \Mageants\Advancesizechart\Model\Sizechart
     */
    protected function _initSizechart()
    {
        $sizechartid  = (int) $this->getRequest()->getParam('id');
		
        /** @var \Mageants\Advancesizechart\Model\Sizechart $sizechart */
        $sizechart    = $this->_sizechartFactory->create();
		
        if ($sizechartid) 
		{
            $sizechart->load($sizechartid);
        }
		
        $this->_coreRegistry->register('mageants_advancesizechart', $sizechart);
		
        return $sizechart;
    }
}

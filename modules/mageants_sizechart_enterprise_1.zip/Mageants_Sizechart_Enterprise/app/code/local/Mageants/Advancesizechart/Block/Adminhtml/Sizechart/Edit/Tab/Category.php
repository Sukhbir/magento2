<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizechart\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;

class Category extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
	const FORM_NAME = 'mageants_sizechart_form';
	
    /**
     * constructor
     * 
     * @param Context $context
	 * @param Options $cmsOpt
	 * @param Yesno $yesNo
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        array $data = []
    )
    {	
		
	    parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Mageants\Advancesizechart\Model\Sizechart $sizechart */
        $sizechart = $this->_coreRegistry->registry('mageants_advancesizechart');
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('category_');
        $form->setFieldNameSuffix('category');
        
		 $fieldset = $form->addFieldset(
            'category_fieldset',
            [
                'legend' => __('Category'),
                'class'  => 'fieldset-wide'
            ]
        );
		
		$categoryTreeBlock = $this->getLayout()->createBlock(
            \Magento\Catalog\Block\Adminhtml\Category\Checkboxes\Tree::class,
            null,
            ['data' => ['js_form_object' => 'сategoryIds']]
        );

        $fieldset->addField(
            'category_ids',
            'hidden',
            [
                'name' => 'category_ids',
                'data-form-part' => self::FORM_NAME,
                'after_element_js' => $this->getCategoryIdsJs(),
                'value' =>$sizechart->getCategoryIds()
            ]
        );
        $categoryTreeBlock->setCategoryIds(explode(',', $sizechart->getCategoryIds()));
        
        $fieldset->addField(
            'category_tree_container',
            'note',
            [
                'label' => __('Categories'),
                'title' => __('Categories'),
                'text' => $categoryTreeBlock->toHtml()
            ]
        );
 
       $this->setForm($form);
		
        return parent::_prepareForm();
    }

	/**
     * Retrive js code for CategoryIds input field
     *
     * @return string
     */
    private function getCategoryIdsJs()
    {
        return <<<HTML
    <script type="text/javascript">
        сategoryIds = {updateElement : {value : "", linkedValue : ""}};
        Object.defineProperty(сategoryIds.updateElement, "value", {
            get: function() {
                return сategoryIds.updateElement.linkedValue
            },
            set: function(v) {
                сategoryIds.updateElement.linkedValue = v;
                jQuery("#category_category_ids").val(v)
            }
        });
    </script>
HTML;
    }
	
    /**
     * Prepare Sizechart for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Categories');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }

}

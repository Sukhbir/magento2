<?php
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Model\ResourceModel;

use \Magento\Framework\UrlInterface;
use \Magento\Framework\Filesystem;
use \Magento\Framework\View\Asset\Repository;
use \Magento\Store\Model\StoreManagerInterface;
		
class Image
{
	
	/**
     * @var _storeManager
     */
	protected $_storeManager;
    /**
     * Media sub folder
     * 
     * @var string
     */
    protected $_subDir = 'mageants/advancesizechart/sizechart';
    /**
     * Media sub icon folder
     * 
     * @var string
     */
	 protected $_iconDir = 'mageants/advancesizechart/icon';

    /**
     * URL builder
     * 
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlBuilder;

    /**
     * File system model
     * 
     * @var \Magento\Framework\Filesystem
     */
    protected $_fileSystem;

    /**
     * @var \Magento\Framework\View\Asset\Repositoryp
     */
    protected $_assetRepo;

    /**
     * constructor
     * 
     * @param UrlInterface $urlBuilder
     * @param Filesystem $fileSystem
     */
    public function __construct(
        UrlInterface $urlBuilder,
        Filesystem $fileSystem,
		Repository $assetRepo,
		StoreManagerInterface $storeManager
    )
    {
        $this->_urlBuilder = $urlBuilder;
		
        $this->_fileSystem = $fileSystem;
		
		$this->_assetRepo = $assetRepo;
		
		$this->_storeManager = $storeManager;
    }

    /**
     * get images base url
     *
     * @return string
     */
    public function getBaseUrl()
    {
        return $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]).$this->_subDir.'/image';
    }
    
	/**
     * get base image dir
     *
     * @return string
     */
    public function getBaseDir()
    {
        return $this->_fileSystem->getDirectoryWrite(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath($this->_subDir.'/image');
    }
	
    /**
     * get base image dir
     *
     * @return string
     */
    public function getSizeChartUrl($Image)
    {
        return $this->getBaseUrl().$Image;
    }
	
	/**
     * get product icon
     *
     * @return string
     */
    public function getSizechartIcon($icon = "")
    {
        return $this->_urlBuilder->getBaseUrl(['_type' => UrlInterface::URL_TYPE_MEDIA]).$this->_iconDir.'/'.$icon;
    }
	
}

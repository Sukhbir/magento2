<?php
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizechart;

use Magento\Rule\Model\Condition\AbstractCondition;
use Mageants\Advancesizechart\Model\Rule\Product as ProductRule;

/**
 * Class NewRuleHtml
 * @package Mageants\Advancesizechart\Controller\Adminhtml\Sizechart
 */
class NewRuleHtml extends \Magento\CatalogRule\Controller\Adminhtml\Promo\Catalog
{
    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    const RESOURCE_ID = 'Mageants_Advancesizechart::advancesizechart_new_edit';
	/*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
	
    /**
     * @return void
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        
		$formName = $this->getRequest()->getParam('form_namespace');
        
		$typeArr = explode('|', str_replace('-', '/', $this->getRequest()->getParam('type')));
		
        $type = $typeArr[0];

        $prefix = 'rule';
		
        if ($this->getRequest()->getParam('prefix')) 
		{
            $prefix = $this->getRequest()->getParam('prefix');
        }

        $rule = ProductRule::class;
        
		if ($this->getRequest()->getParam('rule')) 
		{
            $rule = base64_decode($this->getRequest()->getParam('rule'));
        }
		
        $model = $this->_objectManager->create($type)
		->setId($id)
		->setType($type)
		->setRule($this->_objectManager->create($rule))
		->setPrefix($prefix);

        if (!empty($typeArr[1])) 
		{
            $model->setAttribute($typeArr[1]);
        }

        if ($model instanceof AbstractCondition) 
		{
            $model->setJsFormObject($this->getRequest()->getParam('form'));
			
            $model->setFormName($formName);
			
            $html = $model->asHtmlRecursive();
        } 
		else 
		{
            $html = '';
        }
		
        $this->getResponse()->setBody($html);
    }
}

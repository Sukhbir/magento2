<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizechart\Edit\Tab;

use \Mageants\Advancesizechart\Helper\Data;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Backend\Block\Widget\Form\Renderer\FieldsetFactory;
use Magento\Rule\Block\Conditions as BlockConditions;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use \Mageants\Advancesizechart\Model\Rule\Product;
use \Mageants\Advancesizechart\Model\Rule\ProductFactory;
use Magento\Rule\Model\Condition\AbstractCondition as RuleAbstractCondition;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\DataObject\Factory as DataObjectFactory;

class Rule extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
	/**
     * @var string
     */
    const FORM_NAME = 'mageants_sizechart_form';

	/**
     * Core Object Manager
     * 
	 * @var  \Mageants\Advancesizechart\Model\Source\Status
     */
    protected $_objectManager = null;
	
	/**
     * Enable / Disable options
     * 
	 * @var  \Magento\Framework\ObjectManagerInterface
     */
    protected $_status;

	/**
     * Size Chart Helper 
     * 
	 * @var  \Mageants\Advancesizechart\Helper\Data
     */
    protected $_helper = null;
	
    
    /**
     * constructor
     * 
     * @param Context $context
	 * @param Options $cmsOpt
	 * @param Yesno $yesNo
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param array $data
     */
    public function __construct(
		Context $context,
        Registry $registry,
        FormFactory $formFactory,
        DataObjectProcessor $dataObjectProcessor,
        BlockConditions $conditions,
        FieldsetFactory $rendererFieldsetFactory,
		ProductFactory $productRuleFactory,
        DataPersistorInterface $dataPersistor,
        DataObjectFactory $dataObjectFactory,
		Data $sizechartHelper,
        array $data = []     
    )
    {	
        parent::__construct($context, $registry, $formFactory, $data);
        
		$this->dataObjectProcessor = $dataObjectProcessor;
        
		$this->conditions = $conditions;
        
		$this->rendererFieldsetFactory = $rendererFieldsetFactory;
        
		$this->dataPersistor = $dataPersistor;
		
		$this->productRuleFactory = $productRuleFactory;
        
		$this->dataObjectFactory = $dataObjectFactory;
		
		$this->_sizechartHelper = $sizechartHelper;
    }
	
   /**
     * Prepare form before rendering HTML
     *
     * @return $this
     */
    protected function _prepareForm()
    {
		$sizechart = $this->_coreRegistry->registry('mageants_advancesizechart');		
        //echo $sizechart->getSetting();exit;
		$formData = $this->_sizechartHelper->unserializeSetting( $sizechart->getSetting());
		
        $productRule = $this->productRuleFactory->create();
		
        if (isset($formData['rule'])) 
		{
			ini_set("display_error",1);

            $productRule->setConditions([])
                ->getConditions()
				->loadArray($formData['rule']);				
        }

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('rule_');
		$form->setFieldNameSuffix('rule');

        $fieldset = $form->addFieldset(
            'conditions_fieldset',
            [
                'comment' => __(
                    'Please specify products where the block should be displayed. '
                    . 'Leave blank to display the block on all product pages.'
                )
            ]
        )->setRenderer(
            $this->rendererFieldsetFactory->create()
                ->setTemplate('Magento_CatalogRule::promo/fieldset.phtml')
                ->setNewChildUrl(
                    $this->getUrl(
                        '*/*/newRuleHtml',
                        [
                            'form'   => $form->getHtmlIdPrefix() . 'conditions_fieldset',
                            'prefix' => 'mageantssizechart',
                            'rule'   => base64_encode(Product::class),
                            'form_namespace' => self::FORM_NAME
                        ]
                    )
                )
        );
		
        $productRule->setJsFormObject($form->getHtmlIdPrefix() . 'conditions_fieldset');
		
        $fieldset
            ->addField(
                'rule',
                'text',
                [
                    'name'           => 'rule',
                    'label'          => __('Rule'),
                    'title'          => __('Rules'),
                    'data-form-part' => self::FORM_NAME
                ]
            )
            ->setRule($productRule)
            ->setRenderer($this->conditions);

        $this->setConditionFormName($productRule->getConditions(), self::FORM_NAME);
        
        $this->setForm($form);
        
		return parent::_prepareForm();
    }
	
	 /**
     * Handles addition of form name to condition and its conditions
     *
     * @param RuleAbstractCondition $conditions
     * @param string $formName
     * @return void
     */
    private function setConditionFormName(RuleAbstractCondition $conditions, $formName)
    {
        $conditions->setFormName($formName);
		
        if ($conditions->getConditions() && is_array($conditions->getConditions())) 
		{
            foreach ($conditions->getConditions() as $condition) 
			{
                $this->setConditionFormName($condition, $formName);
            }
        }
    }
	
    /**
     * Prepare Rule for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Rule');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }
}

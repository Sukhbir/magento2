<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml;

use \Mageants\Advancesizechart\Model\SizedimensionFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
		
abstract class Sizedimension extends \Magento\Backend\App\Action
{
    /**
     * Size Chart Factory
     * 
     * @var \Mageants\Advancesizechart\Model\SizedimensionFactory
     */
    protected $_sizechartFactory;

    /**
     * Core registry
     * 
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * Result redirect factory
     * 
     * @var \Magento\Backend\Model\View\Result\RedirectFactory
     */
    protected $_resultRedirectFactory;

    /**
     * constructor
     * 
     * @param SizedimensionFactory $sizestanderdFactory
     * @param Registry $coreRegistry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        SizedimensionFactory $sizestanderdFactory,
        Registry $coreRegistry,
        Context $context
    )
    {
        $this->_sizechartFactory           = $sizestanderdFactory;
		
        $this->_coreRegistry          = $coreRegistry;
		
        $this->_resultRedirectFactory = $context->getResultRedirectFactory();
		
        parent::__construct($context);
    }

    /**
     * Init Size Chart
     *
     * @return \Mageants\Advancesizechart\Model\Sizedimension
     */
    protected function _initSizedimension()
    {
        $sizestanderdid  = (int) $this->getRequest()->getParam('id');
		
		if(!$sizestanderdid )
	   {
		    $sizedimension  =  $this->getRequest()->getParam('sizedimension');
			
			if(isset($sizedimension['id']))
				$sizestanderdid = (int)$sizedimension['id'];
	   }
	   
        /** @var \Mageants\Advancesizechart\Model\Sizedimension $sizestanderd */
        $sizestanderd    = $this->_sizechartFactory->create();
		
        if ($sizestanderdid) 
		{
            $sizestanderd->load($sizestanderdid);
        }
		
        $this->_coreRegistry->register('mageants_sizedimension', $sizestanderd);
		
        return $sizestanderd;
    }
}

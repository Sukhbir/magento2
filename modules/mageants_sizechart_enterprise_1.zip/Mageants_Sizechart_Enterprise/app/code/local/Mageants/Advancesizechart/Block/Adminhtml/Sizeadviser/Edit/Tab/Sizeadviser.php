<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizeadviser\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;
use \Mageants\Advancesizechart\Model\Source\SizeUnit;
use \Mageants\Advancesizechart\Model\SizedimensionFactory;
use \Mageants\Advancesizechart\Model\SizestanderdFactory;

class Sizeadviser extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * Size Unit options
     * 
     */
    protected $_sizeunit;
	
    /**
     * Dimension Factory
     * 
     */
    protected $_dimensionFactory;
	
    /**
     * Standerd Factory
     * 
     */
    protected $_sizestanderdFactory;
	
	/**
     * constructor
     * 
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param SizeUnit $sizeunit,
     * @param SizedimensionFactory $dimensionFactory,
     * @param array $data
     */
	 public function __construct(
		Context $context,
        Registry $registry,
        FormFactory $formFactory,
		SizeUnit $sizeunit,
		SizedimensionFactory $dimensionFactory,
		SizestanderdFactory $standerdFactory,
        array $data = []
    )
    {	
		$this->_sizeunit 					 = $sizeunit;
		
		$this->_dimensionFactory	 = $dimensionFactory;
		
		$this->_standerdFactory	 = $standerdFactory;
		
	    parent::__construct($context, $registry, $formFactory, $data);
    }
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Mageants\Advancesizechart\Model\Sizeadviser $sizeadviser */
        $sizeadviser = $this->_coreRegistry->registry('mageants_sizeadviser');
		
		$dimension = $this->_dimensionFactory->create();
		
		$standerd = $this->_standerdFactory->create();
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('sizeadviser_');
        $form->setFieldNameSuffix('sizeadviser');
        
		 $fieldset = $form->addFieldset(
            'base_fieldset',
            [
                'legend' => __('Sizeadviser Information'),
                'class'  => 'fieldset-wide'
            ]
        );
	
	 $fieldset->addType('image', 'Mageants\Advancesizechart\Block\Adminhtml\Sizechart\Helper\Image');
			
      if ($sizeadviser->getId()) 
	  {
            $fieldset->addField(
                'id',
                'hidden',
                ['name' => 'id']
            );
        }
		
        $fieldset->addField(
            'code',
            'text',
            [
                'name'  => 'code',
                'label' => __('Size Adviser Code'),
                'title' => __('Size Adviser Code'),
                'required' => true,
				'note' => "must be unique and small latters"			
            ]
        );
		
        $fieldset->addField(
            'name',
            'text',
            [
                'name'  => 'name',
                'label' => __('Size Adviser Name'),
                'title' => __('Size Adviser Name'),
                'required' => true,
            ]
        );
        $fieldset->addField(
            'size_unit',
            'select',
            [
                'name'  => 'size_unit',
                'label' => __('Size Unit'),
                'title' => __('Size Unit'),
                'required' => true,
				'values' => $this->_sizeunit->toOptionArray()
            ]
        );
		
		$fieldset->addField(
			'image',
			'image',
			[
				'name'  => 'image',
				'label' => __('Adviser Image'),
				'title' => __('Adviser Image'),
				'value' => $sizeadviser->getImage(),
				'note' => 'Image will be show in size adviser window'
			]
		);
		
        $fieldset->addField(
            'dimensions',
            'multiselect',
            [
                'name'  => 'dimensions',
                'label' => __('Dimension'),
                'title' => __('Dimension'),
                'required' => true,
				'values' => $dimension->getCollection()->toOptionArray(),
				'value'	=> explode(',' , ''),
				'style'=>"height:100px;"
            ]
        );
		
        $fieldset->addField(
            'standerds',
            'select',
            [
                'name'  => 'standerds[]',
                'label' => __('Standerds'),
                'title' => __('Standerds'),
                'required' => true,
				'values' => $standerd->getCollection()->toOptionArray(),
				'value'	=> explode(',' , ''),
            ]
        );
		
       $sizeadviserData = $this->_session->getData('mageants_advancesizechart_sizeadviser_data', true);
	   
        if ($sizeadviserData) 
		{
		    $sizeadviser->addData($sizeadviserData);
        } 
		else 
		{
            if (!$sizeadviser->getId()) 
			{
			    $sizeadviser->addData($sizeadviser->getDefaultValues());
            }
        }
		
        $form->addValues($sizeadviser->getData()); 
		
        $this->setForm($form);
		
        return parent::_prepareForm();
    }

	
    /**
     * Prepare Sizeadviser for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('General');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }

}

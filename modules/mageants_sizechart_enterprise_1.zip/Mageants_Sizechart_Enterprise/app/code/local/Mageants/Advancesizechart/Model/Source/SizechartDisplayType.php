<?php
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\Advancesizechart\Model\Source;

/**
 * Class Status
 * @package Mageants\Advancesizechart\Model\Source
 */
class SizechartDisplayType implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * 	Display as Popup
     */
    const DISPLAY_POPUP = 1;
	
    /**
     *	Display bellow of "Add To Cart "
     */
    const DISPLAY_BELLOW = 0;

    /**
     * @return array
     */
    public function getOptionArray()
    {
        $optionArray = ['' => ' '];
        foreach ($this->toOptionArray() as $option) 
		{
            $optionArray[$option['value']] = $option['label'];
        }
		
        return $optionArray;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::DISPLAY_BELLOW,  'label' => __('Displlay Bellow Of"Add To Cart"')],
            ['value' => self::DISPLAY_POPUP,  'label' => __('Display in popup')],
        ];
    }
}

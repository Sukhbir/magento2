<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizestanderd;

use \Magento\Framework\Controller\Result\JsonFactory;
use \Mageants\Advancesizechart\Model\SizestanderdFactory;
use \Magento\Backend\App\Action\Context;

abstract class InlineEdit extends \Magento\Backend\App\Action
{		
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::sizestanderd_mass_new_edit';
    /**
     * JSON Factory
     * 
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_jsonFactory;

    /**
     * Sizestanderd Factory
     * 
     * @var \Mageants\Advancesizechart\Model\SizestanderdFactory
     */
    protected $_sizechartFactory;

    /**
     * constructor
     * 
     * @param JsonFactory $jsonFactory
     * @param SizestanderdFactory $sizestanderdFactory
     * @param Context $context
     */
    public function __construct(
        JsonFactory $jsonFactory,
        SizestanderdFactory $sizestanderdFactory,
        Context $context
    )
    {
        $this->_jsonFactory = $jsonFactory;
		
        $this->_sizechartFactory = $sizestanderdFactory;
		
        parent::__construct($context);
    }
	
    /*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->_jsonFactory->create();
		
        $error = false;
		
        $messages = [];
		
        $sizestanderdItems = $this->getRequest()->getParam('items', []);
		
        if (!($this->getRequest()->getParam('isAjax') && count($sizestanderdItems))) 
		{
            return $resultJson->setData(
				[
					'messages' => [__('Please correct the data sent.')],
					'error' => true,
				]
			);
        }
		
        foreach (array_keys($sizestanderdItems) as $sizestanderdId) 
		{
            /** @var \Mageants\Advancesizechart\Model\Sizestanderd $sizestanderd */
            $sizestanderd = $this->_sizechartFactory->create()->load($sizestanderdId);
			
            try 
			{
                $sizestanderdData = $sizestanderdItems[$sizestanderdId];//todo: handle dates
				
                $sizestanderd->addData($sizestanderdData);
				
                $sizestanderd->save();
				
            } 
			catch (\Magento\Framework\Exception\LocalizedException $e) 
			{
                $messages[] = $this->getErrorWithSizestanderdId($sizestanderd, $e->getMessage());
				
                $error = true;
				
            } 
			catch (\RuntimeException $e) 
			{
                $messages[] = $this->getErrorWithSizestanderdId($sizestanderd, $e->getMessage());
				
                $error = true;
				
            } 
			catch (\Exception $e) 
			{
                $messages[] = $this->getErrorWithSizestanderdId(
                    $sizestanderd,
                    __('Something went wrong while saving the label.')
                );
				
                $error = true;
            }
        }
		
        return $resultJson->setData(
			[
				'messages' => $messages,
				'error' => $error
			]
		);
    }

    /**
     * Add Sizestanderd id to error message
     *
     * @param \Mageants\Advancesizechart\Model\Sizestanderd $sizestanderd
     * @param string $errorText
     * @return string
     */
    protected function getErrorWithSizestanderdId(\Mageants\Advancesizechart\Model\Sizestanderd $sizestanderd, $errorText)
    {
        return '[Sizestanderd ID: ' . $sizestanderd->getId() . '] ' . $errorText;
    }
}

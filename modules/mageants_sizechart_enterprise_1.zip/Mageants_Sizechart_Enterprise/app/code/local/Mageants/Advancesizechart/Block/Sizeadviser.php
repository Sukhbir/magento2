<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block;
 
use \Magento\Framework\View\Element\Template\Context;
use \Mageants\Advancesizechart\Helper\Data;
use \Magento\Framework\ObjectManagerInterface;
use \Mageants\Advancesizechart\Model\SizeadviserFactory;
use \Mageants\Advancesizechart\Model\SizedimensionFactory;
use \Mageants\Advancesizechart\Model\ResourceModel\Image;
use \Magento\Store\Model\StoreManagerInterface;
use \Mageants\Advancesizechart\Model\Source\SizechartDisplayType;
use \Mageants\Advancesizechart\Model\Source\SizeUnit;

/**
 * Class BlockRepository
 *
 * @package Mageants\Advancesizechart\Block
 */
 
class Sizeadviser extends \Magento\Framework\View\Element\Template
{
	/**
     * @var _settings
     */
	protected $_settings;
	/**
     * @var _sizeUnit
     */
	protected $_sizeUnit;
	/**
     * @var _advsizechart
     */
	protected $_advsizechart;
	/**
     * @var _sizeadviser
     */
	protected $_sizeadviser;
	/**
     * @var _sizeadviserFactory
     */
	protected $_sizeadviserFactory;
	/**
     * @var _sizestanderdFactory
     */
	protected $_sizedimensionFactory;
	
	 /**
     * @param Context $context,
	 * @param array $data = [],
	 * @param Data $helper,
	 * @param SizechartFactory $sizechartFactory,
	 * @param Image $imageFactory,
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
	public function __construct(
		Context $context,
		array $data = [],
		Data $helper,
		SizeUnit $sizeUnit,
		SizeadviserFactory $sizeadviserFactory,
		SizedimensionFactory $sizedimensionFactory,
		Image $imageFactory        
	) 
	{	
		parent::__construct($context, $data);
		
		$this->_helper = $helper;
		
		$this->_imageFactory = $imageFactory;
		
		$this->_sizeadviserFactory = $sizeadviserFactory;
		
		$this->_sizedimensionFactory = $sizedimensionFactory;
		
		$this->_sizeUnit = $sizeUnit;
	}
	/**
	 * Retrieve setAdvsizechart for current request 
	 *
     * @return sizechart
     */
    public function setAdvsizechart($sizechart)
    {
		$this->_advsizechart = $sizechart;
		
		$this->setSizeadviser();
		
		return $this;
    }
	
	/**
     * Retrieve getAdvsizechart for current request 
     *
     * @return sizechart
     */
	public function getAdvsizechart()
    {
		return $this->_advsizechart;
    }
	
	/**
     * Retrieve getSizeadviser for current request 
     *
     * @return sizechart
     */
	public function getSizeadviser()
    {
		return $this->_sizeadviser;
    }
	/**
     * Retrieve getAdviserId for current request 
     *
     * @return int
     */
	public function getAdviserId()
    {
		return $this->_sizeadviser->getId();
    }
	/**
     * Retrieve setSizeadviser for current request 
     *
     * @return sizechart
     */
	public function setSizeadviser()
    {
		$helper = $this->getSizechartHelper();
		
		$sizechart = $this->getAdvsizechart();
		
		$this->_settings = $helper->unserializeSetting($sizechart->getSetting());
		
		$adviserId = $this->getSiadviserId();
		
		$sizeadviser = false;
		
		if($adviserId)
		{
			$sizeadviserFactory = $this->_sizeadviserFactory->create();
			
			$sizeadviser = $sizeadviserFactory->load($adviserId);
		}
		
		$this->_sizeadviser = $sizeadviser;
    }
	
	/**
     * Retrieve getSiadviserId for current request 
     *
     * @return string
     */
	public function getSiadviserId()
    {
		return $this->_settings['size_adviser'];
    }
	/**
     * Retrieve getSizeUnit for current request 
     *
     * @return string
     */
	public function getSizeUnit()
    {
		$size_unit_id = $this->_sizeadviser->getSizeUnit();
		
		$size_units = $this->_sizeUnit->getOptionArray();
		
		return $size_units[$size_unit_id ];
    }
	/**
     * Retrieve getSizeDimension for current request 
     *
     * @return array
     */
	public function getSizeDimension()
    {
		$sizedimensionFactory = $this->_sizedimensionFactory->create();
		
		$sizedimensions = $sizedimensionFactory->getCollection();
		
		$sizedimensions->setOrder('sort_order','DESC');
		
		$dimensions = [];
		
		foreach($sizedimensions as $key=>$dimension)
		{
			$dimensions[$dimension->getDimensionCode()] = $dimension;
		}
		
		return $dimensions;
    }
	
	/**
     * Retrieve getSizeMeasurements for current request 
     *
     * @return sizechart
     */
	public function getSizeMeasurements()
    {
		$size_adviser = $this->getSizeadviser();
		
		$size_measurements = [];
		
		if($size_adviser)
		{
			$helper = $this->getSizechartHelper();
			
			$size_measurements = $helper->unserializeSetting($size_adviser->getSizeMeasurements());
		}
		
		return $size_measurements;
    }
	
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getSizechartHelper()
	{
		return $this->_helper;
	}
	
	/**
     * Retrieve Size Adviser Text
     *
     * @return string
     */
	public function getAdviserNote()
	{
		return $this->_helper->getAdviserNote();
	}
	/**
     *
     * @return string
     */
	public function getImage()
	{
		 $image = $this->getSizeadviser()->getImage();
		
		$imageFactory = $this->getSizechartImageHelper();
		
		return $imageFactory->getSizeChartUrl($image);
	}
	/**
     * Retrieve Image Model 
     *
     * @return imageFactory
     */
	public function getSizechartImageHelper()
	{
		return $this->_imageFactory;
	}
	
	/**
     * Retrieve current Store Id 
     *
     * @return store_id
     */
	public function getCurrentStoreId(){
		return $this->_storeManager->getStore()->getId();
	}
	
	
	/**
     * Retrieve current Store Id 
     *
     * @return string(color hexa)
     */
	function colorBrightness($hex, $percent) 
	{
		// Work out if hash given
		$hash = '';
		if (stristr($hex,'#')) {
			$hex = str_replace('#','',$hex);
			$hash = '#';
		}
		/// HEX TO RGB
		$rgb = array(hexdec(substr($hex,0,2)), hexdec(substr($hex,2,2)), hexdec(substr($hex,4,2)));
		//// CALCULATE 
		for ($i=0; $i<3; $i++) {
			// See if brighter or darker
			if ($percent > 0) {
				// Lighter
				$rgb[$i] = round($rgb[$i] * $percent) + round(255 * (1-$percent));
			} else {
				// Darker
				$positivePercent = $percent - ($percent*2);
				$rgb[$i] = round($rgb[$i] * $positivePercent) + round(0 * (1-$positivePercent));
			}
			// In case rounding up causes us to go to 256
			if ($rgb[$i] > 255) {
				$rgb[$i] = 255;
			}
		}
		//// RBG to Hex
		$hex = '';
		for($i=0; $i < 3; $i++) {
			// Convert the decimal digit to hex
			$hexDigit = dechex($rgb[$i]);
			// Add a leading zero if necessary
			if(strlen($hexDigit) == 1) {
			$hexDigit = "0" . $hexDigit;
			}
			// Append to the hex string
			$hex .= $hexDigit;
		}
		return $hash.$hex;
	}
}
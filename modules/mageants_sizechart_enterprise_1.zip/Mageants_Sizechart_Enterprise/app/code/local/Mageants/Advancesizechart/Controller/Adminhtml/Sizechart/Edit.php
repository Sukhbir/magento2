<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizechart;

use \Magento\Backend\Model\Session;
use \Magento\Framework\View\Result\PageFactory;
use \Magento\Framework\Controller\Result\JsonFactory;
use \Mageants\Advancesizechart\Model\SizechartFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;

class Edit extends \Mageants\Advancesizechart\Controller\Adminhtml\Sizechart
{
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::advancesizechart_new_edit';
    /**
     * Backend session
     * 
     * @var \Magento\Backend\Model\Session
     */
    protected $_backendSession;

    /**
     * Page factory
     * 
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * Result JSON factory
     * 
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * constructor
     * 
     * @param Session $backendSession
     * @param PageFactory $resultPageFactory
     * @param JsonFactory $resultJsonFactory
     * @param SizechartFactory $sizechartFactory
     * @param Registry $registry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory,
        SizechartFactory $sizechartFactory,
        Registry $registry,
        Context $context
    )
    {
        $this->_backendSession    = $context->getSession();
		
        $this->_resultPageFactory = $resultPageFactory;
		
        $this->_resultJsonFactory = $resultJsonFactory;
		
        parent::__construct($sizechartFactory, $registry,$context);
    }

    /*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
	

    /**
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Backend\Model\View\Result\Redirect|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
		
        /** @var \Mageants\Advancesizechart\Model\Sizechart $sizechart */
        $sizechart = $this->_initSizechart();
		
        /** @var \Magento\Backend\Model\View\Result\Page|\Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
		
        $resultPage->setActiveMenu('Mageants_Advancesizechart::sizechart');
		
        $resultPage->getConfig()->getTitle()->set(__('Sizechart'));
		
        if ($id) 
		{
            $sizechart->load($id);
			
            if (!$sizechart->getId()) 
			{
                $this->messageManager->addError(__('This Sizechart no longer exists.'));
				
                $resultRedirect = $this->_resultRedirectFactory->create();
				
                $resultRedirect->setPath(
                    'mageants_advancesizechart/*/edit',
                    [
                        'id' => $sizechart->getId(),
                        '_current' => true
                    ]
                );
				
                return $resultRedirect;
            }
        }
		
        $title = $sizechart->getId() ? $sizechart->getLabel() : __('New Sizechart');
		
        $resultPage->getConfig()->getTitle()->prepend($title);
		
        $data = $this->_backendSession->getData('mageants_advancesizechart_sizechart_data', true);
		
        if (!empty($data)) 
		{
            $sizechart->setData($data);
        }
		
        return $resultPage;
    }
}

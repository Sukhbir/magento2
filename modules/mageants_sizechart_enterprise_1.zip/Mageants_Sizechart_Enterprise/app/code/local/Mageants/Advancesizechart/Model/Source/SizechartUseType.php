<?php
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\Advancesizechart\Model\Source;

/**
 * Class Status
 * @package Mageants\Advancesizechart\Model\Source
 */
class SizechartUseType implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * 	Display as Popup
     */
    const USE_IMAGE = 0;
	
    /**
     *	Display bellow of "Add To Cart "
     */
    const USE_CONTENT = 1;

    /**
     * @return array
     */
    public function getOptionArray()
    {
        $optionArray = ['' => ' '];
        foreach ($this->toOptionArray() as $option) 
		{
            $optionArray[$option['value']] = $option['label'];
        }
		
        return $optionArray;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::USE_IMAGE,  'label' => __('Use Image')],
            ['value' => self::USE_CONTENT,  'label' => __('Use Content')],
        ];
    }
}

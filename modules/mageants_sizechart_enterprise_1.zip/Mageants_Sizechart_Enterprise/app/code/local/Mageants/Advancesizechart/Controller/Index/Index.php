<?php
namespace Mageants\Advancesizechart\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 use \Magento\Framework\View\Result\LayoutFactory;
 
class Index extends \Magento\Framework\App\Action\Action
{
    protected $_resultPageFactory;
 
    public function __construct(Context $context, LayoutFactory $resultLayoutFactory)
    {
         $this->_resultLayoutFactory = $resultLayoutFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {
		return $this->_resultLayoutFactory->create();
    }
}
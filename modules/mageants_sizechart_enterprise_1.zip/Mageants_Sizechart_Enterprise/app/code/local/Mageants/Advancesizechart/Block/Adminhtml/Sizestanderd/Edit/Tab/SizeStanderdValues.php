<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizestanderd\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;
use \Magento\Cms\Ui\Component\Listing\Column\Cms\Options;
use \Mageants\Advancesizechart\Helper\Data;

class SizeStanderdValues extends \Magento\Framework\View\Element\Template
{
	private $serilize_standerd_val = NULL;
	/**
     * @param Context $context,
	 * @param array $data = [],
	 * @param Data $helper,
	 * @param ObjectManagerInterface $objectManager,
	 * @param SizechartFactory $sizechartFactory,
	 * @param Image $imageFactory,
     * @param StoreManagerInterface $storeManager
     * @param CollectionFactory $productCollectionFactory
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
	public function __construct(
		Context $context,
		array $data = [],
		Data $helper		
	) 
	{	
		parent::__construct($context, $data);
		
		$this->_helper = $helper;
		
		$this->serilize_standerd_val = $data['standerd_serialize'];
		
		$this->setTemplate('advancesizechart/size_standerds/values.phtml');
	}
	
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getStandersValues()
	{
		$helper = $this->getHelper();
		
		$values = [''];
		
		if($this->serilize_standerd_val)
		{
			$values = $helper->unserializeSetting($this->serilize_standerd_val);
		}
		
		return $values;
	}
	
	
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getHelper()
	{
		return $this->_helper;
	}
	
}
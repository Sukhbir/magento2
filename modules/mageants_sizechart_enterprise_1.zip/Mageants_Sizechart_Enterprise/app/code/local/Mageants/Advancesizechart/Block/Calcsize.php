<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block;
 
use \Magento\Framework\View\Element\Template\Context;
use \Mageants\Advancesizechart\Helper\Data;
use \Mageants\Advancesizechart\Model\ResourceModel\Image;
use \Mageants\Advancesizechart\Model\Source\SizechartUseType;
use \Mageants\Advancesizechart\Model\SizeadviserFactory;

/**
 * Class BlockRepository
 *
 * @package Mageants\Advancesizechart\Block
 */
 
class Calcsize extends \Magento\Framework\View\Element\Template
{
	/**
     * @var _advsizechart
     */
	protected $_advsizechart;
		
	/**
     * @var _settings
     */
	protected $_settings;
		
	/**
     * @var _helper
     */
	protected $_helper;
		
	/**
     * @var _imageFactory
     */
	protected $_sizeadviser;
	/**
     * @var _imageFactory
     */
	protected $_imageFactory;
	/**
     * @var _sizeadviserFactory
     */
	protected $_sizeadviserFactory;	
    /**
     * @param Context $context,
	 * @param array $data = [],
	 * @param Data $helper
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
	public function __construct(
		Context $context,
		array $data = [],
		SizeadviserFactory $sizeadviserFactory,
		Data $helper
	) 
	{
		parent::__construct($context, $data);
	
		$this->_helper = $helper;
		
		$this->_sizeadviserFactory = $sizeadviserFactory;
		
		$this->initSizeadviser();
	}
	
	/**
     * @return null
     */
	public function initSizeadviser()
	{
		$adviserid = $this->getRequest()->getPost("adviserid");
	
		$sizeadviserFactory = $this->_sizeadviserFactory->create();

		$this->_sizeadviser = $sizeadviserFactory->load($adviserid);
	}
	/**
     * @return Sizeadviser
     */
	public function getSizeadviser()
	{
		return $this->_sizeadviser;
	}
	/**
     * @return Sizeadviser
     */
	public function getSizeMeasurements()
	{
		$sizeadviser = $this->getSizeadviser();
		
		$helper = $this->getSizechartHelper();
			
		return $helper->unserializeSetting($sizeadviser->getSizeMeasurements());
	}
	/**
     * @return sizechart
     */
    public function getSuggestedSize()
    {
		$user_measurement = $measurement = $this->getRequest()->getPost("measurement");
		
		$size_measurements = $this->getSizeMeasurements();
				
		$final_result = false;
		
		$result = $this->getSelectedDimenssionResult($user_measurement, $size_measurements);
		
		$result_count = array_count_values($result);
		
		$suggest_size = false;
		
		if(count($result_count) == 1)
		{
			reset($result_count);
			
			$suggest_size = key($result_count); // get first key or count result
			
			$final_result['match'] =[
				'suggest_size'=> $suggest_size,
				'message'=> __("Our Advise size is %1"," <i>".$suggest_size."</i>")
				]; 
				
			$final_result["approx"]= [];
				
		}
		else
		{
			list($match_dim, $appox_dim ) = $this->getApproxAndExactResult($result , $result_count);	
			
			if(!empty($match_dim))
			{
				$match_index_position = 0;
				
				$match_key = key($match_dim);

				$size_measurements_first_key =key($size_measurements);
				
				$size_measurements_match_approx = $size_measurements[$size_measurements_first_key][$match_key];
					
				
				$first_match_dim_key = key($match_dim);
				
				$suggest_size = $match_dim[$first_match_dim_key];
				
				$final_result["match"] =[
					'suggest_size'=> $suggest_size,
					'message'=> __("Your optimal size is %1 fit with %1 ","<i>".$suggest_size."</i> ",implode(", ",array_keys($match_dim)))
				]; 
				
				foreach($size_measurements_match_approx as $match_dim_key => $match_val )
				{
					$match_index_position++;
					
					if($suggest_size == $match_dim_key)
					{
						break;
					}
				}
			
				if(!empty($appox_dim))
				{	
					foreach($appox_dim as $approx_dim_key => $approx_val )
					{
						
						$size_measurements_approx = $size_measurements[$size_measurements_first_key][$approx_dim_key][$approx_val]; 
						
						$user_measurements_first_key = key($user_measurement);
						
						$user_measurement_approx = $user_measurement[$user_measurements_first_key][$approx_dim_key];
						
						$match_index_approx = 0;
						
						foreach($size_measurements_match_approx as $match_dim_key => $match_val )
						{
							$match_index_approx++;
							
							if($approx_val == $match_dim_key)
							{
								break;
							}
						}
						
						if($match_index_approx < $match_index_position)
						{
							$final_result["approx"][] =[
								'suggest_size'=> $approx_dim_key,
								'message'=> __(" Suggest size tight in %1",$approx_dim_key)
								];  	
						}
						else
						{
							$final_result["approx"][] =[
								'suggest_size'=> $approx_dim_key,
								'message'=> __(" Suggest size may be loose in %1",$approx_dim_key)
								];  
						}
					}
				}
				else
				{
					$final_result["approx"]= [];
				}
			}
			else
			{
				$final_result = false;
			}
		}
		
		return $final_result;
	}	
	
	/**
     *
     * @return array
     */
	public function getSelectedDimenssionResult($user_measurement = array() , $size_measurements = array())
    {
		$result = [];
		
		// Find Selected Dimension Size name 
		foreach($user_measurement as $standerd_id => $user_dimenssion_selection)
		{
			foreach($user_dimenssion_selection as $dimenssion_id => $dimenssion_value)
			{
				$dimenssions = $size_measurements[$standerd_id ][$dimenssion_id];
				
				foreach($dimenssions as $dimenssion=>$size_dimenssion_value)
				{
					if($dimenssion == 'increment_by') continue;
					
					$min = $size_dimenssion_value['min'];
					
					$max = $this->getMaxDimensionSize($size_dimenssion_value['min'] , $size_dimenssion_value['max']);
					
					if($dimenssion_value >= $min && $dimenssion_value <= $max)
					{
						$result[$dimenssion_id] = $dimenssion;
					}
				}
			}
		}
		return $result;
    }
	/**
     *
     * @return array
     */
	public function getApproxAndExactResult($result = array(), $result_count = array())
    {
		$match_dim = [];
		$appox_dim = [];
		
		$max_dim_count = max($result_count );
			
		$max_dim_val_key = array_search(max($result_count), $result_count);
		
		// Find Approx Matching size
		foreach($result_count as $dim_val_key => $dim_count)
		{
			if($max_dim_val_key != $dim_val_key)
			{					
				
				$appox_match_dim = array_search( $dim_val_key, $result);
				
				$appox_dim[$appox_match_dim] = $dim_val_key; 
			}
		}
		
		// Find Exact Matched size
		foreach($result as $dim_key => $dim_val)
		{
			if($max_dim_val_key == $dim_val)
			{					
				$match_dim[$dim_key] = $dim_val; 
			}
			
		}
		
		return array($match_dim, $appox_dim);
    }
	/**
     * Retrieve sizechart for current request 
     *
     * @return int
     */
	public function getMaxDimensionSize($min, $max)
    {
		$size_diff = $max - $min ;
		
		$talarance_size = ($size_diff * 10 / 100);
		
		$max_size = $talarance_size + $max;
		
		return $max_size;
    }
	/**
     * Retrieve sizechart for current request 
     *
     * @return array
     */
	public function getMessage()
    {
		return "may be a bit bigger in the Waist";
    }
	 
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getSizechartHelper()
	{
		return $this->_helper;
	}
	
}
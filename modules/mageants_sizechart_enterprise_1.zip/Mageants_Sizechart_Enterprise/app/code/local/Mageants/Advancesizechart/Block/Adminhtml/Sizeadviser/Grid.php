<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizeadviser;

class Grid extends \Magento\Backend\Block\Widget\Grid
{

}

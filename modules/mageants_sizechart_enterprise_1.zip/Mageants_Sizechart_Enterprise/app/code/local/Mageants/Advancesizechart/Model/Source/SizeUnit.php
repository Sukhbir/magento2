<?php
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\Advancesizechart\Model\Source;

/**
 * Class Status
 * @package Mageants\Advancesizechart\Model\Source
 */
class SizeUnit implements \Magento\Framework\Data\OptionSourceInterface
{
    /**
     * Status values
     */
    const UNIT_MM = 0;
    const UNIT_CM = 1;
    const UNIT_INCH = 2;

    /**
     * @return array
     */
    public function getOptionArray()
    {
        $optionArray = ['' => ' '];
        
		foreach ($this->toOptionArray() as $option) 
		{
            $optionArray[$option['value']] = $option['label'];
        }
		
        return $optionArray;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => self::UNIT_MM,  'label' => __('mm')],
            ['value' => self::UNIT_CM,  'label' => __('cm')],
            ['value' => self::UNIT_INCH,  'label' => __('Inches')],
        ];
    }
}

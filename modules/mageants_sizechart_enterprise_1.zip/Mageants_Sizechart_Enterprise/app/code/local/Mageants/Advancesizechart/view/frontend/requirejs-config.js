var config = {
	"map": {
	    "*": {
	    	"jquitouch": "Mageants_Advancesizechart/js/jquery.ui.touch-punch.min"	  
	    }
	},
	paths: {
		'mageants/jquitouch': 'Mageants_Advancesizechart/js/jquery.ui.touch-punch.min'
	},
	shim: {
	}
};

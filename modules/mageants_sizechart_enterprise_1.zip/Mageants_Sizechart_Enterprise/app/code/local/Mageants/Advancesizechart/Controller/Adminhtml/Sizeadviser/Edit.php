<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizeadviser;

use \Magento\Backend\Model\Session;
use \Magento\Framework\View\Result\PageFactory;
use \Magento\Framework\Controller\Result\JsonFactory;
use \Mageants\Advancesizechart\Model\SizeadviserFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;

class Edit extends \Mageants\Advancesizechart\Controller\Adminhtml\Sizeadviser
{
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::sizeadviser_new_edit';
    /**
     * Backend session
     * 
     * @var \Magento\Backend\Model\Session
     */
    protected $_backendSession;

    /**
     * Page factory
     * 
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;

    /**
     * Result JSON factory
     * 
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $_resultJsonFactory;

    /**
     * constructor
     * 
     * @param Session $backendSession
     * @param PageFactory $resultPageFactory
     * @param JsonFactory $resultJsonFactory
     * @param SizeadviserFactory $sizeadviserFactory
     * @param Registry $registry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory,
        SizeadviserFactory $sizeadviserFactory,
        Registry $registry,
        
        Context $context
    )
    {
        $this->_backendSession    = $context->getSession();
		
        $this->_resultPageFactory = $resultPageFactory;
		
        $this->_resultJsonFactory = $resultJsonFactory;
		
        parent::__construct($sizeadviserFactory, $registry,$context);
    }
	/*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
    /**
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Backend\Model\View\Result\Redirect|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
		
        /** @var \Mageants\Advancesizechart\Model\Sizeadviser $sizeadviser */
        $sizeadviser = $this->_initSizeadviser();
		
        /** @var \Magento\Backend\Model\View\Result\Page|\Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
		
        $resultPage->setActiveMenu('Mageants_Advancesizechart::sizechart');
		
        $resultPage->getConfig()->getTitle()->set(__('Size Adviser'));
		
        if ($id) 
		{
            $sizeadviser->load($id);
			
            if (!$sizeadviser->getId()) 
			{
                $this->messageManager->addError(__('This Sizeadviser no longer exists.'));
				
                $resultRedirect = $this->_resultRedirectFactory->create();
				
                $resultRedirect->setPath(
                    'mageants_advancesizechart/*/edit',
                    [
                        'id' => $sizeadviser->getId(),
                        '_current' => true
                    ]
                );
				
                return $resultRedirect;
            }
        }
		
        $title = $sizeadviser->getId() ? $sizeadviser->getLabel() : __('New Size Adviser');
		
        $resultPage->getConfig()->getTitle()->prepend($title);
		
        $data = $this->_backendSession->getData('mageants_advancesizechart_sizechart_data', true);
		
        if (!empty($data)) 
		{
            $sizeadviser->setData($data);
        }
		
        return $resultPage;
    }
}

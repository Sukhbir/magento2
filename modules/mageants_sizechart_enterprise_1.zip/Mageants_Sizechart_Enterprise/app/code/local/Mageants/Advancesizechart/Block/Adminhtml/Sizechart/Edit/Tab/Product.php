<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizechart\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;

class Product extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
	const FORM_NAME = 'mageants_sizechart_form';
	
    /**
     * constructor
     * 
     * @param Context $context
	 * @param Options $cmsOpt
	 * @param Yesno $yesNo
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        array $data = []
    )
    {	
		
	    parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Mageants\Advancesizechart\Model\Sizechart $sizechart */
        $sizechart = $this->_coreRegistry->registry('mageants_advancesizechart');	
		
		$productBlock = $this->getLayout()->createBlock(
            ProductGrid::class,
            null,
            ['data' => ['product_ids' => explode(',' ,$this->getProductIds())]]
        );
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('sizechart_product_');
        $form->setFieldNameSuffix('sizechart_product');
        
		 $fieldset = $form->addFieldset(
            'product_fieldset',
            [
                'legend' => __('Product'),
                'class'  => 'fieldset-wide'
            ]
        );
		
        $fieldset->addField(
            'product_grid_container',
            'note',
            [
                'label' => __('Product'),
                'title' => __('Product'),
                'text' => $productBlock->toHtml()
            ]
        );
	  
	   $fieldset->addField(
				'product_ids',
				'hidden',
				[
					'name' => 'product_ids',
					'data-form-part' => self::FORM_NAME,
					'after_element_js' =>$this->getProductIdsJs($this->getProductIds()),
				]
			);
			
 
		
       $sizechartData = $this->_session->getData('mageants_advancesizechart_sizechart_data', true);
	   
        if ($sizechartData) 
		{
		    $sizechart->addData($sizechartData);
        } 
		else 
		{
            if (!$sizechart->getId()) 
			{
			    $sizechart->addData($sizechart->getDefaultValues());
            }
        }
		
        $form->addValues($sizechart->getData()); 
		
        $this->setForm($form);
		
        return parent::_prepareForm();
    }
	
	/**
     * Retrive js code for Product Ids input field
     *
     * @return string
     */
	private function getProductIdsJs($prod_ids)
    {
        return <<<HTML
    <script type="text/javascript">		 
		  require([
				'mage/adminhtml/grid'
			], function(){
				new serializerController('sizechart_product_product_ids', [$prod_ids], [], productsGridJsObject, 'sizechart_product_product_ids');
			});				   
    </script>
HTML;
    }
    /**
     * Prepare Sizechart for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Products');
    }
    /**
     * Prepare Sizechart product ids
     *
     * @return string
     */
    public function getProductIds()
    {
		$updated_product_ids = [];
		
		$sizechart = $this->_coreRegistry->registry('mageants_advancesizechart');	
		
		$product_ids =  explode(',' ,$sizechart->getProductIds());
		
		foreach($product_ids as $product)
		{
			if(is_numeric($product)) 
				$updated_product_ids[] = $product;
		}
		
        return implode(",",$updated_product_ids);
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }

}

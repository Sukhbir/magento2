<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizestanderd;

class Delete extends \Mageants\Advancesizechart\Controller\Adminhtml\Sizestanderd
{		
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::sizestanderd_delete';
	
    /*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $resultRedirect = $this->_resultRedirectFactory->create();
		
        $id = $this->getRequest()->getParam('id');
		
        if ($id) 
		{
            $name = "";
			
            try 
			{
                /** @var \Mageants\Advancesizechart\Model\Sizestanderd $sizestanderd */
                $sizestanderd = $this->_sizechartFactory->create();
				
                $sizestanderd->load($id);
				
                $name = $sizestanderd->getName();
				
                $sizestanderd->delete();
				
                $this->messageManager->addSuccess(__('The Sizestanderd has been deleted.'));
				
                $this->_eventManager->dispatch(
                    'adminhtml_mageants_advancesizechart_sizechart_on_delete',
                    ['name' => $name, 'status' => 'success']
                );
				
                $resultRedirect->setPath('mageants_advancesizechart/*/');
				
                return $resultRedirect;
				
            } 
			catch (\Exception $e) 
			{
                $this->_eventManager->dispatch(
                    'adminhtml_mageants_advancesizechart_label_on_delete',
                    ['name' => $name, 'status' => 'fail']
                );
				
                // display error message
                $this->messageManager->addError($e->getMessage());
				
                // go back to edit form
                $resultRedirect->setPath('mageants_advancesizechart/*/edit', ['id' => $id]);
				
                return $resultRedirect;
            }
        }
		
        // display error message
        $this->messageManager->addError(__('Sizestanderd to delete was not found.'));
		
        // go to grid
        $resultRedirect->setPath('mageants_advancesizechart/*/');
		
        return $resultRedirect;
    }
}

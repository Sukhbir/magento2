<?php
/**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Model\Rule;

use Magento\Framework\App\RequestInterface;
use Mageants\Advancesizechart\Model\SizechartFactory;

/**
 * Class Validator
 * @package Mageants\Advancesizechart\Model\Rule
 */
class Validator
{
    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @param RequestInterface $request
     */
    public function __construct(
        RequestInterface $request
    ) {
        $this->request = $request;
    }

    /**
     * Is show Sizechart
     *
     * @param SizechartFactory $sizechartFactory
     * @return bool
     */
    public function canShow(SizechartFactory $sizechartFactory)
    {
		$currentProductId = $this->request->getParam('id');
		if (!$currentProductId) {
			return false;
		}
		$conditions = $sizechartFactory->getProductRule()->getConditions();
		if (isset($conditions)) {
			$match = $sizechartFactory->getProductRule()->getMatchingProductIds();
			if (in_array($currentProductId, $match)) {
				return true;
			}
		}

        return false;
    }
}

<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizechart;

use \Magento\Backend\Model\Session;
use \Mageants\Advancesizechart\Model\SizechartFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
use \Mageants\Advancesizechart\Helper\Data;
use \Mageants\Advancesizechart\Model\Upload;
use \Mageants\Advancesizechart\Model\ResourceModel\Image; 
		
class Save extends \Mageants\Advancesizechart\Controller\Adminhtml\Sizechart
{
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::advancesizechart_save';
	 /**
     * Upload model
     * 
     * @var \Mageants\Advancesizechart\Model\Upload
     */
    protected $_uploadModel;

    /**
     * Image model
     * 
     * @var \Mageants\Advancesizechart\Model\ResourceModel\Image
     */
    protected $_imageModel;
    
    /**
     * Backend session
     * 
     * @var \Magento\Backend\Model\Session
     */
    protected $_backendSession;
	
    /**
     * Sizechart Data Helper
     * 
     * @var \Mageants\Advancesizechart\Helper\Data
     */
    protected $_sizechartHelper; 
	
    /**
     * constructor
     * 
     * @param Upload $uploadModel
     * @param File $fileModel
     * @param Image $imageModel
     * @param Session $backendSession
     * @param SizechartFactory $sizechartFactory
     * @param Registry $registry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(        
        SizechartFactory $sizechartFactory,
        Registry $registry,
        
        Context $context,
		Upload $uploadModel,
		Image $imageModel, 
		Data $sizechartHelper
    )
    {
		
        $this->_backendSession    = $context->getSession();
		
		$this->_sizechartHelper = $sizechartHelper;
		
		$this->_uploadModel = $uploadModel;
		
		$this->_imageModel = $imageModel; 
		
        parent::__construct($sizechartFactory, $registry,$context);
    }
	/*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
	
    /**
     * run the action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $data = $this->getRequest()->getPost('sizechart');
		
        $ruledata = $this->getRequest()->getPost('rule');
		
		$productdata = $this->getRequest()->getPost('sizechart_product');
	
		$data['product_ids'] = str_replace(" ",'',str_replace('&', ', ',$productdata['product_ids']));
		
		$categorydata = $this->getRequest()->getPost('category');
		
		$data['category_ids'] =  str_replace(" ",'',$categorydata['category_ids']);
		
        $resultRedirect = $this->resultRedirectFactory->create();
		
        if ($data) 
		{
			
            $sizechart = $this->_initSizechart();
			
			$sizechartetting = $data['setting'];
			
			$sizechartetting['rule'] = [];
			
			$ruledata  = $this->convertRuleFlatDataAsRecursive($ruledata,['mageantssizechart']);
		
			if(is_array($ruledata['mageantssizechart'][1]))
			{ 	
				$ruledata = $ruledata['mageantssizechart'][1];
				
				if(!isset($ruledata['mageantssizechart']))
				{
					$ruledata['mageantssizechart'] = [];
				}
				
				$ruledata['conditions'] = $ruledata['mageantssizechart'] ;
				
				unset($ruledata['mageantssizechart'] );
				
				$sizechartetting['rule'] = $ruledata;
			}
			
			$data['setting'] =  $this->_sizechartHelper->serializeSetting($sizechartetting);
			
			
            $sizechart->setData($data);
			
			$image = $this->_uploadModel->uploadFileAndGetName('image', $this->_imageModel->getBaseDir(), $data,$this->messageManager);
			
			if($image == false)
			{
				$image = $sizechart->getImage($image);
			}
			
			$sizechart->setImage($image);
			
            $this->_eventManager->dispatch(
                'mageants_advancesizechart_sizechart_prepare_save',
                [
                    'sizechart' => $sizechart,
                    'request' => $this->getRequest()
                ]
            );
			
            try 
			{
                $sizechart->save();
				
                $this->messageManager->addSuccess(__('The Size Chart has been saved.'));
				
                $this->_backendSession->setMageantsAdvancesizechartData(false);
				
                if ($this->getRequest()->getParam('back')) 
				{
                    $resultRedirect->setPath(
                        'mageants_advancesizechart/*/edit',
                        [
                            'id' => $sizechart->getId(),
                            '_current' => true
                        ]
                    );
					
                    return $resultRedirect;
                }
				
                $resultRedirect->setPath('mageants_advancesizechart/*/');
				
                return $resultRedirect;
				
            } 
			catch (\Magento\Framework\Exception\LocalizedException $e) 
			{
                $this->messageManager->addError($e->getMessage());
            } 
			catch (\RuntimeException $e) 
			{
                $this->messageManager->addError($e->getMessage());
            } 
			catch (\Exception $e) 
			{
                $this->messageManager->addException($e, __('Something went wrong while saving the Sizechart.'));
            }
			
            $this->_getSession()->setMageantsAdvancesizechartPostData($data);
			
            $resultRedirect->setPath(
                'mageants_advancesizechart/*/edit',
                [
                    'id' => $sizechart->getId(),
                    '_current' => true
                ]
            );
			
            return $resultRedirect;
        }
		
        $resultRedirect->setPath('mageants_advancesizechart/*/');
		
        return $resultRedirect;
    }
	 /**
     * Get conditions data recursively
     *
     * @param array $data
     * @param array $allowedKeys
     * @return array
     */
    private function convertRuleFlatDataAsRecursive(array $data, $allowedKeys = [])
    {
        $result = [];
		
        foreach ($data as $key => $value) 
		{
            if (in_array($key, $allowedKeys) && is_array($value)) 
			{
                foreach ($value as $id => $data) 
				{
                    $path = explode('--', $id);
					
                    $node = & $result;

                    for ($i = 0, $l = sizeof($path); $i < $l; $i++) 
					{
                        if (!isset($node[$key][$path[$i]])) 
						{
                            $node[$key][$path[$i]] = [];
                        }
						
                        $node = & $node[$key][$path[$i]];

                    }
					
                    foreach ($data as $k => $v) 
					{
                        $node[$k] = $v;
                    }
                }
            }
        }
		
        return $result;
    }
	
}

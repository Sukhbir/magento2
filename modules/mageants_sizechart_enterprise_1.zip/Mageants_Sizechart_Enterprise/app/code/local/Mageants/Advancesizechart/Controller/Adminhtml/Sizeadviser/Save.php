<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizeadviser;

use \Magento\Backend\Model\Session;
use \Mageants\Advancesizechart\Model\SizeadviserFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
use \Mageants\Advancesizechart\Helper\Data;
use \Mageants\Advancesizechart\Model\Upload;
use \Mageants\Advancesizechart\Model\ResourceModel\Image; 
		
class Save extends \Mageants\Advancesizechart\Controller\Adminhtml\Sizeadviser
{
	
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::sizeadviser_save';
	 /**
     * Upload model
     * 
     * @var \Mageants\Advancesizechart\Model\Upload
     */
    protected $_uploadModel;

    /**
     * Image model
     * 
     * @var \Mageants\Advancesizechart\Model\ResourceModel\Image
     */
    protected $_imageModel;
    
    /**
     * Backend session
     * 
     * @var \Magento\Backend\Model\Session
     */
    protected $_backendSession;
	
    /**
     * Sizeadviser Data Helper
     * 
     * @var \Mageants\Advancesizechart\Helper\Data
     */
    protected $_sizechartHelper; 
	
    /**
     * constructor
     * 
     * @param Upload $uploadModel
     * @param File $fileModel
     * @param Image $imageModel
     * @param Session $backendSession
     * @param SizeadviserFactory $sizeadviserFactory
     * @param Registry $registry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        SizeadviserFactory $sizeadviserFactory,
        Registry $registry,
        
        Context $context,
		Upload $uploadModel,
		Image $imageModel, 
		Data $sizeadviserHelper
    )
    {
		
        $this->_backendSession    = $context->getSession();
		
		$this->_sizechartHelper = $sizeadviserHelper;		
		
		$this->_uploadModel = $uploadModel;
		
		$this->_imageModel = $imageModel; 
		
        parent::__construct($sizeadviserFactory, $registry,$context);
		
    }
	/*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
    /**
     * run the action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
		$sizeadviser = $this->_initSizeadviser();
			
        $data = $this->getRequest()->getPost('sizeadviser');
		
        $resultRedirect = $this->resultRedirectFactory->create();
		
        if ($data) 
		{	
			if(preg_match('/^[a-z_]+$/',$data['code']))
			{
				$data['dimensions'] =  implode(',',$data['dimensions']);
				
				$data['standerds'] =  implode(',',$data['standerds']);
				
				$measurement = $this->getRequest()->getPost('measurement');
					
				$data['size_measurements'] =  $this->_sizechartHelper->serializeSetting($measurement);
				
				$sizeadviser->setData($data);
				
				
				$image = $this->_uploadModel->uploadFileAndGetName('image', $this->_imageModel->getBaseDir(), $data,$this->messageManager);
				
				if($image == false)
				{
					$image = $sizeadviser->getImage($image);
				}
				
				$sizeadviser->setImage($image);
				
				$this->_eventManager->dispatch(
					'mageants_advancesizechart_sizeadviser_prepare_save',
					[
						'sizeadviser' => $sizeadviser,
						'request' => $this->getRequest()
					]
				);
				
				try 
				{
					$sizeadviser->save();
					
					$this->messageManager->addSuccess(__('The Size Adviser has been saved.'));
					
					$this->_backendSession->setMageantsAdvancesizechartData(false);
					
					if ($this->getRequest()->getParam('back')) 
					{
						$resultRedirect->setPath(
							'mageants_advancesizechart/*/edit',
							[
								'id' => $sizeadviser->getId(),
								'_current' => true
							]
						);
						
						return $resultRedirect;
					}
					
					$resultRedirect->setPath('mageants_advancesizechart/*/');
					
					return $resultRedirect;
					
				} 
				catch (\Magento\Framework\Exception\LocalizedException $e) 
				{
					$this->messageManager->addError($e->getMessage());
				} 
				catch (\RuntimeException $e) 
				{
					$this->messageManager->addError($e->getMessage());
				} 
				catch (\Exception $e) 
				{
					$this->messageManager->addException($e, __('Something went wrong while saving the Sizeadviser.'));
				}
				
				$this->_getSession()->setMageantsAdvancesizechartPostData($data);
				
				$resultRedirect->setPath(
					'mageants_advancesizechart/*/edit',
					[
						'id' => $sizeadviser->getId(),
						'_current' => true
					]
				);
				
				return $resultRedirect;
			}
			else{
				
				$this->messageManager->addError('Only small characters and underscore allow in code.');
				
				$resultRedirect->setPath(
						'mageants_advancesizechart/*/edit',
						[
							'id' => $sizeadviser->getId(),
							'_current' => true
						]
					);
				return $resultRedirect;
			}
		}
	
		$resultRedirect->setPath('mageants_advancesizechart/*/');
		
		return $resultRedirect;
    }
	
	
}

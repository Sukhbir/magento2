<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\Advancesizechart\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Store\Model\StoreManagerInterface;

class InstallSchema implements InstallSchemaInterface
{
	protected $StoreManager;         
	/*<b raw_pre="*" raw_post="*">     * Init     </b>     <b raw_pre="*" raw_post="*"> @param EavSetupFactory $eavSetupFactory     </b>/*/    
	public function __construct(StoreManagerInterface $StoreManager)       
	{                
		$this->StoreManager=$StoreManager;        
	}
	
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();
		
		/*Size Chart Table*/
		
        $table  = $installer->getConnection()
            ->newTable($installer->getTable('mageants_advancesizechart'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'sizechart_name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Chart Name'
            )
            ->addColumn(
                'setting',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null, 'nullable' => false],
                'Size Chart Setting  in json'
            )
			->addColumn(
                'store_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                1,
                [],
                'Store Id'
            )
			->addColumn(
                'status',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                1,
                [],
                'Status'
            )
            ->addColumn(
                'content',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null, 'nullable' => false],
                'Size Chart table content'
            )
			->addColumn(
                'image',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size chart Image Path'
            )
            ->addColumn(
                'category_ids',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                512,
                ['default' => null, 'nullable' => false],
                'size chart assigned to Categories Ids '
            )
            ->addColumn(
                'product_ids',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null, 'nullable' => false],
                'size chart assigned to Product Ids '
            )
            ->addColumn(
                'created_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Size Chart Created At'
            )
            ->addColumn(
                'updated_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Size Chart Updated At'
            )
			->addIndex(  
				$installer->getIdxName(  
					$installer->getTable('mageants_advancesizechart'),  
					['sizechart_name'],  
					\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
				),  
				['sizechart_name'],
				['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
			);
			
        $installer->getConnection()->createTable($table);
		
		
		/*Size Standerd Table */
		$table  = $installer->getConnection()
            ->newTable($installer->getTable('mageants_sizestandard'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'standerd_name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Standerd Name'
            )
            ->addColumn(
                'value',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null, 'nullable' => false],
                'Size Standerd values'
            )
            ->addColumn(
                'created_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Standerd Created At'
            )
            ->addColumn(
                'updated_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Standerd Updated At'
            )
			->addIndex(  
				$installer->getIdxName(  
					$installer->getTable('mageants_sizestandard'),  
					['standerd_name'],  
					\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
				),  
				['standerd_name'],
				['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
			);
			
        $installer->getConnection()->createTable($table);

		
		/*Size Dimensions Table*/
		 $table  = $installer->getConnection()
            ->newTable($installer->getTable('mageants_sizedimension'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'dimension_code',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Dimension Code'
            )
            ->addColumn(
                'label',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Dimension Label'
            )
            ->addColumn(
                'color',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Dimension Color'
            )
            ->addColumn(
                'created_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Dimension Created At'
            )
            ->addColumn(
                'updated_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Dimension Updated At'
            )
			->addIndex(  
				$installer->getIdxName(  
					$installer->getTable('mageants_sizedimension'),  
					['label','dimension_code'],  
					\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
				),  
				['label','dimension_code'],  
				['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
			);
			
        $installer->getConnection()->createTable($table);
			
		
		/*Size Dimensions Table*/
		$table  = $installer->getConnection()
            ->newTable($installer->getTable('mageants_sizeadviser'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Adviser Name'
            )
            ->addColumn(
                'code',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size  Adviser Code'
            )
			->addColumn(
                'image',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Adviser Image Path'
            )
			->addColumn(
                'dimensions',                
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Adviser Dimensions'
            )
			->addColumn(
                'standerds',                
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Adviser Standerd'
            )
			->addColumn(
                'size_measurements',                
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                null,
                ['default' => null, 'nullable' => false],
                'Size Adviser Measurements values'
            )
			->addColumn(
                'size_unit',                
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Adviser size unit '
            )
			->addColumn(
                'attech_attributes',                
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['default' => null, 'nullable' => false],
                'Size Adviser Atteched Attributes'
            )
			->addColumn(
                'status',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                1,
                [],
                'Status'
            )
            ->addColumn(
                'created_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Size Chart Created At'
            )
            ->addColumn(
                'updated_at',
                \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                null,
                [],
                'Size Chart Updated At'
            )
			->addIndex(  
				$installer->getIdxName(  
					$installer->getTable('mageants_sizeadviser'),  
					['name','code'],  
					\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT  
				),  
				['name','code'],  
				['type' => \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT]
			);
			
        $installer->getConnection()->createTable($table);
		
        $installer->endSetup();
		
		$service_url = 'https://www.mageants.com/index.php/rock/register/live?ext_name=Mageants_Advancesizechart&dom_name='.$this->StoreManager->getStore()->getBaseUrl();
		$curl = curl_init($service_url);     
		curl_setopt_array($curl, array(            
			CURLOPT_SSL_VERIFYPEER => false,            
			CURLOPT_RETURNTRANSFER => true,            
			CURLOPT_POST => true,            
			CURLOPT_FOLLOWLOCATION =>true,            
			CURLOPT_ENCODING=>'',            
			CURLOPT_USERAGENT => 'Mozilla/5.0'        
		));                
		$curl_response = curl_exec($curl);        
		curl_close($curl);
    }
}

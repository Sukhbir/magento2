<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml;

class Sizeadviser extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_sizeadviser';
		
        $this->_blockGroup = 'Mageants_Advancesizechart';
		
        $this->_headerText = __('Adviser');
		
        $this->_addButtonLabel = __('Create New Adviser');
		
        parent::_construct();
    }
}

<?php
/**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Ui\Component\Listing\Column;

use Mageants\Advancesizechart\Model\ResourceModel\Image;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\UrlInterface;

/**
 * Class Thumbnail
 * @package Mageants\Advancesizechart\Ui\Component\Listing\Columns
 */
class Thumbnail extends \Magento\Ui\Component\Listing\Columns\Column
{
    /**
     * @var ImageFileUploader
     */
    private $_imageFactory;

    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param ImageFileUploader $imageFileUploader
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        Image $imageFactory,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
		
        $this->urlBuilder = $urlBuilder;
		
        $this->_imageFactory = $imageFactory;
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) 
		{
			$fieldName = $this->getData('name');

			foreach ($dataSource['data']['items'] as & $item) 
			{
				
				if($item['image'])
				{
					$configData = $this->getData('config');
					
					$configData['has_preview'] = -1;
					
					$this->setData('config',$configData);
				
					$imgUrl = $this->_imageFactory->getSizeChartUrl($item['image']);
					
					$item[$fieldName . '_src'] = $item[$fieldName . '_orig_src'] = $imgUrl;
					
					$id =$item['id'];
							
					$item[$fieldName . '_link'] = $this->urlBuilder->getUrl(
						'mageants_advancesizechart/sizechart/edit',
						['id' => $id]
					);
				}					
			}
        }
        return $dataSource;
    }
}

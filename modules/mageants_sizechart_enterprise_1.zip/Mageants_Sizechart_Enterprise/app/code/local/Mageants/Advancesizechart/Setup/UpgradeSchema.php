<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */

namespace Mageants\Advancesizechart\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{
	
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
      if (version_compare($context->getVersion(), '2.0.1') < 0) {
            $setup->startSetup();
            $setup->getConnection()->addColumn(
                $setup->getTable('mageants_sizedimension'),
                'font_color',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length' => 255,
                    'nullable' => false,
                    'default' => 0,
                    'comment' => 'Font Color of Dimention Label'
                ]
            );
			
			 $setup->getConnection()->addColumn(
                $setup->getTable('mageants_sizedimension'),
                'sort_order',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'length' => 4,
                    'nullable' => false,
                    'default' => 0,
                    'comment' => 'Font Color of Dimention Label'
                ]
            );
            $setup->endSetup();
        }
    }
}

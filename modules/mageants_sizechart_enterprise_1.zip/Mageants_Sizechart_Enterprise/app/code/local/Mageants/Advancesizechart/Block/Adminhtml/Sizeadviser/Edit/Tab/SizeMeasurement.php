<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizeadviser\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;
use \Magento\Cms\Ui\Component\Listing\Column\Cms\Options;
use \Mageants\Advancesizechart\Helper\Data;
use \Mageants\Advancesizechart\Model\SizestanderdFactory;
use \Mageants\Advancesizechart\Model\SizedimensionFactory;
use \Mageants\Advancesizechart\Model\Source\SizeUnit;

class SizeMeasurement extends \Magento\Framework\View\Element\Template
{
    /**
     * Size MEasurement options
     * 
     */
	private $serilize_measurement_val = NULL;
	
    /**
     * Size unit options
     * 
     */
	private $size_unit = NULL;
	
    /**
     * Size Dimension options
     * 
     */
	private $dimension = NULL;
	
    /**
     * Size Standerd options
     * 
     */
	private $standerd = NULL;
	
    /**
     * Standerd Factory
     * 
     */
    protected $_sizestanderdFactory;
	
    /**
     * Dimension Factory
     * 
     */
    protected $_sizedimenstionFactory;
	
    /**
     * Size Unit  Source
     * 
     */
    protected $_sizeUnit;
	
	/**
     * @param Context $context,
	 * @param array $data = [],
	 * @param Data $helper,
	 * @param SizestanderdFactory $sizestanderdFactory,
	 * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
	public function __construct(
		Context $context,
		array $data = [],
		Data $helper,
		SizestanderdFactory $sizestanderdFactory,
		SizedimensionFactory $sizedimensionFactory,
		SizeUnit $sizeUnit
	) 
	{	
		parent::__construct($context, $data);
		
		$this->_helper = $helper;
		
		$this->serilize_measurement_val = $data['measurement'];
		
		$this->size_unit = $data['size_unit'];
		
		$this->dimension = $data['dimension'];
		
		$this->standerd = $data['standerd'];
		
		$this->sizedimensionFactory = $sizedimensionFactory->create();
		
		$this->sizestanderdFactory = $sizestanderdFactory->create();
		
		$this->_sizeUnit = $sizeUnit;
		
		$this->setTemplate('advancesizechart/size_measurement/measurement.phtml');
		
	}
	
	
	/**
     * Retrieve Size Dimension
     *
     * @return _helper
     */
	public function getDimensionValues()
	{
		$values = [];
		
		if($this->dimension)
		{
			$ids = explode(",",$this->dimension);
			
			$dimenstions = $this->sizedimensionFactory->getCollection();
			
			$dimenstions->addFieldToFilter('id' , array('in'=> $ids));
			
			$dimenstions->setOrder('sort_order','DESC');
			
			$values = $dimenstions;
		}
		
		return $values;
	}
	
	/**
     * Retrieve Size Mesaurments
     *
     * @return _helper
     */
	public function getStanderdValues()
	{
		$values = [];
		
		if($this->standerd)
		{
			$ids = explode(",",$this->standerd);
			
			$sizestanderds = $this->sizestanderdFactory->getCollection();
			
			$sizestanderds->addFieldToFilter('id', array('in'=> $ids));
			
			$values = $sizestanderds;
		}
		
		return $values;
	}
	/**
     * Retrieve Size Mesaurments
     *
     * @return _helper
     */
	public function getMeasurementValues()
	{
		$helper = $this->getHelper();
		
		$values = [''];
		
		if($this->serilize_measurement_val)
		{
			$values = $helper->unserializeSetting($this->serilize_measurement_val);
		}
		
		return $values;
	}
	
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getSizeUnit()
	{
		$sizeUnit = $this->_sizeUnit->getOptionArray();

		return $sizeUnit[$this->size_unit];
	}
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getHelper()
	{
		return $this->_helper;
	}
	
}
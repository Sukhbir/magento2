<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block;
 
use \Magento\Framework\View\Element\Template\Context;
use \Mageants\Advancesizechart\Helper\Data;
use \Mageants\Advancesizechart\Model\ResourceModel\Image;
use \Mageants\Advancesizechart\Model\Source\SizechartUseType;

/**
 * Class BlockRepository
 *
 * @package Mageants\Advancesizechart\Block
 */
 
class Sizechart extends \Magento\Framework\View\Element\Template
{
	/**
     * @var _advsizechart
     */
	protected $_advsizechart;
		
	/**
     * @var _settings
     */
	protected $_settings;
		
	/**
     * @var _helper
     */
	protected $_helper;
		
	/**
     * @var _imageFactory
     */
	protected $_imageFactory;
		
    /**
     * @param Context $context,
	 * @param array $data = [],
	 * @param Data $helper
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
	public function __construct(
		Context $context,
		array $data = [],
		Data $helper,
		Image	$imageFactory
	) 
	{
		parent::__construct($context, $data);
	
		$this->_helper = $helper;
		
		$this->_imageFactory = $imageFactory;
	}
	
	/**
     * @return sizechart
     */
    public function getSizechartContent()
    {
		$sizechart = $this->getAdvsizechart();
		
	
		if($this->isUseImage())
		{
			$imageFactory = $this->getSizechartImageHelper();
			
			$image_url = $imageFactory->getSizeChartUrl($sizechart->getImage());
			
			$image = "<img src='{$image_url}'/>";
			
			return $image;
		}
		else
		{
			return $sizechart->getContent();
		}
		
		
	}
	/**
     * @return bool
     */
	public function isUseImage()
	{
		return $this->_settings['use_image_content'] == SizechartUseType::USE_IMAGE ? true : false;		
	}
	/**
     * @return sizechart
     */
    public function setAdvsizechart($sizechart)
    {
		$this->_advsizechart = $sizechart;
		
		$helper = $this->getSizechartHelper();
		
		$this->_settings =  $helper->unserializeSetting($sizechart->getSetting());
		
		return $this;
    }
	
	/**
     * Retrieve sizechart for current request 
     *
     * @return sizechart
     */
	public function getAdvsizechart()
    {
		return $this->_advsizechart;
    }
	 
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getSizechartHelper()
	{
		return $this->_helper;
	}
	
	/**
     * Retrieve Image Model 
     *
     * @return imageFactory
     */
	public function getSizechartImageHelper()
	{
		return $this->_imageFactory;
	}
}
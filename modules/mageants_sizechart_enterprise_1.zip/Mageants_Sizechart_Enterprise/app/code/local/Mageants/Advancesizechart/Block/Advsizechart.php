<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block;
 
use \Magento\Framework\View\Element\Template\Context;
use \Mageants\Advancesizechart\Helper\Data;
use \Magento\Framework\ObjectManagerInterface;
use \Mageants\Advancesizechart\Model\SizechartFactory;
use \Mageants\Advancesizechart\Model\ResourceModel\Image;
use \Magento\Store\Model\StoreManagerInterface;
use \Mageants\Advancesizechart\Model\Source\SizechartDisplayType;
use \Mageants\Advancesizechart\Model\Rule\Product;
use \Mageants\Advancesizechart\Model\Rule\ProductFactory;
use \Magento\Framework\Registry;

/**
 * Class BlockRepository
 *
 * @package Mageants\Advancesizechart\Block
 */
 
class Advsizechart extends \Magento\Framework\View\Element\Template
{
	/**
     * @var _storeManager
     */
	protected $_storeManager;
	/**
     * @var _objectManager
     */
	protected $_objectManager;
	/**
     * @var _sizechartFactory
     */
	protected $_sizechartFactory;
	
	/**
     * @var _imageFactory
     */
	protected $_imageFactory;
    
	/**
     * @var _advsizechart
     */
	protected $_advsizechart;
	
	/**
     * @var array
     */
	protected $_settings;
	
    /**
     * @param Context $context,
	 * @param array $data = [],
	 * @param Data $helper,
	 * @param ObjectManagerInterface $objectManager,
	 * @param SizechartFactory $sizechartFactory,
	 * @param Image $imageFactory,
     * @param StoreManagerInterface $storeManager
     * @param CollectionFactory $productCollectionFactory
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
	public function __construct(
		Context $context,
		array $data = [],
		Data $helper,
		ObjectManagerInterface $objectManager,
		SizechartFactory $sizechartFactory,
		Image $imageFactory,
		ProductFactory $productRuleFactory,
		Registry $coreRegistry
	) 
	{	
		parent::__construct($context, $data);
		
		$this->_helper = $helper;
		
		$this->_storeManager = $context->getStoreManager();
		
		$this->_objectManager = $objectManager;
	 	
		$this->_sizechartFactory = $sizechartFactory;
		
		$this->_imageFactory = $imageFactory;
		
		$this->productRuleFactory = $productRuleFactory;
		
		$this->_coreRegistry = $coreRegistry;
		
		$this->_advsizechart = $this->getSizechart();		
	}
	
	/**
     * Retrieve sizechart for current request 
     *
     * @return sizechart
     */
    public function getAdvsizechart()
    {
		return $this->_advsizechart;
	}
	/**
     * Retrieve sizechart for current request 
     *
     * @return sizechart
     */
    private function getSizechart()
    {
		$helper = $this->getSizechartHelper();
		
		$sizechart = false;
		
		if($helper->isExtentionEnable())
		{
			$this->_currentProduct = $this->_coreRegistry->registry('current_product');
			
			$currentProductId = $this->_currentProduct->getId();
			
			if($this->_currentProduct &&  $currentProductId  && !$this->_advsizechart)
			{	
		
				$sizechartFactory = $this->_sizechartFactory->create();
				
				 foreach($this->_currentProduct->getCategoryIds() as $catId)
				{
					$fields_list[] = 'category_ids';
					$fields_list_value[] = array('finset'=> array($catId));
					
				}
				
				$fields_list[] ='product_ids';
				
				$fields_list_value[] = ['finset'=> array($currentProductId)];
				
				$sizechart = $sizechartFactory->getCollection()
								->addFieldToFilter('store_id', array('in' => array($this->getCurrentStoreId(),0)))
								->addFieldToFilter('status', array('eq' => 1))
								->addFieldToFilter($fields_list, $fields_list_value)
								->getFirstItem();		
				if($sizechart->getId())
				{
					$this->_settings =  $helper->unserializeSetting($sizechart->getSetting());
					
					$rules = $this->getRules();
					
					if (isset($rules) &&  !empty($rules)) 
					{
						$this->productRule = $this->productRuleFactory->create();

						$this->productRule->setConditions([])
							->getConditions()
							->loadArray($rules);

						$match = $this->productRule->getMatchingProductIds( $currentProductId);
						
						if (!in_array($currentProductId, $match)) 
						{
							return false;
						}
					}
					
					return $sizechart;
				}
			}
		}
		return false;
    }
		/**
     *
     * @return array
     */
	public function getRules()
	{
		return isset($this->_settings['rule'] ) ? $this->_settings['rule'] : [];
	}
	/**
     *
     * @return boot
     */
	public function isPopupEnable()
	{
		return $this->_settings['display_type']  == SizechartDisplayType::DISPLAY_POPUP ? true : false;
	}
	/**
     *
     * @return string
     */
	public function getLinkLabel()
	{
		return $this->_settings['link_label'] ;
	}
	/**
     *
     * @return string
     */
	public function getIcon()
	{
		$helper = $this->getSizechartHelper();
		
		$imageFactory = $this->getSizechartImageHelper();
		
		return $imageFactory->getSizechartIcon($helper->getSizechartIcon());
	}
	
	/**
     *
     * @return boot
     */
	public function isAdviserEnable()
	{
		return $this->_settings['enable_size_adviser']  ? true : false;
	}
	/**
     *
     * @return array
     */
	public function getTabs()
	{
		$sizehelper = $this->getSizechartHelper();
		
		$sizechart = $this->getAdvsizechart();
		
		$tabs = [];
		
		$tabs['sizechart']['block'] = $this->getChildBlock('sizechart')->setAdvsizechart($sizechart)->toHtml();;
		
		$tabs['sizechart']['title'] = $sizehelper->getSizeChartTabLabel();
		
		 if($this->isAdviserEnable())
		{
			$adviser_tab_label = $sizehelper->getSizeAdviserTabLabel();
		
			$adviser_result_tab_label = $sizehelper->getAdviserResultTabLabel();
			
			$tabs['sizechart']['title'] .= " <span class='scount'>(".__('Step 1').")</span> ";
			
			$tabs['sizeadviser']['block'] = $this->getChildBlock('sizeadviser')->setAdvsizechart($sizechart)->toHtml();
			
			$tabs['sizeadviser']['title'] = "{$adviser_tab_label} <span class='scount'>(".__('Step 2').")</span>";
			
			$tabs['adviserresult']['block'] = $this->getChildBlock('adviserresult')->toHtml();;
			
			$tabs['adviserresult']['title'] = "{$adviser_result_tab_label} <span class='scount'>(".__('Step 3').")</span>";
		} 
		
		return $tabs;
	} 
	 
	/**
     *
     * @return boot
     */
	public function isSizechartAvailable()
	{
		return $this->_advsizechart ? true : false;
	}
	 
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getSizechartHelper()
	{
		return $this->_helper;
	}
	/**
     * Retrieve Module Data Helper
     *
     * @return _helper
     */
	public function getSizeChartPopupLabel()
	{
		return $this->getSizechartHelper()->getSizeChartPopupLabel();
	}
	
	/**
     * Retrieve Image Model 
     *
     * @return imageFactory
     */
	public function getSizechartImageHelper()
	{
		return $this->_imageFactory;
	}
	
	/**
     * Retrieve current Store Id 
     *
     * @return store_id
     */
	public function getCurrentStoreId(){
		return $this->_storeManager->getStore()->getId();
	}
}
<?php
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
 
namespace Mageants\Advancesizechart\Model;

class Sizestanderd extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
		
		$this->_init('Mageants\Advancesizechart\Model\ResourceModel\Sizestanderd');
    }
	
    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}

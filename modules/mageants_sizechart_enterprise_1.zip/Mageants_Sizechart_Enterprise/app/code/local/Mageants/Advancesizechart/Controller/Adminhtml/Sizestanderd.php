<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml;

use \Mageants\Advancesizechart\Model\SizestanderdFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
		
abstract class Sizestanderd extends \Magento\Backend\App\Action
{
    /**
     * Post Factory
     * 
     * @var \Mageants\Advancesizechart\Model\SizestanderdFactory
     */
    protected $_sizechartFactory;

    /**
     * Core registry
     * 
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * Result redirect factory
     * 
     * @var \Magento\Backend\Model\View\Result\RedirectFactory
     */
    protected $_resultRedirectFactory;

    /**
     * constructor
     * 
     * @param SizestanderdFactory $sizestanderdFactory
     * @param Registry $coreRegistry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        SizestanderdFactory $sizestanderdFactory,
        Registry $coreRegistry,
        Context $context
    )
    {
        $this->_sizechartFactory           = $sizestanderdFactory;
		
        $this->_coreRegistry          = $coreRegistry;
		
        $this->_resultRedirectFactory = $context->getResultRedirectFactory();
		
        parent::__construct($context);
    }

    /**
     * Init Size Chart
     *
     * @return \Mageants\Advancesizechart\Model\Sizestanderd
     */
    protected function _initSizestanderd()
    {
        $sizestanderdid  = (int) $this->getRequest()->getParam('id');
		
		if(!$sizestanderdid )
	   {
		   $sizestanderd  =  $this->getRequest()->getParam('sizestanderd');
		  
 		   if(isset($sizestanderd['id']))
				$sizestanderdid = (int)$sizestanderd['id'];
	   }
	   
        /** @var \Mageants\Advancesizechart\Model\Sizestanderd $sizestanderd */
        $sizestanderd    = $this->_sizechartFactory->create();
		
        if ($sizestanderdid) 
		{
            $sizestanderd->load($sizestanderdid);
        }
		
        $this->_coreRegistry->register('mageants_sizestandard', $sizestanderd);
		
        return $sizestanderd;
    }
}

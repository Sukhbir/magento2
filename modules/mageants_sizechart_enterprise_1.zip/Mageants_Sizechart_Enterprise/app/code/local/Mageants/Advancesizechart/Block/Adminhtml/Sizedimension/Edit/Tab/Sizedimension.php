<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizedimension\Edit\Tab;

use \Magento\Backend\Block\Template\Context;
use \Magento\Framework\Registry;
use \Magento\Framework\Data\FormFactory;
use \Magento\Cms\Ui\Component\Listing\Column\Cms\Options;

class Sizedimension extends \Magento\Backend\Block\Widget\Form\Generic implements \Magento\Backend\Block\Widget\Tab\TabInterface
{
    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Mageants\Advancesizechart\Model\Sizedimension $sizedimension */
        $sizedimension = $this->_coreRegistry->registry('mageants_sizedimension');
		
        $form = $this->_formFactory->create();
		
        $form->setHtmlIdPrefix('sizedimension_');
        $form->setFieldNameSuffix('sizedimension');
        
		 $fieldset = $form->addFieldset(
            'base_fieldset',
            [
                'legend' => __('Sizedimension Information'),
                'class'  => 'fieldset-wide'
            ]
        );
		 
	 $fieldset->addType('color', 'Mageants\Advancesizechart\Block\Adminhtml\Sizedimension\Helper\Color');
	 $fieldset->addType('number', 'Mageants\Advancesizechart\Block\Adminhtml\Sizedimension\Helper\Number');
	 
      if ($sizedimension->getId()) 
	  {
            $fieldset->addField(
                'id',
                'hidden',
                ['name' => 'id']
            );
        }
		
        $fieldset->addField(
            'dimension_code',
            'text',
            [
                'name'  => 'dimension_code',
                'label' => __('Dimension Code'),
                'title' => __('Dimension Code'),
                'required' => true,
				'note' => 'Must be unique and small latters'
            ]
        );
		
        $fieldset->addField(
            'label',
            'text',
            [
                'name'  => 'label',
                'label' => __('Dimension Label'),
                'title' => __('Dimension Label'),
                'required' => true,				
            ]
        );
		
        $fieldset->addField(
            'color',
            'color',
            [
                'name'  => 'color',
                'label' => __('Background Color : '),
                'title' => __('Background Color : '),
                'required' => true,
				'style'=> "width:50px"
            ]
        );
		
        $fieldset->addField(
            'font_color',
            'color',
            [
                'name'  => 'font_color',
                'label' => __('Font Color : '),
                'title' => __('Font Color : '),
                'required' => true,
				'style'=> "width:50px"
            ]
        );
        $fieldset->addField(
            'sort_order',
            'number',
            [
                'name'  => 'sort_order',
                'label' => __('Sort Order : '),
                'title' => __('Sort Order: '),
                'required' => true,
				'style'=> "width:100px",
				"min"=>0,
            ]
        );
		
       $sizedimensionData = $this->_session->getData('mageants_advancesizechart_sizedimension_data', true);
	   
        if ($sizedimensionData) 
		{
		    $sizedimension->addData($sizedimensionData);
        } 
		else 
		{
            if (!$sizedimension->getId()) 
			{
			    $sizedimension->addData($sizedimension->getDefaultValues());
            }
        }
		
        $form->addValues($sizedimension->getData()); 
		
        $this->setForm($form);
		
        return parent::_prepareForm();
    }

	
    /**
     * Prepare Sizedimension for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('General');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return $this->getTabLabel();
    }

    /**
     * Can show tab in tabs
     *
     * @return boolean
     */
    public function canShowTab()
    {
        return true;
    }

    /**
     * Tab is hidden
     *
     * @return boolean
     */
    public function isHidden()
    {
        return false;
    }

}

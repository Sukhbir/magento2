<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml;

class Sizestanderd extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * constructor
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_controller = 'adminhtml_sizechart';
		
        $this->_blockGroup = 'Mageants_Advancesizechart';
		
        $this->_headerText = __('Sizestanderd');
		
        $this->_addButtonLabel = __('Create New Standerd');
		
        parent::_construct();
    }
}

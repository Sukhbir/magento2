<?php
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
 
namespace Mageants\Advancesizechart\Model;
 
use Mageants\Advancesizechart\Model\ResourceModel\Sizechart as ResourceSizechart;
use Mageants\Advancesizechart\Model\Rule\ProductFactory;
use Mageants\Advancesizechart\Model\Rule\Product;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;

class Sizechart extends \Magento\Framework\Model\AbstractModel
{
	/**
     * @var ProductFactory
     */
    private $productRuleFactory;
	 /**
     * @param Context $context
     * @param Registry $registry
     * @param ProductFactory $productRuleFactory
     * @param ConditionConverter $conditionConverter
     * @param ResourceSizechart|null $resource
     * @param ResourceSizechart\Collection|null $resourceCollection
     */
    public function __construct(
        Context $context,
        Registry $registry,
        ProductFactory $productRuleFactory,
        ResourceSizechart $resource = null,
        ResourceSizechart\Collection $resourceCollection = null
    ) {
        parent::__construct($context, $registry, $resource, $resourceCollection);
        
		$this->productRuleFactory = $productRuleFactory;		
    }
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
		parent::_construct();
		
        $this->_init('Mageants\Advancesizechart\Model\ResourceModel\Sizechart');
    }
	
    /**
     *
     * @return default values for edit
     */
    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
		
    /**
     *
     * @return Sizechart rule
     */
     public function getProductRule()
    {
        if (!$this->productRule) 
		{
            $conditionArray =[];// $this->conditionConverter->dataModelToArray($this->getProductCondition());
			
            $this->productRule = $this->productRuleFactory->create();
			
            $this->productRule->setConditions([])
                ->getConditions()
                ->loadArray($conditionArray);
        }

        return $this->productRule;
    }
	
}

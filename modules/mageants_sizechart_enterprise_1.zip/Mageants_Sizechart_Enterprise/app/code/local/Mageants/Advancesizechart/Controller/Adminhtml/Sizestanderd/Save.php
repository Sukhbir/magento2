<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizestanderd;

use \Magento\Backend\Model\Session;
use \Mageants\Advancesizechart\Model\SizestanderdFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
use \Mageants\Advancesizechart\Helper\Data;
		
class Save extends \Mageants\Advancesizechart\Controller\Adminhtml\Sizestanderd
{		
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::sizestanderd_save';
	 /**
     * Upload model
     * 
     * @var \Mageants\Advancesizechart\Model\Upload
     */
    protected $_uploadModel;

    /**
     * Image model
     * 
     * @var \Mageants\Advancesizechart\Model\ResourceModel\Image
     */
    protected $_imageModel;
    
    /**
     * Backend session
     * 
     * @var \Magento\Backend\Model\Session
     */
    protected $_backendSession;
	
    /**
     * Sizestanderd Data Helper
     * 
     * @var \Mageants\Advancesizechart\Helper\Data
     */
    protected $_sizechartHelper; 
	
    /**
     * constructor
     * 
     * @param Upload $uploadModel
     * @param File $fileModel
     * @param Image $imageModel
     * @param Session $backendSession
     * @param SizestanderdFactory $sizestanderdFactory
     * @param Registry $registry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        SizestanderdFactory $sizestanderdFactory,
        Registry $registry,
        
        Context $context,
		Data $sizestanderdHelper
    )
    {
		
        $this->_backendSession    = $context->getSession();
		
		$this->_sizechartHelper = $sizestanderdHelper;
		
		
        parent::__construct($sizestanderdFactory, $registry,$context);
    }
	
    /*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
    /**
     * run the action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
		$sizestanderd = $this->_initSizestanderd();
			
        $data = $this->getRequest()->getPost('sizestanderd');
		
        $resultRedirect = $this->resultRedirectFactory->create();
		
        if ($data) 
		{	
			$data['value'] =  $this->_sizechartHelper->serializeSetting(array_filter($data['value']));
			
            $sizestanderd->setData($data);
			
            $this->_eventManager->dispatch(
                'mageants_advancesizechart_sizestanderd_prepare_save',
                [
                    'sizechart' => $sizestanderd,
                    'request' => $this->getRequest()
                ]
            );
			
            try 
			{
                $sizestanderd->save();
				
                $this->messageManager->addSuccess(__('The Size Standerd has been saved.'));
				
                $this->_backendSession->setMageantsAdvancesizechartData(false);
				
                if ($this->getRequest()->getParam('back')) 
				{
                    $resultRedirect->setPath(
                        'mageants_advancesizechart/*/edit',
                        [
                            'id' => $sizestanderd->getId(),
                            '_current' => true
                        ]
                    );
					
                    return $resultRedirect;
                }
				
                $resultRedirect->setPath('mageants_advancesizechart/*/');
				
                return $resultRedirect;
				
            } 
			catch (\Magento\Framework\Exception\LocalizedException $e) 
			{
                $this->messageManager->addError($e->getMessage());
            } 
			catch (\RuntimeException $e) 
			{
                $this->messageManager->addError($e->getMessage());
            } 
			catch (\Exception $e) 
			{
                $this->messageManager->addException($e, __('Something went wrong while saving the Sizestanderd.'));
            }
			
            $this->_getSession()->setMageantsAdvancesizechartPostData($data);
			
            $resultRedirect->setPath(
                'mageants_advancesizechart/*/edit',
                [
                    'id' => $sizestanderd->getId(),
                    '_current' => true
                ]
            );
			
            return $resultRedirect;
        }
		
        $resultRedirect->setPath('mageants_advancesizechart/*/');
		
        return $resultRedirect;
    }
	 /**
     * Get conditions data recursively
     *
     * @param array $data
     * @param array $allowedKeys
     * @return array
     */
    private function convertRuleFlatDataAsRecursive(array $data, $allowedKeys = [])
    {
        $result = [];
		
        foreach ($data as $key => $value) 
		{
            if (in_array($key, $allowedKeys) && is_array($value)) 
			{
                foreach ($value as $id => $data) 
				{
                    $path = explode('--', $id);
					
                    $node = & $result;

                    for ($i = 0, $l = sizeof($path); $i < $l; $i++) 
					{
                        if (!isset($node[$key][$path[$i]])) 
						{
                            $node[$key][$path[$i]] = [];
                        }
						
                        $node = & $node[$key][$path[$i]];

                    }
					
                    foreach ($data as $k => $v) 
					{
                        $node[$k] = $v;
                    }
                }
            }
        }
		
        return $result;
    }
	
}

<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Block\Adminhtml\Sizeadviser;

use \Magento\Framework\Registry;
use \Magento\Backend\Block\Widget\Context;
		
class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
    /**
     * Core registry
     * 
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry;

    /**
     * constructor
     * 
     * @param Registry $coreRegistry
     * @param Context $context
     * @param array $data
     */
    public function __construct(
        Registry $coreRegistry,
        Context $context,
        array $data = []
    )
    {
        $this->_coreRegistry = $coreRegistry;
		
        parent::__construct($context, $data);
    }

    
    /**
     * Initialize Size Chart edit block
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_objectId = 'id';
        
		$this->_blockGroup = 'Mageants_Advancesizechart';
        
		$this->_controller = 'adminhtml_sizeadviser';
		
        parent::_construct();
        
		$this->buttonList->update('save', 'label', __('Save Size Adviser'));
        
		$this->buttonList->add(
            'save-and-continue',
            [
                'label' => __('Save and Continue Edit'),
                'class' => 'save',
                'data_attribute' => [
                    'mage-init' => [
                        'button' => [
                            'event' => 'saveAndContinueEdit',
                            'target' => '#edit_form'
                        ]
                    ]
                ]
            ],
            -100
        );
    }
	
    /**
     * Retrieve text for header element depending on loaded 
     *
     * @return string
     */
    public function getHeaderText()
    {
        $sizeadviser = $this->_coreRegistry->registry('mageants_sizeadviser');
        
		if ($sizeadviser->getId()) 
		{
            return __("Edit Adviser '%1'", $this->escapeHtml($sizeadviser->getName()));
        }
		
        return __('New Adviser');
    }
}

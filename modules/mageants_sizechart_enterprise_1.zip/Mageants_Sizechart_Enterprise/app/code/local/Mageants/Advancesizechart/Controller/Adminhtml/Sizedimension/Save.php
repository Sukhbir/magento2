<?php
 /**
 * @category Mageants Advancesizechart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Controller\Adminhtml\Sizedimension;

use \Magento\Backend\Model\Session;
use \Mageants\Advancesizechart\Model\SizedimensionFactory;
use \Magento\Framework\Registry;
use \Magento\Backend\Model\View\Result\RedirectFactory;
use \Magento\Backend\App\Action\Context;
use \Mageants\Advancesizechart\Helper\Data;
		
class Save extends \Mageants\Advancesizechart\Controller\Adminhtml\Sizedimension
{	
	/**
     * Access Resource ID
     * 
     */
	const RESOURCE_ID = 'Mageants_Advancesizechart::sizedimension_save';
	 /**
     * Upload model
     * 
     * @var \Mageants\Advancesizechart\Model\Upload
     */
    protected $_uploadModel;

    /**
     * Image model
     * 
     * @var \Mageants\Advancesizechart\Model\ResourceModel\Image
     */
    protected $_imageModel;
    
    /**
     * Backend session
     * 
     * @var \Magento\Backend\Model\Session
     */
    protected $_backendSession;
	
    /**
     * Sizedimension Data Helper
     * 
     * @var \Mageants\Advancesizechart\Helper\Data
     */
    protected $_sizechartHelper; 
	
    /**
     * constructor
     * 
     * @param Upload $uploadModel
     * @param File $fileModel
     * @param Image $imageModel
     * @param Session $backendSession
     * @param SizedimensionFactory $sizedimensionFactory
     * @param Registry $registry
     * @param RedirectFactory $resultRedirectFactory
     * @param Context $context
     */
    public function __construct(
        SizedimensionFactory $sizedimensionFactory,
        Registry $registry,
        
        Context $context,
		Data $sizedimensionHelper
    )
    {
		
        $this->_backendSession    = $context->getSession();
		
		$this->_sizechartHelper = $sizedimensionHelper;
		
		
        parent::__construct($sizedimensionFactory, $registry,$context);
    }
	/*
	 * Check permission via ACL resource
	 */
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed(Self::RESOURCE_ID);
	}
    /**
     * run the action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
		$sizedimension = $this->_initSizedimension();
		
        $data = $this->getRequest()->getPost('sizedimension');
		
        $resultRedirect = $this->resultRedirectFactory->create();
		
        if ($data) 
		{	
			if(preg_match('/^[a-z_]+$/',$data['dimension_code']))
			{
			
				$sizedimension->setData($data);
				
				$this->_eventManager->dispatch(
					'mageants_advancesizechart_sizedimension_prepare_save',
					[
						'sizechart' => $sizedimension,
						'request' => $this->getRequest()
					]
				);
				
				try 
				{
					$sizedimension->save();
					
					$this->messageManager->addSuccess(__('The Size Dimension has been saved.'));
					
					$this->_backendSession->setMageantsAdvancesizechartData(false);
					
					if ($this->getRequest()->getParam('back')) 
					{
						$resultRedirect->setPath(
							'mageants_advancesizechart/*/edit',
							[
								'id' => $sizedimension->getId(),
								'_current' => true
							]
						);
						
						return $resultRedirect;
					}
					
					$resultRedirect->setPath('mageants_advancesizechart/*/');
					
					return $resultRedirect;
					
				} 
				catch (\Magento\Framework\Exception\LocalizedException $e) 
				{
					$this->messageManager->addError($e->getMessage());
				} 
				catch (\RuntimeException $e) 
				{
					$this->messageManager->addError($e->getMessage());
				} 
				catch (\Exception $e) 
				{
					$this->messageManager->addException($e, __('Something went wrong while saving the Sizedimension.'));
				}
				
				$this->_getSession()->setMageantsAdvancesizechartPostData($data);
				
				$resultRedirect->setPath(
					'mageants_advancesizechart/*/edit',
					[
						'id' => $sizedimension->getId(),
						'_current' => true
					]
				);
				
				return $resultRedirect;
			}
			else{
				
				$this->messageManager->addError('Only small characters and underscore allow in code.');
				
				$resultRedirect->setPath(
						'mageants_advancesizechart/*/edit',
						[
							'id' => $sizedimension->getId(),
							'_current' => true
						]
					);
				return $resultRedirect;
			}			
        }
		
        $resultRedirect->setPath('mageants_advancesizechart/*/');
		
        return $resultRedirect;
    }
	 
}

<?php 
 /**
 * @category Mageants Advance Size Chart
 * @package Mageants_Advancesizechart
 * @copyright Copyright (c) 2017 Mageants
 * @author Mageants Team <info@mageants.com>
 */
namespace Mageants\Advancesizechart\Helper; 

use \Magento\Framework\App\Config\ScopeConfigInterface;
use \Magento\Framework\App\Helper\Context;
use \Magento\Store\Model\ScopeInterface;
		
class Data extends \Magento\Framework\App\Helper\AbstractHelper 
{
	/** 
	* @var \Magento\Framework\App\Config\ScopeConfigInterfac 
	*/ 
	protected $_scopeConfig;
	
	/** 
	* @var array
	*/ 
	protected $_sizechartsConfig; 
	
	/** 
	* @var \Magento\Backend\Helper\Data
	*/ 
	protected $_helperBackend; 

	/*Extention Enable Disable Constant*/
	CONST ENABLE = 'mageants_advancesizechart/general/enable'; 
	CONST SIZECHART_ICON = 'mageants_advancesizechart/general/sizechart_icon'; 
	CONST SIZECHART_LINKLABEL = 'mageants_advancesizechart/general/link_label'; 
	CONST SIZE_ADVISER_NOTE = 'mageants_advancesizechart/general/adviser_note'; 
	CONST SIZE_CHART_POPUP_LABEL = 'mageants_advancesizechart/general/sizechart_popup_label'; 
	CONST SIZE_CHART_TAB_LABEL = 'mageants_advancesizechart/general/sizechart_tab_label'; 
	CONST SIZE_ADVISER_TAB_LABEL = 'mageants_advancesizechart/general/sizeadv_tab_label'; 
	CONST SIZE_ADVISER_RESULT_TAB_LABEL = 'mageants_advancesizechart/general/sizeadvresu_tab_label'; 
	
	 /**
	 *	construct
	 *
     * @param Context $context,
	 * @param ScopeConfigInterface $scopeConfig 
	 * @param Data $HelperBackend
     */
	public function __construct( 
		Context $context, 	
		\Magento\Backend\Helper\Data $HelperBackend
	) 
	{
		parent::__construct($context); 
		
		$this->_scopeConfig = $context->getscopeConfig();
		
		$this->_helperBackend = $HelperBackend;
		
		$this->_sizechartsConfig['link_label'] =  $this->_scopeConfig->getValue(self::SIZECHART_LINKLABEL,ScopeInterface::SCOPE_STORE);
    }
	
	/**
     * Retrieve sizechart icon
     *
     * @return string
     */
    public function getSizechartIcon()
	{
		return $this->_scopeConfig->getValue(self::SIZECHART_ICON,ScopeInterface::SCOPE_STORE);
    }
	
	/**
     * Retrieve extention enable or disable
     *
     * @return boolean
     */
    public function isExtentionEnable()
	{
		return $this->_scopeConfig->getValue(self::ENABLE,ScopeInterface::SCOPE_STORE);
    }
	/**
     * Retrieve extention Adviser slider note
     *
     * @return string
     */
    public function getAdviserNote()
	{
		return $this->_scopeConfig->getValue(self::SIZE_ADVISER_NOTE,ScopeInterface::SCOPE_STORE);
    }
	/**
     * Retrieve extention Size chart popup label
     *
     * @return string
     */
    public function getSizeChartPopupLabel()
	{
		return $this->_scopeConfig->getValue(self::SIZE_CHART_POPUP_LABEL,ScopeInterface::SCOPE_STORE);
    }
	/**
     * Retrieve extention Size chart tab label
     *
     * @return string
     */
    public function getSizeChartTabLabel()
	{
		return $this->_scopeConfig->getValue(self::SIZE_CHART_TAB_LABEL,ScopeInterface::SCOPE_STORE);
    }
	/**
     * Retrieve extention Size Adviser tab label
     *
     * @return string
     */
    public function getSizeAdviserTabLabel()
	{
		return $this->_scopeConfig->getValue(self::SIZE_ADVISER_TAB_LABEL,ScopeInterface::SCOPE_STORE);
    }
	/**
     * Retrieve extention Size Adviser Result tab label
     *
     * @return string
     */
    public function getAdviserResultTabLabel()
	{
		return $this->_scopeConfig->getValue(self::SIZE_ADVISER_RESULT_TAB_LABEL,ScopeInterface::SCOPE_STORE);
    }
	/**
     * Retrieve default sizechart configuration
     *
     * @return array
     */
    public function getDefaultSizechartSetting()
	{
			return $this->_sizechartsConfig;
    }
		
	/**
     * Retrieve serialize setting
     *
     * @return array
     */
    public function serializeSetting($data)
	{
		 return serialize($data);
    }
		
	/**
     * Retrieve unserialize setting
     *
     * @return array
     */
    public function unserializeSetting($string)
	{
		$data['setting'] = array();
		
		if(!empty($string))
		{
			return unserialize($string);
		}
		else
		{
			return $data;
		}
    }
}
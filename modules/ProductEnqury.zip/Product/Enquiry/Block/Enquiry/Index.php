<?php
/**
 * Copyright © 2015 Product . All rights reserved.
 */
namespace Product\Enquiry\Block\Enquiry;
use Product\Enquiry\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
